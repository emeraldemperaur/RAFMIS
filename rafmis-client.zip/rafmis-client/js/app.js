(function () {
    'use strict';

    angular.module('rafmis', [
        'omnl',
        'ui.router', // Routing
        'ui.bootstrap', // Ui Bootstrap
        'ngIdle', // Idle timer
        'rafmis.config', // configuration module
        'rafmis.revenueMonitoringModule', // revenue monitoring module
        'securityModule',
        'rafmis.revenueConfigurationModule', // revenue configuration module
        'rafmis.principleManagementModule', //principle management module
        'cgNotify',
        'datatables',
        'ngCookies',
        'cgNotify',
        'datePicker',
        'datatables',
        'ngCookies',
        'ngMessages',
        'ngCsv',
        'ngCsvImport',
        'rafmis.dashboard',
        'rafmis.beneficiaryManagementModule',
        'angular-confirm',
        'rafmis.userManagementModule',
        'rafmis.activityLogModule',
        'smart-table',
        'checklist-model'
    ])

        .config(['$urlRouterProvider', '$locationProvider', function ($urlRouterProvider, $locationProvider) {
            $locationProvider.html5Mode(false);

            $urlRouterProvider.otherwise('/');

        }])

        .config(function (stConfig) {
            stConfig.pagination.template = 'views/common/st-pagination.html';
        })


        .run(['$rootScope', '$state', '$cookieStore', '$location', 'AuthorizationService', 'UtilityService',
            function ($rootScope, $state, $cookieStore, $location, AuthorizationService, UtilityService) {
                $rootScope.pageTitle = '';
                $rootScope.isLoaded = true;

                $rootScope.$on('login-successful', function (event) {
                    $state.go('dashboard');
                });

                $rootScope.$on('access-denied', function (event) {
                    UtilityService.notify('Access Denied', 'alert-danger');
                });

                $rootScope.$on('$stateChangeStart', function (event, toRoute, fromRoute) {
                    var toRouteData = toRoute.data !== undefined ? toRoute.data : {};
                    $rootScope.currentUser = JSON.parse(sessionStorage.getItem('rafmis-token'));

                    if (!angular.isDefined($rootScope.currentUser)) {
                        $rootScope.currentUser = JSON.parse(sessionStorage.getItem('rafmis-token'));
                    }

                    if (toRouteData.loginRequired && !$rootScope.currentUser) {
                        event.preventDefault();
                        $state.go('login');
                    }

                    $rootScope.pageTitle = toRouteData.title !== undefined ? "RAFMIS | " + toRouteData.pageTitle : 'RAFMIS';
                    $('body').off('click')
                });
            }])

        .config(['$httpProvider', function ($httpProvider) {
            $httpProvider.interceptors.push([
                '$cookieStore', '$location', '$q', '$rootScope', function ($cookieStore, $location, $q, $rootScope) {
                    var TIMEOUT = 90000;

                    return {
                        request: function (config) {
                            config.headers = config.headers || {};

                            if (angular.isDefined(sessionStorage.getItem('rafmis-token'))) {
                                var authData = sessionStorage.getItem('rafmis-token');
                                authData = JSON.parse(authData);
                                if (authData) {
                                    config.headers.Authorization = authData.token;
                                }
                            }

                            if ($location.path() === '\login') {
                                delete config.headers.Authorization;
                            }

                            config.timeout = TIMEOUT;

                            return config;
                        },
                        responseError: function (response) {
                            if (response.status === 403) {
                                $rootScope.$broadcast('access-denied');
                            }

                            if (response.status === 401) {
                                $location.path('/login');
                                return $q.reject(response);
                            } else {
                                return $q.reject(response);
                            }
                        }
                    };
                }
            ]);
        }]);
})();

// Other libraries are loaded dynamically in the config.js file using the library ocLazyLoad
