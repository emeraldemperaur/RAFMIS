/* * ***************************************************						 		 		 	 
 * 	Authors: James Akinniranye <jamesniranye@gmail.com> ,Olabosinde Dipo 						     
 * 	Revision: 1.0					         				 
 * 	Date Created:    Oct 15, 2014  10:28:41 PM			         			 
 * 	Last Revision Date:                       
 * ****************************************************     
 */

function fluidDialog() {
    var $visible = $(".ui-dialog:visible");
    // each open dialog
    $visible.each(function() {
        var $this = $(this);
        var dialog = $this.find(".ui-dialog-content").data("ui-dialog");
        // if fluid option == true
        if (dialog.options.fluid) {
            var wWidth = $(window).width();
            // check window width against dialog width
            if (wWidth < (parseInt(dialog.options.maxWidth) + 50)) {
                // keep dialog from filling entire screen
                $this.css("max-width", "90%");
            } else {
                // fix maxWidth bug
                $this.css("max-width", dialog.options.maxWidth + "px");
            }
            //reposition dialog
            dialog.option("position", dialog.options.position);
        }
    });

}

function selectorEvent() {
    $("#columnSelect select").off("focus change");
    if (!$("#importcheck").is(':checked')) {
        return;
    }

    $("#columnSelect select").on('focus', function() {
        // Store the current value on focus and on change
        previouSelectionPicked = $(this).val();
    }).on("change",
            function() {
                if ($(this).val()) {
                    //hide all other options except this select and group that have this same value
                    var thisVal = $(this).val();
                    //loop through all the options of the selects elements expect of the current one
                    $.each($("#columnSelect select:not([name=" + $(this).attr("name") + "])").children(), function(key, element) {
                        if ($(element).attr("value") === thisVal) {
                            $(element).hide();
                        }
                    });
                }
                //show all the options with the previous value
                if (previouSelectionPicked) {
                    $.each($("#columnSelect  option"), function(key, element) {
                        if ($(element).attr("value") === previouSelectionPicked) {
                            $(element).show();
                        }
                    });

                }

            });
}

function convertExcelToCsv(submit_url, file_input, successfulcallback, failedcallback) {
    var deferred = null;
    var $form = $("<form id='webmasterfileform' />");
    $form.append($(file_input).attr("name", "webmasterfile").clone(false, false).removeAttr("id"));


    var myfile = file_input.files[0];
    file_input.files = null;
    $(file_input).val("");
    var ie_timeout = null;


    if ("FormData" in window) {
        var formData_object = new FormData();//create empty FormData object


        formData_object.append($(file_input).attr("name"), myfile);


        deferred = $.ajax({
            url: submit_url,
            type: 'POST',
            processData: false, //important
            contentType: false, //important
            dataType: 'json', //server response type
            data: formData_object
        });
    }
    else {
        $("body").append($form);
        deferred = new $.Deferred;

        var temporary_iframe_id = 'temporary-iframe-' + (new Date()).getTime() + '-' + (parseInt(Math.random() * 1000));
        var temp_iframe =
                $('<iframe id="' + temporary_iframe_id + '" name="' + temporary_iframe_id + '" \
                                                                        frameborder="0" width="0" height="0" src="about:blank"\
                                                                        style="position:absolute; z-index:-1; visibility: hidden;"></iframe>')
                .insertAfter($form);

        $form.append('<input type="hidden" name="temporary-iframe-id" value="' + temporary_iframe_id + '" />');



        temp_iframe.data('deferrer', deferred);
        //we save the deferred object to the iframe and in our server side response
        //we use "temporary-iframe-id" to access iframe and its deferred object

        $form.attr({
            action: submit_url,
            method: 'POST',
            enctype: 'multipart/form-data',
            target: temporary_iframe_id //important
        });

        $form.get(0).submit();

        //if we don't receive any response after 600 seconds, declare it as failed!
        ie_timeout = setTimeout(function() {
            ie_timeout = null;
            temp_iframe.attr('src', 'about:blank').remove();
            deferred.reject({'status': 'fail', 'message': 'Timeout!'});
        }, 600000);
    }


    //deferred callbacks, triggered by both ajax and iframe solution
    deferred
            .done(function(result) {//success
                if (result["status"] === "1") {
                    if (typeof successfulcallback === "function") {
                        successfulcallback(result["data"], myfile);
                    }
                }
                else {
                    if (typeof failedcallback === "function") {
                        failedcallback();
                    }
                }
                $("#webmasterfileform").remove();
                $(file_input).val("");

            })
            .fail(function(result) {//failure
                if (typeof failedcallback === "function") {
                    failedcallback(result["data"]);
                }

                $("#webmasterfileform").remove();
                $(file_input).val("");

            })
            .always(function() {//called on both success and failure
                if (ie_timeout)
                    clearTimeout(ie_timeout)
                ie_timeout = null;
            });



}
function  showDialog(results, file) {
    if (!results) {

        return false;
    }
    var fields = results.meta.fields;
    var errors = [];
    $.each(fields, function(key, value) {
        if (!isNaN(parseInt(value))) {
            errors.push(value);
        }
    });
    if (errors.length > 0) {
        bootbox.alert("Please make sure all your coulms start with descriptive names like first_name, last_name. Correct the following header(s): " + errors);
        return false;
    }
    //$("#moveContacts").children().remove();
//    $.widget("ui.dialog", $.extend({}, $.ui.dialog.prototype, {
//        _title: function(title) {
//            var $title = this.options.title || '&nbsp;'
//            if (("title_html" in this.options) && this.options.title_html == true)
//                title.html($title);
//            else
//                title.text($title);
//        }
//    }));
    $("#columnSelect select").children().remove();
//            $("#groupIdSelect").children().remove();
//            $('#groupIdSelect').append($('<option>', {
//                value: "",
//                text: 'Please Select Group '
//            }));
    $('#columnSelect select').append($('<option>', {
        value: "",
        text: 'Select Column in  Your CSV '
    }));
//            var groups = $("#gridAll").getColProp("group_id").editoptions.value.split(";");
//            $.each(groups, function(i, item) {
//                var div = item.split(":");
//                if (div[0]) {
//                    $('#groupIdSelect').append($('<option>', {
//                        value: div[0],
//                        text: div[1]
//                    }));
//                }
//
//            });

    $.each(fields, function(i, item) {
        console.log(i, item);
        $('#columnSelect select').append($('<option>', {
            value: item,
            text: item
        }));
    });
    $("body").attr("data", Papa.unparse(results.data));
    $("body").attr("fields", results.meta.fields);
    $("#filename").html(file.name);
    selectorEvent();
    $("#dialog-message").modal('show');

}

        