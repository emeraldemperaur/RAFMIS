/**
 * Created by SQuaye on 6/16/2015.
 */
'use strict';

angular.module('rafmis.config', [])
        .constant('config', {
            api: {
                endpoint: 'http://localhost/rafmis-server',
                DECIMAL_PLACES: 9,
                DECIMAL_PLACES_SCHEDULE: 2
            }
        });
