(function () {
	'use strict';
	
	angular.module('rafmis')
		.config(['$stateProvider', function ($stateProvider) {
			$stateProvider
		        .state('root', {
		            abstract: true,
		            url: "",
		            templateUrl: "views/common/content.html",
					data: {
						loginRequired: true
					}
		        })
				.state('root.index', {
					url: "/",
					template: "<ui-view/>",
					data: {
						loginRequired: true
					}
				})
				.state('security', {
					abstract: true,
					url: "",
					template: "<ui-view/>"
				});
		}])
		.directive('pageLimit', function () {
			return {
				require: '^stTable',
				transclude: true,
				template: '<label><select class="form-control input-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> records per page</label>',
				link: function (scope, element, attr, ctrl) {
					element.bind('change', function (evt) {
						var tableState = ctrl.tableState();
						tableState.pagination.number = element.children().children()[0].value
						ctrl.pipe();
					})
				}
			}
		})
})();
