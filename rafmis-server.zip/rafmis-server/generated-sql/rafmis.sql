
# This is a fix for InnoDB in MySQL >= 4.1.x
# It "suspends judgement" for fkey relationships until are tables are set.
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- activity_log
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `activity_log`;

CREATE TABLE `activity_log`
(
    `activity_id` INTEGER NOT NULL AUTO_INCREMENT,
    `activity_type` VARCHAR(128),
    `details` TEXT,
    `username` VARCHAR(64),
    `date_of_activity` DATETIME,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`activity_id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- app_user
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `app_user`;

CREATE TABLE `app_user`
(
    `username` VARCHAR(64) NOT NULL,
    `email` VARCHAR(128) NOT NULL,
    `role_id` VARCHAR(64) NOT NULL,
    `password` VARCHAR(64),
    `first_name` VARCHAR(64),
    `last_name` VARCHAR(64),
    `active` INTEGER(1),
    `last_login_date` DATETIME,
    `login_attempt` INTEGER(1),
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`username`),
    UNIQUE INDEX `email` (`email`),
    INDEX `role_id` (`role_id`),
    CONSTRAINT `app_user_ibfk_1`
        FOREIGN KEY (`role_id`)
        REFERENCES `role` (`role_id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- beneficiary
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `beneficiary`;

CREATE TABLE `beneficiary`
(
    `beneficiary_id` VARCHAR(64) NOT NULL,
    `beneficiary_category_id` VARCHAR(64) NOT NULL,
    `beneficiary_name` VARCHAR(256) NOT NULL,
    `parent_id` VARCHAR(64),
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`beneficiary_id`),
    INDEX `beneficiary_category_id` (`beneficiary_category_id`),
    CONSTRAINT `beneficiary_ibfk_1`
        FOREIGN KEY (`beneficiary_category_id`)
        REFERENCES `beneficiary_category` (`beneficiary_category_id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- beneficiary_category
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `beneficiary_category`;

CREATE TABLE `beneficiary_category`
(
    `beneficiary_category_id` VARCHAR(64) NOT NULL,
    `description` VARCHAR(256) NOT NULL,
    `parent_category_id` VARCHAR(64),
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`beneficiary_category_id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- beneficiary_category_allocation
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `beneficiary_category_allocation`;

CREATE TABLE `beneficiary_category_allocation`
(
    `beneficiary_cat_allocation_group_id` VARCHAR(64) NOT NULL,
    `beneficiary_category_id` VARCHAR(64) NOT NULL,
    `percentage_allocation` DECIMAL(5,2) NOT NULL,
    `principle_id` VARCHAR(64) NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`beneficiary_cat_allocation_group_id`,`beneficiary_category_id`),
    INDEX `beneficiary_category_id` (`beneficiary_category_id`),
    INDEX `principle_id` (`principle_id`),
    CONSTRAINT `beneficiary_category_allocation_ibfk_1`
        FOREIGN KEY (`beneficiary_cat_allocation_group_id`)
        REFERENCES `beneficiary_category_allocation_group` (`beneficiary_cat_allocation_group_id`)
        ON UPDATE CASCADE,
    CONSTRAINT `beneficiary_category_allocation_ibfk_2`
        FOREIGN KEY (`beneficiary_category_id`)
        REFERENCES `beneficiary_category` (`beneficiary_category_id`)
        ON UPDATE CASCADE,
    CONSTRAINT `beneficiary_category_allocation_ibfk_3`
        FOREIGN KEY (`principle_id`)
        REFERENCES `principle` (`principle_id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- beneficiary_category_allocation_group
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `beneficiary_category_allocation_group`;

CREATE TABLE `beneficiary_category_allocation_group`
(
    `beneficiary_cat_allocation_group_id` VARCHAR(64) NOT NULL,
    `description` VARCHAR(256) NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`beneficiary_cat_allocation_group_id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- beneficiary_index
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `beneficiary_index`;

CREATE TABLE `beneficiary_index`
(
    `beneficiary_id` VARCHAR(64) NOT NULL,
    `principle_item_id` VARCHAR(64) NOT NULL,
    `beneficiary_cat_allocation_group_id` VARCHAR(64) NOT NULL,
    `Index` FLOAT,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`beneficiary_id`,`principle_item_id`,`beneficiary_cat_allocation_group_id`),
    INDEX `beneficiary_id` (`beneficiary_id`),
    INDEX `beneficiary_cat_allocation_group_id` (`beneficiary_cat_allocation_group_id`),
    INDEX `beneficiary_index_ibfi_1` (`principle_item_id`),
    INDEX `i_referenced_schedule_ibfk_1_1` (`principle_item_id`, `beneficiary_id`, `beneficiary_cat_allocation_group_id`),
    CONSTRAINT `beneficiary_index_ibfk_1`
        FOREIGN KEY (`principle_item_id`)
        REFERENCES `principle_item` (`principle_item_id`)
        ON UPDATE CASCADE,
    CONSTRAINT `beneficiary_index_ibfk_2`
        FOREIGN KEY (`beneficiary_id`)
        REFERENCES `beneficiary` (`beneficiary_id`)
        ON UPDATE CASCADE,
    CONSTRAINT `beneficiary_index_ibfk_3`
        FOREIGN KEY (`beneficiary_cat_allocation_group_id`)
        REFERENCES `beneficiary_category_allocation_group` (`beneficiary_cat_allocation_group_id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- categories
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `categoryName` VARCHAR(45) NOT NULL,
    `description` VARCHAR(45),
    `createdAt` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    `updatedAt` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `categoryName_UNIQUE` (`categoryName`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- files
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `files`;

CREATE TABLE `files`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `passportDetailId` INTEGER NOT NULL,
    `filePath` VARCHAR(45) NOT NULL,
    `createdAt` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    `updatedAt` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `filePath_UNIQUE` (`filePath`),
    INDEX `fk_files_passport_detail_idx` (`passportDetailId`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- inhouse_revenue_collection
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `inhouse_revenue_collection`;

CREATE TABLE `inhouse_revenue_collection`
(
    `inhouse_revenue_collection_id` INTEGER NOT NULL AUTO_INCREMENT,
    `revenue_head_id` VARCHAR(64) NOT NULL,
    `mda_code` VARCHAR(64) NOT NULL,
    `expected_payment_month` INTEGER(2) NOT NULL,
    `expected_payment_year` INTEGER(4) NOT NULL,
    `amount` FLOAT,
    `state` VARCHAR(45),
    `payer_name` VARCHAR(64),
    `rc_number` VARCHAR(32),
    `source_id` VARCHAR(128),
    `tin_number` VARCHAR(32),
    `payment_date` DATE,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`inhouse_revenue_collection_id`),
    INDEX `revenue_head_id` (`revenue_head_id`),
    INDEX `mda_code` (`mda_code`),
    CONSTRAINT `inhouse_revenue_collection_ibfk_1`
        FOREIGN KEY (`revenue_head_id`)
        REFERENCES `revenue_head` (`revenue_head_id`)
        ON UPDATE CASCADE,
    CONSTRAINT `inhouse_revenue_collection_ibfk_2`
        FOREIGN KEY (`mda_code`)
        REFERENCES `revenue_collection_entity` (`mda_code`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- locations
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `locations`;

CREATE TABLE `locations`
(
    `id` INTEGER NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(45) NOT NULL,
    `loactionCode` VARCHAR(5) NOT NULL,
    `createdAt` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    `updatedAt` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE INDEX `location_UNIQUE` (`name`),
    UNIQUE INDEX `loactionCode_UNIQUE` (`loactionCode`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- principle
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `principle`;

CREATE TABLE `principle`
(
    `principle_id` VARCHAR(64) NOT NULL,
    `description` VARCHAR(256) NOT NULL,
    `is_active` INTEGER(1) NOT NULL,
    `is_default` INTEGER(1) NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`principle_id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- principle_item
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `principle_item`;

CREATE TABLE `principle_item`
(
    `principle_item_id` VARCHAR(64) NOT NULL,
    `principle_item_name` VARCHAR(256) NOT NULL,
    `principle_id` VARCHAR(64) NOT NULL,
    `beneficiary_category_id` VARCHAR(64) NOT NULL,
    `is_equal` INTEGER(1) DEFAULT 0 NOT NULL,
    `percentage_allocation` DECIMAL(5,2) NOT NULL,
    `parent_id` VARCHAR(64),
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`principle_item_id`),
    INDEX `beneficiary_category_id` (`beneficiary_category_id`),
    INDEX `principle_id` (`principle_id`),
    CONSTRAINT `principle_item_ibfk_1`
        FOREIGN KEY (`beneficiary_category_id`)
        REFERENCES `beneficiary_category` (`beneficiary_category_id`)
        ON UPDATE CASCADE,
    CONSTRAINT `principle_item_ibfk_2`
        FOREIGN KEY (`principle_id`)
        REFERENCES `principle` (`principle_id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- priviledge
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `priviledge`;

CREATE TABLE `priviledge`
(
    `privilege_id` VARCHAR(64) NOT NULL,
    `privilege_name` VARCHAR(256),
    PRIMARY KEY (`privilege_id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- raw_data
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `raw_data`;

CREATE TABLE `raw_data`
(
    `principle_item_id` VARCHAR(64) NOT NULL,
    `beneficiary_id` VARCHAR(64) NOT NULL,
    `value` FLOAT NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    INDEX `beneficiary_id` (`beneficiary_id`),
    INDEX `principle_item_id` (`principle_item_id`),
    CONSTRAINT `raw_data_ibfk_1`
        FOREIGN KEY (`beneficiary_id`)
        REFERENCES `beneficiary` (`beneficiary_id`)
        ON UPDATE CASCADE,
    CONSTRAINT `raw_data_ibfk_2`
        FOREIGN KEY (`principle_item_id`)
        REFERENCES `principle_item` (`principle_item_id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- revenue
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `revenue`;

CREATE TABLE `revenue`
(
    `revenue_type_id` VARCHAR(64) NOT NULL,
    `month` INTEGER(2) NOT NULL,
    `year` INTEGER(4) NOT NULL,
    `amount` FLOAT NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`revenue_type_id`,`month`,`year`),
    CONSTRAINT `revenue_ibfk_1`
        FOREIGN KEY (`revenue_type_id`)
        REFERENCES `revenue_type` (`revenue_type_id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- revenue_collection
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `revenue_collection`;

CREATE TABLE `revenue_collection`
(
    `revenue_collection_id` INTEGER NOT NULL AUTO_INCREMENT,
    `revenue_head_id` VARCHAR(64) NOT NULL,
    `mda_code` VARCHAR(64) NOT NULL,
    `expected_payment_month` INTEGER(2) NOT NULL,
    `expected_payment_year` INTEGER(4) NOT NULL,
    `amount` FLOAT,
    `state` VARCHAR(45),
    `payer_name` VARCHAR(64),
    `rc_number` VARCHAR(32),
    `source_id` VARCHAR(128),
    `tin_number` VARCHAR(32),
    `payment_date` DATE,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`revenue_collection_id`),
    INDEX `revenue_head_id` (`revenue_head_id`),
    INDEX `mda_code` (`mda_code`),
    CONSTRAINT `revenue_collection_ibfk_1`
        FOREIGN KEY (`revenue_head_id`)
        REFERENCES `revenue_head` (`revenue_head_id`)
        ON UPDATE CASCADE,
    CONSTRAINT `revenue_collection_ibfk_2`
        FOREIGN KEY (`mda_code`)
        REFERENCES `revenue_collection_entity` (`mda_code`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- revenue_collection_entity
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `revenue_collection_entity`;

CREATE TABLE `revenue_collection_entity`
(
    `mda_code` VARCHAR(64) NOT NULL,
    `description` VARCHAR(256),
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`mda_code`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- revenue_head
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `revenue_head`;

CREATE TABLE `revenue_head`
(
    `revenue_head_id` VARCHAR(64) NOT NULL,
    `description` VARCHAR(256) NOT NULL,
    `mda_code` VARCHAR(64) NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`revenue_head_id`),
    INDEX `mda_code` (`mda_code`),
    CONSTRAINT `revenue_head_ibfk_1`
        FOREIGN KEY (`mda_code`)
        REFERENCES `revenue_collection_entity` (`mda_code`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- revenue_head_collection
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `revenue_head_collection`;

CREATE TABLE `revenue_head_collection`
(
    `revenue_head_id` VARCHAR(64) NOT NULL,
    `mda_code` VARCHAR(64) NOT NULL,
    `amount` FLOAT NOT NULL,
    `payment_period_month` INTEGER(2) NOT NULL,
    `payment_period_year` INTEGER(4) NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`revenue_head_id`,`mda_code`,`payment_period_month`,`payment_period_year`),
    INDEX `mda_code` (`mda_code`),
    CONSTRAINT `revenue_head_collection_ibfk_1`
        FOREIGN KEY (`revenue_head_id`)
        REFERENCES `revenue_head` (`revenue_head_id`)
        ON UPDATE CASCADE,
    CONSTRAINT `revenue_head_collection_ibfk_2`
        FOREIGN KEY (`mda_code`)
        REFERENCES `revenue_collection_entity` (`mda_code`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- revenue_head_remittance
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `revenue_head_remittance`;

CREATE TABLE `revenue_head_remittance`
(
    `mda_code` VARCHAR(64) NOT NULL,
    `revenue_head_id` VARCHAR(64) NOT NULL,
    `month` INTEGER(2) NOT NULL,
    `year` INTEGER(4) NOT NULL,
    `remittance_date` DATETIME,
    `amount` FLOAT,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`mda_code`,`revenue_head_id`,`month`,`year`),
    INDEX `revenue_head_id` (`revenue_head_id`),
    CONSTRAINT `revenue_head_remittance_ibfk_1`
        FOREIGN KEY (`mda_code`)
        REFERENCES `revenue_collection_entity` (`mda_code`)
        ON UPDATE CASCADE,
    CONSTRAINT `revenue_head_remittance_ibfk_2`
        FOREIGN KEY (`revenue_head_id`)
        REFERENCES `revenue_head` (`revenue_head_id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- revenue_type
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `revenue_type`;

CREATE TABLE `revenue_type`
(
    `revenue_type_id` VARCHAR(64) NOT NULL,
    `description` VARCHAR(256) NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`revenue_type_id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- revenue_type_category
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `revenue_type_category`;

CREATE TABLE `revenue_type_category`
(
    `revenue_type_category_id` VARCHAR(64) NOT NULL,
    `description` VARCHAR(256) NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`revenue_type_category_id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- revenue_type_category_group
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `revenue_type_category_group`;

CREATE TABLE `revenue_type_category_group`
(
    `revenue_type_id` VARCHAR(64) NOT NULL,
    `revenue_type_category_id` VARCHAR(64) NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`revenue_type_id`,`revenue_type_category_id`),
    INDEX `revenue_type_category_id` (`revenue_type_category_id`),
    CONSTRAINT `revenue_type_category_group_ibfk_1`
        FOREIGN KEY (`revenue_type_id`)
        REFERENCES `revenue_type` (`revenue_type_id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `revenue_type_category_group_ibfk_2`
        FOREIGN KEY (`revenue_type_category_id`)
        REFERENCES `revenue_type_category` (`revenue_type_category_id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- role
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role`
(
    `role_id` VARCHAR(64) NOT NULL,
    `role_name` VARCHAR(256) NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`role_id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- role_priviledge
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `role_priviledge`;

CREATE TABLE `role_priviledge`
(
    `role_id` VARCHAR(64) NOT NULL,
    `privilege_id` VARCHAR(64) NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`role_id`,`privilege_id`),
    INDEX `privilege_id` (`privilege_id`),
    CONSTRAINT `role_priviledge_ibfk_1`
        FOREIGN KEY (`role_id`)
        REFERENCES `role` (`role_id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `role_priviledge_ibfk_2`
        FOREIGN KEY (`privilege_id`)
        REFERENCES `priviledge` (`privilege_id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- schedule
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `schedule`;

CREATE TABLE `schedule`
(
    `beneficiary_id` VARCHAR(64) NOT NULL,
    `principle_item_id` VARCHAR(64) NOT NULL,
    `beneficiary_cat_allocation_group_id` VARCHAR(64) NOT NULL,
    `revenue_type_category_id` VARCHAR(64) NOT NULL,
    `allocated_value` FLOAT NOT NULL,
    `disbursed_value` FLOAT,
    `month` INTEGER(2) NOT NULL,
    `year` INTEGER(4) NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`beneficiary_id`,`principle_item_id`,`beneficiary_cat_allocation_group_id`,`revenue_type_category_id`,`month`,`year`),
    INDEX `revenue_type_category_id` (`revenue_type_category_id`),
    INDEX `schedule_ibfi_1` (`principle_item_id`, `beneficiary_id`, `beneficiary_cat_allocation_group_id`),
    CONSTRAINT `schedule_ibfk_1`
        FOREIGN KEY (`principle_item_id`,`beneficiary_id`,`beneficiary_cat_allocation_group_id`)
        REFERENCES `beneficiary_index` (`principle_item_id`,`beneficiary_id`,`beneficiary_cat_allocation_group_id`)
        ON UPDATE CASCADE,
    CONSTRAINT `schedule_ibfk_2`
        FOREIGN KEY (`revenue_type_category_id`)
        REFERENCES `revenue_type_category` (`revenue_type_category_id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- session_token
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `session_token`;

CREATE TABLE `session_token`
(
    `username` VARCHAR(64) NOT NULL,
    `token` VARCHAR(256) NOT NULL,
    `date_created` DATETIME NOT NULL,
    PRIMARY KEY (`username`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- state
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `state`;

CREATE TABLE `state`
(
    `state_id` VARCHAR(64) NOT NULL,
    `state_name` VARCHAR(64) NOT NULL,
    PRIMARY KEY (`state_id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- supergroup
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `supergroup`;

CREATE TABLE `supergroup`
(
    `supergroup_id` VARCHAR(64) NOT NULL,
    `description` VARCHAR(256) NOT NULL,
    `is_active` INTEGER(1) NOT NULL,
    `is_default` INTEGER(1) NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`supergroup_id`)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- supergroup_revenue_type_category
-- ---------------------------------------------------------------------

DROP TABLE IF EXISTS `supergroup_revenue_type_category`;

CREATE TABLE `supergroup_revenue_type_category`
(
    `revenue_type_category_id` VARCHAR(64) NOT NULL,
    `supergroup_id` VARCHAR(64) NOT NULL,
    `date_created` DATETIME NOT NULL,
    `created_by` VARCHAR(64) NOT NULL,
    `date_modified` DATETIME,
    `modified_by` VARCHAR(64),
    PRIMARY KEY (`revenue_type_category_id`,`supergroup_id`),
    INDEX `supergroup_id` (`supergroup_id`),
    CONSTRAINT `supergroup_revenue_type_category_ibfk_1`
        FOREIGN KEY (`revenue_type_category_id`)
        REFERENCES `revenue_type_category` (`revenue_type_category_id`)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT `supergroup_revenue_type_category_ibfk_2`
        FOREIGN KEY (`supergroup_id`)
        REFERENCES `supergroup` (`supergroup_id`)
        ON UPDATE CASCADE
) ENGINE=InnoDB;

# This restores the fkey checks, after having unset them earlier
SET FOREIGN_KEY_CHECKS = 1;
