<?php

require_once 'db.properties.php';

$serviceContainer = \Propel\Runtime\Propel::getServiceContainer();
$serviceContainer->checkVersion('2.0.0-dev');
$serviceContainer->setAdapterClass('rafmis', 'mysql');
$manager = new \Propel\Runtime\Connection\ConnectionManagerSingle();
$manager->setConfiguration(array(
    'classname' => 'Propel\\Runtime\\Connection\\DebugPDO',
    'dsn' => 'mysql:host=' . DATABASE_HOST . ';dbname=' . DATABASE_NAME,
    'user' => DB_USERNAME,
    'password' => DB_PASSWORD
));
$manager->setName('rafmis');
$serviceContainer->setConnectionManager('rafmis', $manager);
$serviceContainer->setDefaultDatasource('rafmis');
