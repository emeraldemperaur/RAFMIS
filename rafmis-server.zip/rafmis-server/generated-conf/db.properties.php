<?php

        const DB_USERNAME = "root"; //The UserName for the Database Server

        const DB_PASSWORD = ""; //The Password for the Database Server

        const DATABASE_HOST = "localhost"; //The Name of the Host on which the database server is located

        const DATABASE_NAME = "rafmisdb"; //The Name of the selected Database
