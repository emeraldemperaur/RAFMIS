/* ****************************************************	*/
/*	Project: RAFMIS					*/
/*	Database Name: rafmis				*/
/*	File Purpose: Application Database Schema       */
/*	Author: Ada Orajiaku                            */
/*	Revision: Farouk Alogba                         */
/*	Revision: 1.8					*/
/*	Date Created: 23 May  2015			*/
/*	Last Revision Date: 06 July 2015			*/

/* *************REVISION HISTORY**********************	*/
/*
@farouk:24-05-2015: Added drop table statement to all tables.
@farouk:24-05-2015: Re-arranged tables.
@farouk:24-05-2015: Modified foreign key statements in all tables.
@farouk:24-05-2015: Added NOT NULL constraint to 'created_by' and `date_created'
        fields.
@farouk:24-05-2015: Modified `session_token` table - Added additional fields and 
        primary key.
@farouk:24-05-2015: General table relationship corrections
@farouk:22-06-2015: Added DELETE CASCASE to table supergroup_revenue_type_category
@farouk:22-06-2015: Added DELETE CASCASE to table revenue_type_category_group
@farouk:24-06-2015: Modified all occurrence of DECIMAL(3,2) to DECIMAL(5,2)
@farouk:24-06-2015: Deleted table revenue_allocation (Not needed for the tight coupling)
@farouk:24-06-2015: Added `beneficiary_cat_allocation_group_id` for reference to `beneficiary_category_allocation_group` table
@farouk:30-06-2015: Added `state` table
@farouk:30-06-2015: Changed PRIMARY KEY on revenue_collection to AUTO INCREMENT
@farouk:30-06-2015: Changed PRIMARY KEY on inhouse_revenue_collection to AUTO INCREMENT
@farouk:01-07-2015: Changed principle_item_id from INT to VARCHAR(64) in the following tables:
					Tables: principle_item, raw_data, beneficiary_index, schedule.
@farouk:04-07-2015: Modified fields with INT(1) to have a default of zero (0) in the following tables:
					Tables: principle, principle_item, app_user, supergroup		
@farouk:06-07-2015: Modified raw_data table:
					Added composite primary key of `principle_item_id` and  `beneficiary_id`;		
@farouk:16-07-2015: Modified principle_item table changed `parent_id` INT NULL to `parent_id` VARCHAR(64) NULL	
@farouk:30-07-2015:	Modified FK relationship between principle and principle_item to include CASCADE DELETE
					FOREIGN KEY (`principle_id`) REFERENCES `principle` (`principle_id`)
					ON DELETE CASCADE ON UPDATE CASCADE
@farouk:04-08-2015: Added revenue_target table.
@farouk:06-08-2015: Added schedule_disbursement table.		
@farouk:17-08-2015: Table schedule_disbursement : Changed `total_disbursed_value` FLOAT NOT NULL to `total_disbursed_value` FLOAT NULL
*/


-- =======================================================
-- *             User Management tables                 --
-- *             -----------------------                --
-- * 							--
-- *  `priviledge`					--
-- *  `role`                                            --
-- *  `role_priviledge`                                 --
-- *  `app_user`                                        --
-- *   activity_log                                     --
-- *   session_token                                     --
-- =======================================================



-- -----------------------------------------------------
-- Table `priviledge`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `priviledge`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `priviledge` (
  `privilege_id` VARCHAR(64) NOT NULL,
  `privilege_name` VARCHAR(256) NULL,
  PRIMARY KEY (`privilege_id`)
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `role`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `role`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `role` (
  `role_id` VARCHAR(64) NOT NULL,
  `role_name` VARCHAR(256) NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`role_id`)
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `role_priviledge`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `role_priviledge`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `role_priviledge` (
  `role_id` VARCHAR(64) NOT NULL,
  `privilege_id` VARCHAR(64) NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`role_id`, `privilege_id`),
  FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (`privilege_id`) REFERENCES `priviledge` (`privilege_id`)
    ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;



-- -----------------------------------------------------
-- Table `app_user`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `app_user`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `app_user` (
  `username` VARCHAR(64) NOT NULL,
  `email` VARCHAR(128) NOT NULL,
  `role_id` VARCHAR(64) NOT NULL,
  `password` VARCHAR(64) NULL,
  `first_name` VARCHAR(64) NULL,
  `last_name` VARCHAR(64) NULL,
  `active` INT(1) NULL DEFAULT 0,
  `last_login_date` DATETIME NULL,
  `login_attempt` INT(1) NULL DEFAULT 0,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`username`),
  UNIQUE (email),
  FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `activity_log`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `activity_log`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `activity_log` (
  `activity_id` INT NOT NULL AUTO_INCREMENT,
  `activity_type` VARCHAR(128) NULL,
  `details` TEXT(128) NULL,
  `username` VARCHAR(64) NULL,
  `date_of_activity` DATETIME NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`activity_id`)
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `session_token`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `session_token`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `session_token` (
  `username` VARCHAR(64) NOT NULL,  
  `token` VARCHAR(256) NOT NULL,
  `date_created` DATETIME NOT NULL,
  PRIMARY KEY (`username`)
)ENGINE=INNODB DEFAULT CHARSET=utf8;



-- =======================================================
-- *             Payment tables                         --
-- *             --------------                         --
-- * 							--
-- *  `revenue_type`					--
-- *  `revenue`                                         --
-- *  `beneficiary_category`                            --
-- *  `beneficiary`                                     --
-- *  `supergroup`                                      --
-- *  `revenue_type_category`                           --
-- *  `revenue_type_category_group`                     --
-- *  `supergroup_revenue_type_category`                --
-- *  `principle`                                       --
-- *  `principle_item`                                  --
-- *  `beneficiary_category_allocation_group`           --
-- *  `beneficiary_index`                               --
-- *  `raw_data`                                        --
-- *  `schedule`                                        --
-- *  `beneficiary_category_allocation`                 --
-- =======================================================



-- -----------------------------------------------------
-- Table `revenue_type`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `revenue_type`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `revenue_type` (
  `revenue_type_id` VARCHAR(64) NOT NULL,
  `description` VARCHAR(256) NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`revenue_type_id`)
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `revenue`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `revenue`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `revenue` (
  `revenue_type_id` VARCHAR(64) NOT NULL,
  `month` INT(2) NOT NULL,
  `year` INT(4) NOT NULL,
  `amount` FLOAT NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`revenue_type_id`, `month`, `year`),
    FOREIGN KEY (`revenue_type_id`) REFERENCES `revenue_type` (`revenue_type_id`)
      ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `beneficiary_category`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `beneficiary_category`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `beneficiary_category` (
  `beneficiary_category_id` VARCHAR(64) NOT NULL,
  `description` VARCHAR(256) NOT NULL,
  `parent_category_id` VARCHAR(64) NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`beneficiary_category_id`)
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 

-- -----------------------------------------------------
-- Table `beneficiary`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `beneficiary`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `beneficiary` (
  `beneficiary_id` VARCHAR(64) NOT NULL,
  `beneficiary_category_id` VARCHAR(64) NOT NULL,
  `beneficiary_name` VARCHAR(256) NOT NULL,
  `parent_id` VARCHAR(64) NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`beneficiary_id`),
  FOREIGN KEY (`beneficiary_category_id`) 
    REFERENCES `beneficiary_category` (`beneficiary_category_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `supergroup`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `supergroup`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `supergroup` (
  `supergroup_id` VARCHAR(64) NOT NULL,
  `description` VARCHAR(256) NOT NULL,
  `is_active` INT(1) NOT NULL DEFAULT 0,
  `is_default` INT(1) NOT NULL DEFAULT 0,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`supergroup_id`)
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `revenue_type_category`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `revenue_type_category`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `revenue_type_category` (
  `revenue_type_category_id` VARCHAR(64) NOT NULL,
  `description` VARCHAR(256) NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`revenue_type_category_id`)
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `revenue_type_category_group`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `revenue_type_category_group`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `revenue_type_category_group` (
  `revenue_type_id` VARCHAR(64) NOT NULL,
  `revenue_type_category_id` VARCHAR(64) NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`revenue_type_id`, `revenue_type_category_id`),
  FOREIGN KEY (`revenue_type_id`) REFERENCES `revenue_type` (`revenue_type_id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (`revenue_type_category_id`)
    REFERENCES `revenue_type_category` (`revenue_type_category_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;



-- -----------------------------------------------------
-- Table `supergroup_revenue_type_category`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `supergroup_revenue_type_category`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `supergroup_revenue_type_category` (
  `revenue_type_category_id` VARCHAR(64) NOT NULL,
  `supergroup_id` VARCHAR(64) NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`revenue_type_category_id`, `supergroup_id`),
  FOREIGN KEY (`revenue_type_category_id`)
    REFERENCES `revenue_type_category` (`revenue_type_category_id`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (`supergroup_id`) REFERENCES `supergroup` (`supergroup_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `principle`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `principle`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `principle` (
  `principle_id` VARCHAR(64) NOT NULL,
  `description` VARCHAR(256) NOT NULL,
  `is_active` INT(1) NOT NULL DEFAULT 0,
  `is_default` INT(1) NOT NULL DEFAULT 0,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`principle_id`)
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `principle_item`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `principle_item`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `principle_item` (
  `principle_item_id` VARCHAR(64) NOT NULL,
  `principle_item_name` VARCHAR(256) NOT NULL,
  `principle_id` VARCHAR(64) NOT NULL,
  `beneficiary_category_id` VARCHAR(64) NOT NULL,
  `is_equal` INT(1) NOT NULL DEFAULT 0,
  `percentage_allocation` DECIMAL(5,2) NOT NULL,
  `parent_id` VARCHAR(64) NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`principle_item_id`),
  FOREIGN KEY (`beneficiary_category_id`)
    REFERENCES `beneficiary_category` (`beneficiary_category_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE,
  FOREIGN KEY (`principle_id`) REFERENCES `principle` (`principle_id`)
    ON DELETE CASCADE ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 

 
-- -----------------------------------------------------
-- Table `raw_data`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `raw_data`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `raw_data` (
  `principle_item_id` VARCHAR(64) NOT NULL,
  `beneficiary_id` VARCHAR(64) NOT NULL,
  `value` FLOAT NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`principle_item_id`, `beneficiary_id`),
  FOREIGN KEY (`beneficiary_id`) REFERENCES `beneficiary` (`beneficiary_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE,
  FOREIGN KEY (`principle_item_id`) 
    REFERENCES `principle_item` (`principle_item_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 
 
 
-- -----------------------------------------------------
-- Table `beneficiary_category_allocation_group`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `beneficiary_category_allocation_group`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `beneficiary_category_allocation_group` (
  `beneficiary_cat_allocation_group_id` VARCHAR(64) NOT NULL,
  `description` VARCHAR(256) NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`beneficiary_cat_allocation_group_id`)
)ENGINE=INNODB DEFAULT CHARSET=utf8;

 
-- -----------------------------------------------------
-- Table `beneficiary_index`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `beneficiary_index`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `beneficiary_index` (
  `beneficiary_id` VARCHAR(64) NOT NULL,  
  `principle_item_id` VARCHAR(64) NOT NULL,
  `beneficiary_cat_allocation_group_id` VARCHAR(64) NOT NULL,
  `Index` FLOAT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`principle_item_id`, `beneficiary_id`,`beneficiary_cat_allocation_group_id`),
  FOREIGN KEY (`principle_item_id`) 
    REFERENCES `principle_item` (`principle_item_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE,
  FOREIGN KEY (`beneficiary_id`) REFERENCES `beneficiary` (`beneficiary_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE,
  FOREIGN KEY (`beneficiary_cat_allocation_group_id`) 
    REFERENCES `beneficiary_category_allocation_group` (`beneficiary_cat_allocation_group_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `schedule`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `schedule`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `schedule` (
  `beneficiary_id` VARCHAR(64) NOT NULL,  
  `principle_item_id` VARCHAR(64) NOT NULL,
  `beneficiary_cat_allocation_group_id` VARCHAR(64) NOT NULL,
  `revenue_type_category_id` VARCHAR(64) NOT NULL,
  `allocated_value` FLOAT NOT NULL,
  `disbursed_value` FLOAT NULL,
  `month` INT(2) NOT NULL,
  `year` INT(4) NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`principle_item_id`, `beneficiary_id`,`beneficiary_cat_allocation_group_id`, `revenue_type_category_id`, `month`, `year`),
  FOREIGN KEY (`principle_item_id`, `beneficiary_id`,`beneficiary_cat_allocation_group_id`) 
    REFERENCES `beneficiary_index` (`principle_item_id`, `beneficiary_id`,`beneficiary_cat_allocation_group_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE,
  FOREIGN KEY (`revenue_type_category_id`) REFERENCES `revenue_type_category` (`revenue_type_category_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;
  

  -- -----------------------------------------------------
-- Table `schedule_disbursement`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `schedule_disbursement`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `schedule_disbursement` (
  `beneficiary_id` VARCHAR(64) NOT NULL,  
  `beneficiary_cat_allocation_group_id` VARCHAR(64) NOT NULL,
  `revenue_type_category_id` VARCHAR(64) NOT NULL,
  `total_allocated_value` FLOAT NOT NULL,
  `total_disbursed_value` FLOAT NULL,
  `month` INT(2) NOT NULL,
  `year` INT(4) NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`beneficiary_id`,`beneficiary_cat_allocation_group_id`, `revenue_type_category_id`, `month`, `year`),
  FOREIGN KEY (`beneficiary_id`) REFERENCES `beneficiary` (`beneficiary_id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  FOREIGN KEY (`beneficiary_cat_allocation_group_id`) REFERENCES `beneficiary_category_allocation_group` (`beneficiary_cat_allocation_group_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE,
  FOREIGN KEY (`revenue_type_category_id`) REFERENCES `revenue_type_category` (`revenue_type_category_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;

-- -----------------------------------------------------
-- Table `beneficiary_category_allocation`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `beneficiary_category_allocation`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `beneficiary_category_allocation` (
  `beneficiary_cat_allocation_group_id` VARCHAR(64) NOT NULL,
  `beneficiary_category_id` VARCHAR(64) NOT NULL,
  `percentage_allocation` DECIMAL(5,2) NOT NULL,
  `principle_id` VARCHAR(64) NOT NULL,  
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`beneficiary_cat_allocation_group_id`, `beneficiary_category_id`),
  FOREIGN KEY (`beneficiary_cat_allocation_group_id`)
    REFERENCES `beneficiary_category_allocation_group` (`beneficiary_cat_allocation_group_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE,
  FOREIGN KEY (`beneficiary_category_id`)
    REFERENCES `beneficiary_category` (`beneficiary_category_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE,
  FOREIGN KEY (`principle_id`) REFERENCES `principle` (`principle_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;


-- =======================================================
-- *             Revenue Tracking tables                --
-- *             -----------------------                --
-- * 							--
-- *  `revenue_collection_entity`			--
-- *  `revenue_head`                                    --
-- *  `revenue_head_collection`                         --
-- *  `revenue_head_remittance`                         --
-- *  `revenue_collection`                              --
-- *  `inhouse_revenue_collection`                      --
-- ======================================================= 


-- -----------------------------------------------------
-- Table `revenue_collection_entity`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `revenue_collection_entity`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `revenue_collection_entity` (
  `mda_code` VARCHAR(64) NOT NULL,
  `description` VARCHAR(256) NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`mda_code`)
)ENGINE=INNODB DEFAULT CHARSET=utf8;



-- -----------------------------------------------------
-- Table `revenue_head`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `revenue_head`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `revenue_head` (
  `revenue_head_id` VARCHAR(64) NOT NULL,
  `description` VARCHAR(256) NOT NULL,
  `mda_code` VARCHAR(64) NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`revenue_head_id`),
  FOREIGN KEY (`mda_code`) REFERENCES `revenue_collection_entity` (`mda_code`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `revenue_head_collection`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `revenue_head_collection`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `revenue_head_collection` (
  `revenue_head_id` VARCHAR(64) NOT NULL,
  `mda_code` VARCHAR(64) NOT NULL,
  `amount` FLOAT NOT NULL,
  `payment_period_month` INT(2) NOT NULL,
  `payment_period_year` INT(4) NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`revenue_head_id`, `mda_code`, `payment_period_month`, `payment_period_year`),
  FOREIGN KEY (`revenue_head_id`) REFERENCES `revenue_head` (`revenue_head_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE,
  FOREIGN KEY (`mda_code`) REFERENCES `revenue_collection_entity` (`mda_code`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `revenue_head_remittance`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `revenue_head_remittance`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `revenue_head_remittance` (
  `mda_code` VARCHAR(64) NOT NULL,
  `revenue_head_id` VARCHAR(64) NOT NULL,
  `month` INT(2) NOT NULL,
  `year` INT(4) NOT NULL,
  `remittance_date` DATETIME NULL,
  `amount` FLOAT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`mda_code`, `revenue_head_id`, `month`, `year`),
  FOREIGN KEY (`mda_code`) REFERENCES `revenue_collection_entity` (`mda_code`)
    ON DELETE NO ACTION ON UPDATE CASCADE,
  FOREIGN KEY (`revenue_head_id`) REFERENCES `revenue_head` (`revenue_head_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `revenue_collection`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `revenue_collection`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `revenue_collection` (
  `revenue_collection_id` INT NOT NULL AUTO_INCREMENT,
  `revenue_head_id` VARCHAR(64) NOT NULL,
  `mda_code` VARCHAR(64) NOT NULL,
  `expected_payment_month` INT(2) NOT NULL,
  `expected_payment_year` INT(4) NOT NULL,
  `amount` FLOAT NULL,
  `state` VARCHAR(45) NULL,
  `payer_name` VARCHAR(64) NULL,
  `rc_number` VARCHAR(32) NULL,
  `source_id` VARCHAR(128) NULL,
  `tin_number` VARCHAR(32) NULL,
  `payment_date` DATE NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`revenue_collection_id`),
  FOREIGN KEY (`revenue_head_id`) REFERENCES `revenue_head` (`revenue_head_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE,
  FOREIGN KEY (`mda_code`) REFERENCES `revenue_collection_entity` (`mda_code`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 


-- -----------------------------------------------------
-- Table `inhouse_revenue_collection`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `inhouse_revenue_collection`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `inhouse_revenue_collection` (
  `inhouse_revenue_collection_id` INT NOT NULL AUTO_INCREMENT,
  `revenue_head_id` VARCHAR(64) NOT NULL,
  `mda_code` VARCHAR(64) NOT NULL,
  `expected_payment_month` INT(2) NOT NULL,
  `expected_payment_year` INT(4) NOT NULL,
  `amount` FLOAT NULL,
  `state` VARCHAR(45) NULL,
  `payer_name` VARCHAR(64) NULL,
  `rc_number` VARCHAR(32) NULL,
  `source_id` VARCHAR(128) NULL,
  `tin_number` VARCHAR(32) NULL,
  `payment_date` DATE NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`inhouse_revenue_collection_id`),
  FOREIGN KEY (`revenue_head_id`) REFERENCES `revenue_head` (`revenue_head_id`)
    ON DELETE NO ACTION ON UPDATE CASCADE,
  FOREIGN KEY (`mda_code`) REFERENCES `revenue_collection_entity` (`mda_code`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;

 
 
-- -----------------------------------------------------
-- Table `revenue_target`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `revenue_target`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `revenue_target` (
  `mda_code` VARCHAR(64) NOT NULL,
  `payment_period_month` INT(2) NOT NULL,
  `payment_period_year` INT(4) NOT NULL,
  `target_amount` FLOAT NOT NULL,
  `date_created` DATETIME NOT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `date_modified` DATETIME NULL,
  `modified_by` VARCHAR(64) NULL,
  PRIMARY KEY (`mda_code`, `payment_period_month`, `payment_period_year`),
  FOREIGN KEY (`mda_code`) REFERENCES `revenue_collection_entity` (`mda_code`)
    ON DELETE NO ACTION ON UPDATE CASCADE
)ENGINE=INNODB DEFAULT CHARSET=utf8;



-- =======================================================
-- *             Utility tables                         --
-- *             --------------                         --
-- * 							--
-- *  `state`					
-- =======================================================



-- -----------------------------------------------------
-- Table `state`
-- -----------------------------------------------------
SET FOREIGN_KEY_CHECKS  = 0;
DROP TABLE IF EXISTS  `state`;
SET FOREIGN_KEY_CHECKS  = 1;
CREATE TABLE `state` (
  `state_id` VARCHAR(64) NOT NULL,
  `state_name` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`state_id`)
)ENGINE=INNODB DEFAULT CHARSET=utf8;
 