<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 5/26/2015
 * Time: 5:49 PM
 *
 * Service configuration file
 */
use Rafmis\RevenueMonitoringModule\RevenueMonitoringModule;
use Rafmis\RevenueConfigurationModule\RevenueConfigurationModule;
use Rafmis\PrincipleManagementModule\PrincipleManagementModule;
use Rafmis\UserManagementModule\UserManagementModule;
use Rafmis\BeneficiaryManagementModule\BeneficiaryManagementModule;
use Rafmis\PaymentScheduleManagementModule\PaymentScheduleManagementModule;
use Rafmis\UtilityModule\UtilityModule;

/**
 * registers RevenueMonitoringModule services
 */
$revenueMonitoringModule = new RevenueMonitoringModule();
$revenueMonitoringModule->register($app);

/**
 * registers RevenueConfigurationModule services
 */
$revenueConfigurationModule = new RevenueConfigurationModule();
$revenueConfigurationModule->register($app);

/**
 * registers PrincipleManagementModule services
 */
$principleManagementModule = new PrincipleManagementModule();
$principleManagementModule->register($app);

/**
 * registers UserManagementModule services
 */
$userManagementModule = new UserManagementModule();
$userManagementModule->register($app);

/**
 * registers BeneficiaryManagementModule services
 */
$beneficiaryManagementModule = new BeneficiaryManagementModule();
$beneficiaryManagementModule->register($app);

/**
 * registers PaymentScheduleManagementModule services
 */
$paymentScheduleManagementModule = new PaymentScheduleManagementModule();
$paymentScheduleManagementModule->register($app);

/**
 * registers UtiltityModule services
 */
$utilityModule = new UtilityModule();
$utilityModule->register($app);
