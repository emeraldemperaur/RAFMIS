<?php

/*
 * Require all the routes present in the routes directory
 * 
 */

$allRoutes = (glob(dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'routes' . DIRECTORY_SEPARATOR . '*.php'));
foreach ($allRoutes as $unit) {
    require $unit;
}
