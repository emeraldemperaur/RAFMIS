<?php
/*

*/


use Rafmis\RevenueConfigurationModule\Controllers\RevenueTypeController;

$app->group('/revenue-type', function () use ($app) {
 	
    $revenueTypeCtrl = new RevenueTypeController();

    // List all Revenue types
    $app->get('/', array($revenueTypeCtrl, 'all'));
        
    // Get revenue type
    $app->get('/:revenueTypeId', array($revenueTypeCtrl, 'show'));
        
    // Create revenue type
    $app->post('/', array($revenueTypeCtrl, 'create'));
    
      // Filter and Export to CSV
    $app->post('/filterexportcsv', array($revenueTypeCtrl, 'filterCsv'));

    // Assign revenue types to revenue type category
    $app->post('/assignToRevenueTypeCategory/:typeCategory', array($revenueTypeCtrl, 'assignToRevenueTypeCategory'));

    // Update revenue type
    $app->put('/:revenueTypeId', array($revenueTypeCtrl, 'update'));

    // Delete revenue type
    $app->delete('/:revenueTypeId', array($revenueTypeCtrl, 'delete'));
    
});
