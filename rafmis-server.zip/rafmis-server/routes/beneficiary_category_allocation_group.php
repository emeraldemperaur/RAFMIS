<?php
/*

*/

use Rafmis\BeneficiaryManagementModule\Controllers\BeneficiaryCategoryAllocationGroupController;


$app->group('/beneficiary-category-allocation-group', function () use ($app) {

    $beneficiaryCategoryAllocationGroupCtrl = new BeneficiaryCategoryAllocationGroupController();

    // List all BeneficiaryCategoryAllocations
    $app->get('/', array($beneficiaryCategoryAllocationGroupCtrl, 'all'));

    // Get BeneficiaryCategoryAllocation with ID
    $app->get('/:id', array($beneficiaryCategoryAllocationGroupCtrl, 'show'));

    // Create BeneficiaryCategoryAllocation
    $app->post('/', array($beneficiaryCategoryAllocationGroupCtrl, 'create'));

     // Filter and Export to CSV
    $app->post('/filterexportcsv', array($beneficiaryCategoryAllocationGroupCtrl, 'filterCsv'));

    // Create BeneficiaryCategoryAllocation
    $app->post('/addtorevcat/:revtypecat', array($beneficiaryCategoryAllocationGroupCtrl, 'addToRevCat'));

    // Update BeneficiaryCategoryAllocation with ID
    $app->put('/:id', array($beneficiaryCategoryAllocationGroupCtrl, 'update'));

    // Delete BeneficiaryCategoryAllocation with ID
    $app->delete('/:id', array($beneficiaryCategoryAllocationGroupCtrl, 'delete'));

});
