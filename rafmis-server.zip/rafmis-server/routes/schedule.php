<?php
/*

*/

use Rafmis\PaymentScheduleManagementModule\Controllers\ScheduleController;

$app->group('/schedule', function () use ($app) {

    $scheduleCtrl = new ScheduleController();

    // List all Schedules
    $app->get('/', array($scheduleCtrl, 'all'));

    // Get Schedule using BeneficiaryId
    $app->get('/beneficiary/:id', array($scheduleCtrl, 'showBeneficiary'));

    // Get Schedule using PrincipleItemId
    $app->get('/principle-item/:id', array($scheduleCtrl, 'showPrincipleItem'));

    // Get Schedule by Month
    $app->get('/month/:id', array($scheduleCtrl, 'showMonth'));

    // Get Schedule by Year
    $app->get('/year/:id', array($scheduleCtrl, 'showYear'));

    // Create Schedule
    $app->post('/', array($scheduleCtrl, 'create'));

    // Generate Schedule
    $app->post('/generate/', array($scheduleCtrl, 'generate'));

    // Generate Indices
    $app->post('/generateIndex/', array($scheduleCtrl, 'generateIndex'));
    
    // Generate Indices
    $app->post('/generateIndex2/', array($scheduleCtrl, 'generateIndex2'));

    // Generate Payment Schedule
    $app->post('/generatePayment/', array($scheduleCtrl, 'generatePayment'));

    // Generate Indices
//    $app->post('/generateIndex/', array($scheduleCtrl, 'generateIndex'));PRI_SCHEDULE_GENERATEPAYMENT

    // Save Payment
    $app->post('/savepayment/', array($scheduleCtrl, 'savePayment'));

    // Save Indices
    $app->post('/saveindices/', array($scheduleCtrl, 'saveIndices'));

    // Save Indices
    $app->post('/scheduleexists/', array($scheduleCtrl, 'scheduleexists'));

    // Update Revenue Disbursment
//    $app->post('/disbursment/', array($scheduleCtrl, 'disbursement'));

    // Update Schedule with id
    $app->put('/', array($scheduleCtrl, 'update'));
//    $app->put('/:id', array($scheduleCtrl, 'update'));

    // Update Schedule with id
    $app->put('/update-multiple', array($scheduleCtrl, 'updateMultiple'));

    // Delete Schedule with id
    $app->delete('/:id', array($scheduleCtrl, 'delete'));

    // Delete Schedule with id
    $app->delete('/:id1/:id2/:id3/:id4', array($scheduleCtrl, 'deletePayment'));
    
    // Delete Schedule with id
    $app->delete('/:id1/:id2/:id3/:id5/:id6', array($scheduleCtrl, 'deleteDisbursement'));

    // Import RC
    $app->post('/importrecords', array($scheduleCtrl, 'importrecords'));
    
    // Convert Excel to CSV
    $app->post('/converttocsv', array($scheduleCtrl, 'convertExcelToCSV'));
    
    // Convert Excel to CSV
    $app->post('/revenuedisbursementgrid', array($scheduleCtrl, 'revenueDisbursementGrid'));

});
