<?php

/*

 */

use Rafmis\UserManagementModule\Controllers\RolePriviledgeController;

$app->group('/rolepriviledge', function () use ($app) {

    $rolePriviledgeCtrl = new RolePriviledgeController();

    // List all RolePriviledges
    $app->get('/', array($rolePriviledgeCtrl, 'all'));

    // Get RolePriviledges with rolePriviledgeId
    $app->get('/:roleId/:privilegeId', array($rolePriviledgeCtrl, 'show'));

    // Create RolePriviledges
    $app->post('/create', array($rolePriviledgeCtrl, 'create'));

    // Update RolePriviledges with rolePriviledgeId
//    $app->put('/update', array($rolePriviledgeCtrl, 'update'));

    // Delete RolePriviledges with rolePriviledgeId
    $app->delete('/delete/:roleId/:privilegeId', array($rolePriviledgeCtrl, 'delete'));
});
