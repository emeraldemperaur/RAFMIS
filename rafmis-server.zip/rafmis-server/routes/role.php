<?php

/*

 */

use Rafmis\UserManagementModule\Controllers\RoleController;

$app->group('/role', function () use ($app) {

    $roleCtrl = new RoleController();

    // List all Roles
    $app->get('/', array($roleCtrl, 'all'));

    // Get Roles with roleId
    $app->get('/:roleId', array($roleCtrl, 'show'));

    // Create Roles
    $app->post('/', array($roleCtrl, 'create'));

    // Update Roles with roleId
    $app->put('/', array($roleCtrl, 'update'));

    // Delete Roles with roleId
    $app->delete('/:roleId', array($roleCtrl, 'delete'));

    $app->get('/:roleId/privileges', array($roleCtrl, 'getRolePrivileges'));

    $app->post('/assign-privileges', array($roleCtrl, 'assignPrivileges'));

    $app->post('/:roleId/remove-privileges/:privilegeId', array($roleCtrl, 'removePrivileges'));
});
