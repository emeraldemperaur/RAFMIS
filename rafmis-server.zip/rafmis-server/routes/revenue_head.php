<?php
/*

*/

use Rafmis\RevenueMonitoringModule\Controllers\RevenueHeadController;

$app->group('/revenue-head', function () use ($app) {

    $revenueHeadCtrl = new RevenueHeadController();

    // List all Revenue Heads
    $app->get('/', array($revenueHeadCtrl, 'all'));

    $app->get('/export-data', array($revenueHeadCtrl, 'exportData'));

    // Get Revenue Head with id
    $app->get('/:id', array($revenueHeadCtrl, 'show'));

    // Get Revenue Head by Mda
    $app->get('/mda/:id', array($revenueHeadCtrl, 'showMda'));

    // Create Revenue Head
    $app->post('/', array($revenueHeadCtrl, 'create'));

    // Update Revenue Head with id
    $app->put('/', array($revenueHeadCtrl, 'update'));

    // Delete Revenue Head with id
    $app->delete('/:id', array($revenueHeadCtrl, 'delete'));

});
