<?php

/*

 */

use Rafmis\BeneficiaryManagementModule\Controllers\BeneficiaryCategoryAllocationController;

$app->group('/beneficiary-category-allocation', function () use ($app) {

    $beneficiaryCategoryAllocationCtrl = new BeneficiaryCategoryAllocationController();

    // List all BeneficiaryCategoryAllocations
    $app->get('/', array($beneficiaryCategoryAllocationCtrl, 'all'));

    // Get BeneficiaryCategoryAllocation with ID
    $app->get('/:id', array($beneficiaryCategoryAllocationCtrl, 'show'));

    // Get beneficiaryCategoryAllocation by BeneficiaryCategoryAllocationGroupId
    $app->get('/group/:id', array($beneficiaryCategoryAllocationCtrl, 'showGroup'));

    // Create BeneficiaryCategoryAllocation
    $app->post('/', array($beneficiaryCategoryAllocationCtrl, 'create'));

    // Create BeneficiaryCategoryAllocation
    $app->post('/addBreakdown', array($beneficiaryCategoryAllocationCtrl, 'addBreakdown'));

    // Filter and Export to CSV
    $app->post('/filterexportcsv', array($beneficiaryCategoryAllocationCtrl, 'filterCsv'));

    // Update BeneficiaryCategoryAllocation with ID
    $app->put('/:id', array($beneficiaryCategoryAllocationCtrl, 'update'));

    // Delete BeneficiaryCategoryAllocation with ID
    $app->delete('/:id', array($beneficiaryCategoryAllocationCtrl, 'delete'));

    // Delete all BeneficiaryCategoryAllocations with group ID
    $app->delete('/delete-all/:id', array($beneficiaryCategoryAllocationCtrl, 'deleteAll'));
});
