<?php
/*

*/

use Rafmis\RevenueMonitoringModule\Controllers\RevenueHeadRemittanceController;

$app->group('/revenue-head-remittance', function () use ($app) {

    $revenueHeadRemittanceCtrl = new RevenueHeadRemittanceController();

    // List all Revenue Heads
    $app->get('/', array($revenueHeadRemittanceCtrl, 'all'));

    $app->get('/export-data', array($revenueHeadRemittanceCtrl, 'exportData'));

    // Get Revenue Head with id
    $app->get('/:revenueHeadId/:mdaCode/:month/:year', array($revenueHeadRemittanceCtrl, 'show'));

    // Get Revenue Head by Mda
    $app->get('/mda/:id', array($revenueHeadRemittanceCtrl, 'showMda'));

    // Create Revenue Head
    $app->post('/', array($revenueHeadRemittanceCtrl, 'create'));

    // Update Revenue Head with id
    $app->put('/', array($revenueHeadRemittanceCtrl, 'update'));

    // Delete Revenue Head with id
    $app->delete('/:revenueHeadId/:mdaCode/:month/:year', array($revenueHeadRemittanceCtrl, 'delete'));

    $app->get('/search', array($revenueHeadRemittanceCtrl, 'searchRevenueHeadRemittance'));
});
