<?php

/*

 */

use Rafmis\UserManagementModule\Controllers\SessionTokenController;

$app->group('/sessiontoken', function () use ($app) {

    $sessiontokenCtrl = new SessionTokenController();

    // List all SessionTokens
    $app->get('/', array($sessiontokenCtrl, 'all'));

    // Get SessionToken with username
    $app->get('/:username', array($sessiontokenCtrl, 'show'));

    // Create SessionToken
    $app->post('/create', array($sessiontokenCtrl, 'create'));

    // Update SessionToken with username
    $app->put('/update', array($sessiontokenCtrl, 'update'));

    // Delete SessionToken with username
    $app->delete('/delete/:username', array($sessiontokenCtrl, 'delete'));
});
