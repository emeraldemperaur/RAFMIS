<?php
/*

*/


use Rafmis\RevenueConfigurationModule\Controllers\RevenueController;

$app->group('/revenue', function () use ($app) {
 	
    $revenueCtrl = new RevenueController();

    // List all Revenue types
    $app->get('/', array($revenueCtrl, 'all'));
        
    // Get revenue type
    $app->get('/:revenueTypeId/:month/:year', array($revenueCtrl, 'show'));
        
    // Create revenue type
    $app->post('/', array($revenueCtrl, 'create'));

    // Update revenue type
    $app->put('/', array($revenueCtrl, 'update'));

    // Delete revenue type
    $app->delete('/:revenueTypeId/:month/:year', array($revenueCtrl, 'delete'));

    $app->get('/monthly-revenue', array($revenueCtrl, 'monthlyRevenue'));
});
