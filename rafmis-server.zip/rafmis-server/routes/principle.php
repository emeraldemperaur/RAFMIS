<?php

/*

 */

use Rafmis\PrincipleManagementModule\Controllers\PrincipleController;

$app->group('/principle', function () use ($app) {

    $principleCtrl = new PrincipleController();

    // List all Principles
    $app->get('/', array($principleCtrl, 'all'));

    // Get Principles with principleId
    $app->get('/show/:principleId', array($principleCtrl, 'show'));

    // Create Principles
    $app->post('/create', array($principleCtrl, 'create'));

    // Update Principles with principleId
    $app->put('/update', array($principleCtrl, 'update'));

    // Delete Principles with principleId
    $app->delete('/:principleId', array($principleCtrl, 'delete'));

});
