<?php

/*

 */

use Rafmis\RevenueConfigurationModule\Controllers\RevenueAllocationController;

$app->group('/revneue-allocation', function () use ($app) {

    $revenueAllocationCtrl = new RevenueAllocationController();

    // List all RevenueAllocations
    $app->get('/', array($revenueAllocationCtrl, 'all'));

    // Get RevenueAllocation with ID
    $app->get('/:id', array($revenueAllocationCtrl, 'show'));

    // Create RevenueAllocation
    $app->post('/', array($revenueAllocationCtrl, 'create'));

    // Update RevenueAllocation with ID
    $app->put('/:id', array($revenueAllocationCtrl, 'update'));
    
    // Delete RevenueAllocation with ID
    $app->delete('/:id+', array($revenueAllocationCtrl, 'delete'))->name('revenue-allocation_DELETE');
    // Delete RevenueAllocation with ID
//    $app->post('/deletetwo', array($revenueAllocationCtrl, 'deleteTwo'));
});
