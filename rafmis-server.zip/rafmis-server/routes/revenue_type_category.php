<?php

/*

 */

use Rafmis\RevenueConfigurationModule\Controllers\RevenueTypeCategoryController;

$app->group('/revenue-type-category', function () use ($app) {

    $revenueTypeCategoryCtrl = new RevenueTypeCategoryController();

    // List all Revenue type categories
    $app->get('/', array($revenueTypeCategoryCtrl, 'all'));

    // Get revenue type category
    $app->get('/:revenueTypeCategoryId', array($revenueTypeCategoryCtrl, 'show'));

    // Create revenue type category
    $app->post('/', array($revenueTypeCategoryCtrl, 'create'));

    // Filter and Export to CSV
    $app->post('/filterexportcsv', array($revenueTypeCategoryCtrl, 'filterCsv'));

    // Assign revenue type category to supergroup
    $app->post('/assignToSuperGroup/:superGroupId', array($revenueTypeCategoryCtrl, 'assignToSuperGroup'));

    // Update revenue type category
    $app->put('/:revenueTypeCategoryId', array($revenueTypeCategoryCtrl, 'update'));

    // Delete revenue type category
    $app->delete('/:revenueTypeCategoryId', array($revenueTypeCategoryCtrl, 'delete'));
});
