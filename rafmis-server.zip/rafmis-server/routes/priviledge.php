<?php

/*

 */

use Rafmis\UserManagementModule\Controllers\PriviledgeController;

$app->group('/privilege', function () use ($app) {

    $privilegeCtrl = new PriviledgeController();

    // List all Priviledges
    $app->get('/', array($privilegeCtrl, 'all'));

    // Get Priviledge with priviledgeId
    $app->get('/:privilegeId', array($privilegeCtrl, 'show'));

    // Create Priviledge
    $app->post('/create', array($privilegeCtrl, 'create'));

    // Update Priviledge with priviledgeId
    $app->put('/update', array($privilegeCtrl, 'update'));

    // Delete Priviledge with priviledgeId
    $app->delete('/delete/:privilegeId', array($privilegeCtrl, 'delete'));
});
