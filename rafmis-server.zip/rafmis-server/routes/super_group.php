<?php

/*

 */

use Rafmis\RevenueConfigurationModule\Controllers\SuperGroupController;

$app->group('/super-group', function () use ($app) {

    $superGroupCtrl = new SuperGroupController();

    // List all super groups
    $app->get('/', array($superGroupCtrl, 'all'));

    // Get revenue type category
    $app->get('/:superGroupId', array($superGroupCtrl, 'show'));

    // Create revenue type category
    $app->post('/', array($superGroupCtrl, 'create'));


    // Filter and Export to CSV
    $app->post('/filterexportcsv', array($superGroupCtrl, 'filterCsv'));


    // Update revenue type category
    $app->put('/:superGroupId', array($superGroupCtrl, 'update'));

    // Delete revenue type category
    $app->delete('/:superGroupId', array($superGroupCtrl, 'delete'));
});
