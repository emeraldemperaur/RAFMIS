<?php
/*

*/

use Rafmis\RevenueMonitoringModule\Controllers\RevenueCollectionEntityController;

$app->group('/revenue-collection-entity', function () use ($app) {

    $revenueCollectionEntityCtrl = new RevenueCollectionEntityController();

    // List all RCEs
    $app->get('/', array($revenueCollectionEntityCtrl, 'all'));

    $app->get('/export-data', array($revenueCollectionEntityCtrl, 'exportData'));

    //list all RCEs with revenue head
    $app->get('/with-revenue-head', array($revenueCollectionEntityCtrl, 'allWithRevenueHead'));

    // Get RCE with mdaCode
    $app->get('/:mdaCode', array($revenueCollectionEntityCtrl, 'show'));

    // Create RCE
    $app->post('/', array($revenueCollectionEntityCtrl, 'create'));

    // Update RCE with mdaCode
    $app->put('/:mdaCode', array($revenueCollectionEntityCtrl, 'update'));

    // Delete RCE with mdaCode
    $app->delete('/:mdaCode', array($revenueCollectionEntityCtrl, 'delete'));

});
