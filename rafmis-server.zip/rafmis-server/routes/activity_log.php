<?php

/*

 */

use Rafmis\UserManagementModule\Controllers\ActivityLogController;

$app->group('/activitylog', function () use ($app) {

    $activitylogCtrl = new ActivityLogController();

    // List all ActivityLogs
    $app->get('/', array($activitylogCtrl, 'all'));

    // Get ActivityLogs with activitylogId
    $app->get('/:activitylogId', array($activitylogCtrl, 'show'));

    // Create ActivityLogs
    $app->post('/create', array($activitylogCtrl, 'create'));

    // Update ActivityLogs with activitylogId
//    $app->put('/update', array($activitylogCtrl, 'update'));

    // Delete ActivityLogs with activitylogId
//    $app->delete('/delete/:activitylogId', array($activitylogCtrl, 'delete'));

    $app->post('/search', array($activitylogCtrl, 'filterActivityLog'));
});
