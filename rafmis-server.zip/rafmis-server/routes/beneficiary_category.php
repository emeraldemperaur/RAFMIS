<?php
/*

*/

use Rafmis\BeneficiaryManagementModule\Controllers\BeneficiaryCategoryController;

$app->group('/beneficiary-category', function () use ($app) {

    $beneficiaryCategoryCtrl = new BeneficiaryCategoryController();

    // List all beneficiaryCategory
    $app->get('/', array($beneficiaryCategoryCtrl, 'all'));

    $app->get('/export-data', array($beneficiaryCategoryCtrl, 'exportData'));

    // Get beneficiaryCategoryAllocation with beneficiaryCategoryId
    $app->get('/:id', array($beneficiaryCategoryCtrl, 'show'));

    // Create beneficiaryCategory
    $app->post('/', array($beneficiaryCategoryCtrl, 'create'));

    // Update beneficiaryCategory with ID
    $app->put('/', array($beneficiaryCategoryCtrl, 'update'));

    // Delete beneficiaryCategory with ID
    $app->delete('/:id', array($beneficiaryCategoryCtrl, 'delete'));

    $app->get('/:beneficiaryCategoryId/beneficiaries', array($beneficiaryCategoryCtrl, 'findBeneficiariesByParentCategoryId'));

});
