<?php
/*

*/


use Rafmis\UtilityModule\Controllers\StateController;

$app->group('/state', function () use ($app) {
 	
    $stateCtrl = new StateController();

    // List all super groups
    $app->get('/', array($stateCtrl, 'all'));
        
    // Get revenue type category
    $app->get('/:stateId', array($stateCtrl, 'show'));
        
    // Create revenue type category
    $app->post('/', array($stateCtrl, 'create'));

    // Update revenue type category
    $app->put('/:stateId', array($stateCtrl, 'update'));

    // Delete revenue type category
    $app->delete('/:stateId', array($stateCtrl, 'delete'));
    
});
