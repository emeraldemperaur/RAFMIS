<?php

/*

 */

use Rafmis\RevenueMonitoringModule\Controllers\RevenueCollectionController;

$app->group('/revenue-collection', function () use ($app) {

    $revenueCollectionCtrl = new RevenueCollectionController();

    // List all RCs
    $app->get('/', array($revenueCollectionCtrl, 'all'));

    // Get RC with id(s)
    $app->get('/:id(s)', array($revenueCollectionCtrl, 'show'));

    // Create RC
    $app->post('/', array($revenueCollectionCtrl, 'create'));

    // Import RC
    $app->post('/importrecords', array($revenueCollectionCtrl, 'importrecords'));

    // Convert Excel to CSV
    $app->post('/converttocsv', array($revenueCollectionCtrl, 'convertExcelToCSV'));

    // Export to CSV
    $app->post('/exportcsv', array($revenueCollectionCtrl, 'exportCsv'));

    // Filter and Export to CSV
    $app->post('/filterexportcsv', array($revenueCollectionCtrl, 'filterCsv'));
    
    // Filter for chart
    $app->post('/renderchart', array($revenueCollectionCtrl, 'renderChart'));

    // Update RC with id(s)
    $app->put('/', array($revenueCollectionCtrl, 'update'));

    // Delete RC with id(s)
//    $app->delete('/:id1/:id2/:id3/:id4', array($revenueCollectionCtrl, 'delete'));
    // Delete RC with id(s)
    $app->delete('/:id1', array($revenueCollectionCtrl, 'delete'));
});
