<?php
/*

*/

use Rafmis\BeneficiaryManagementModule\Controllers\BeneficiaryController;

$app->group('/beneficiary', function () use ($app) {

    $beneficiary = new BeneficiaryController();

    // List all beneficiary
    $app->get('/', array($beneficiary, 'all'));

    $app->get('/export-data', array($beneficiary, 'exportData'));

    // Get beneficiary with beneficiaryId
    $app->get('/:id', array($beneficiary, 'show'));

    // Get beneficiary with beneficiaryCategoryId
    $app->get('/beneficiary-category/:id', array($beneficiary, 'showBeneficiaryCategory'));

    // Create beneficiary
    $app->post('/', array($beneficiary, 'create'));

    // Update beneficiary with ID
    $app->put('/', array($beneficiary, 'update'));

    // Delete beneficiary with ID
    $app->delete('/:id', array($beneficiary, 'delete'));

    $app->get('/:beneficiaryId/children', array($beneficiary, 'getBeneficiaryChildren'));
});
