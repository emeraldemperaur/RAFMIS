<?php
/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/9/2015
 * Time: 5:06 PM
 */

use Rafmis\UserManagementModule\Controllers\SecurityController;

$app->group('/auth', function () use ($app) {
	$securityCtrl = new SecurityController();

	// login logic for the user
	$app->post('/login', array($securityCtrl, 'login'));

	// logout logic for the user
	$app->get('/logout', array($securityCtrl, 'logout'));
});
