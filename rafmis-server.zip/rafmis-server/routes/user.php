<?php

/*

 */

use Rafmis\UserManagementModule\Controllers\AppUserController;

$app->group('/users', function () use ($app) {

    $userCtrl = new AppUserController();

    /// List all Users
    $app->get('/', array($userCtrl, 'all'));

    // Get Users with username
    $app->get('/:username', array($userCtrl, 'show'));

    // Create Users
    $app->post('/', array($userCtrl, 'create'));

    // Update Users with username
    $app->put('/', array($userCtrl, 'update'));

    // Delete Users with username
    $app->delete('/:username', array($userCtrl, 'delete'));

    $app->post('/send-password', array($userCtrl, 'sendPassword'));
    $app->put('/change-password', array($userCtrl, 'changePassword'));
});
