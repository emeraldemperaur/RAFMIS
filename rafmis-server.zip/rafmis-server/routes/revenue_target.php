<?php

/*

 */

use Rafmis\RevenueMonitoringModule\Controllers\RevenueTargetController;

$app->group('/revenue-target', function () use ($app) {

    $revenueTargetCtrl = new RevenueTargetController();

    // List all RevenueTargets
    $app->get('/', array($revenueTargetCtrl, 'all'));

    $app->get('/search', array($revenueTargetCtrl, 'searchRevenueTarget'));

    $app->get('/monthly-mda-performance', array($revenueTargetCtrl, 'getMonthlyRevenueCollected'));

    $app->get('/annual-mda-performance', array($revenueTargetCtrl, 'getAnnualRevenueCollected'));

    // Get RevenueTargets with revenuetargetId
    $app->get('/:Id', array($revenueTargetCtrl, 'show'));

    // Create RevenueTargets
    $app->post('/', array($revenueTargetCtrl, 'create'));
    
    // Export to CSV
    $app->post('/exportcsv', array($revenueTargetCtrl, 'exportCsv'));
       
    // Filter and Export to CSV
    $app->post('/filterexportcsv', array($revenueTargetCtrl, 'filterCsv'));
    
    // Filter for chart
    $app->post('/renderchart', array($revenueTargetCtrl, 'renderChart'));

    // Update RevenueTargets with revenuetargetId
    $app->put('/', array($revenueTargetCtrl, 'update'));

    // Delete RevenueTargets with revenuetargetId
    $app->delete('/:Id1/:Id2/:Id3', array($revenueTargetCtrl, 'delete'));
    
    // Import RT
    $app->post('/importrecords', array($revenueTargetCtrl, 'importrecords'));
});
