<?php
/*

*/

use Rafmis\RevenueMonitoringModule\Controllers\InhouseRevenueCollectionController;

$app->group('/inhouse-revenue-collection', function () use ($app) {

    $inhouseRevenueCollectionCtrl = new InhouseRevenueCollectionController();

    // List all RCs
    $app->get('/', array($inhouseRevenueCollectionCtrl, 'all'));

    // Get RC with id(s)
    $app->get('/:id(s)', array($inhouseRevenueCollectionCtrl, 'show'));

    // Create RC
    $app->post('/', array($inhouseRevenueCollectionCtrl, 'create'));

    // Import RC
    $app->post('/importrecords', array($inhouseRevenueCollectionCtrl, 'importrecords'));
    
    // Convert Excel to CSV
    $app->post('/converttocsv', array($inhouseRevenueCollectionCtrl, 'convertExcelToCSV'));
    
    // Filter and Export to CSV
    $app->post('/filterexportcsv', array($inhouseRevenueCollectionCtrl, 'filterCsv'));

    // Filter for chart
    $app->post('/renderchart', array($inhouseRevenueCollectionCtrl, 'renderChart'));

    // Update RC with id(s)
    $app->put('/', array($inhouseRevenueCollectionCtrl, 'update'));

    // Delete RC with id(s)
    $app->delete('/:id1', array($inhouseRevenueCollectionCtrl, 'delete'));

});
