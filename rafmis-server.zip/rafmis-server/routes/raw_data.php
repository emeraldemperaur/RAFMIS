<?php

/*

 */

use Rafmis\PrincipleManagementModule\Controllers\RawDataController;

$app->group('/rawdata', function () use ($app) {

    $rawDataCtrl = new RawDataController();

    // List all RawDatas
    $app->get('/', array($rawDataCtrl, 'all'));

    // Get RawDatas with rawDataId
    $app->get('/show/:principleItemId/:beneficiaryId', array($rawDataCtrl, 'show'));

     // Get RawDatas with rawDataId
    $app->get('/principle-item/:principleItemId', array($rawDataCtrl, 'showByPrincipleItem'));

     // Get RawDatas with benefidicayCategoryId
    $app->get('/beneficiary-category/:principleItemId/:beneficiaryCategoryId', array($rawDataCtrl, 'showByBeneficiaryCategory'));

     // Get RawDatas with beneficiary->ParentId
    $app->get('/beneficiary/parent/:principleItemId/:beneficiaryId', array($rawDataCtrl, 'showByBeneficiaryParent'));
    
     // Get RawDatas 
    $app->post('/specific', array($rawDataCtrl, 'findRawDataBySpecifics'));

    // Create RawData
    $app->post('/create', array($rawDataCtrl, 'create'));

    // Create Multiple RawDatas
    $app->post('/create-multiple', array($rawDataCtrl, 'createMultiple'));

    // Update RawDatas with rawDataId
    $app->put('/update', array($rawDataCtrl, 'update'));

    // Delete RawDatas with rawDataId
    $app->delete('/delete/:principleItemId', array($rawDataCtrl, 'delete'));
});
