<?php

/*

 */

use Rafmis\PaymentScheduleManagementModule\Controllers\BeneficiaryIndexController;

$app->group('/beneficiary-index', function () use ($app) {

    $beneficiaryIndexCtrl = new BeneficiaryIndexController();

// List all Beneficiary Indexs
    $app->get('/', array($beneficiaryIndexCtrl, 'all'));

// Get Beneficiary Index using BeneficiaryId
    $app->get('/beneficiary/:id', array($beneficiaryIndexCtrl, 'showBeneficiary'));

// Get Beneficiary Index using PrincipleItemId
    $app->get('/principle-item/:id', array($beneficiaryIndexCtrl, 'showPrincipleItem'));

// Create Beneficiary Index
    $app->post('/', array($beneficiaryIndexCtrl, 'create'));

// Check Beneficiary Index
    $app->post('/indexexists', array($beneficiaryIndexCtrl, 'indexexists'));


    // Update Beneficiary Index with id
    $app->put('/:id', array($beneficiaryIndexCtrl, 'update'));

    // Delete Beneficiary Index with id
    $app->delete('/:id', array($beneficiaryIndexCtrl, 'delete'));

    // Delete Schedule with id
    $app->delete('/:id1/:id2', array($beneficiaryIndexCtrl, 'deleteIndices'));
});
