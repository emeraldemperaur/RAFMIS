<?php
/*

*/

use Rafmis\RevenueMonitoringModule\Controllers\RevenueHeadCollectionController;

$app->group('/revenue-head-collection', function () use ($app) {

    $revenueHeadCollectionCtrl = new RevenueHeadCollectionController();

    // List all Revenue Heads
    $app->get('/', array($revenueHeadCollectionCtrl, 'all'));

    $app->get('/export-data', array($revenueHeadCollectionCtrl, 'exportData'));

    // Get Revenue Head with id
    $app->get('/:RevenueHeadId/:MdaCode/:PaymentPeriodMonth/:PaymentPeriodYear', array($revenueHeadCollectionCtrl, 'show'));

    // Get Revenue Head by Mda
    $app->get('/mda/:id', array($revenueHeadCollectionCtrl, 'showMda'));

    // Create Revenue Head
    $app->post('/', array($revenueHeadCollectionCtrl, 'create'));

    // Update Revenue Head with id
    $app->put('/', array($revenueHeadCollectionCtrl, 'update'));

    // Delete Revenue Head with id
    $app->delete('/:RevenueHeadId/:MdaCode/:PaymentPeriodMonth/:PaymentPeriodYear', array($revenueHeadCollectionCtrl, 'delete'));

    $app->get('/monthly/:year', array($revenueHeadCollectionCtrl, 'monthlyRevenueHeadCollection'));

    $app->get('/search', array($revenueHeadCollectionCtrl, 'searchRevenueHeadCollection'));

    $app->get('/monthly-revenue-collected', array($revenueHeadCollectionCtrl, 'getMonthlyRevenueCollected'));
});
