<?php

/*

 */

use Rafmis\PrincipleManagementModule\Controllers\PrincipleItemController;

$app->group('/principle-item', function () use ($app) {

    $principleItemCtrl = new PrincipleItemController();

    // List all PrincipleItems
    $app->get('/', array($principleItemCtrl, 'all'));

    // Get PrincipleItems with principleItemId
    $app->get('/:principleItemId', array($principleItemCtrl, 'show'));

    // Get PrincipleItems with principleId
    $app->get('/principle/:principleId', array($principleItemCtrl, 'showPrinciple'));

    // Create PrincipleItems
    $app->post('/create', array($principleItemCtrl, 'create'));

    // Create Multiple PrincipleItems at once
    $app->post('/create-multiple', array($principleItemCtrl, 'createMultiple'));

    // Update PrincipleItems with principleItemId
    $app->put('/update', array($principleItemCtrl, 'update'));

    // Delete PrincipleItems with principleItemId
    $app->delete('/principle/:principleId', array($principleItemCtrl, 'delete'));

});
