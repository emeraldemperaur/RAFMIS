<?php
/*

*/

use Rafmis\PaymentScheduleManagementModule\Controllers\ScheduleDisbursementController;

$app->group('/schedule-disbursement', function () use ($app) {

    $scheduleDisbursementCtrl = new ScheduleDisbursementController();

    // List all Schedules
    $app->get('/', array($scheduleDisbursementCtrl, 'all'));

    // Get Schedule using BeneficiaryId
    $app->get('/beneficiary/:id', array($scheduleDisbursementCtrl, 'showBeneficiary'));

    // Get Schedule using PrincipleItemId
    $app->get('/principle-item/:id', array($scheduleDisbursementCtrl, 'showPrincipleItem'));

    // Get Schedule by Month
    $app->get('/month/:id', array($scheduleDisbursementCtrl, 'showMonth'));

    // Get Schedule by Year
    $app->get('/year/:id', array($scheduleDisbursementCtrl, 'showYear'));

    // Create Schedule
    $app->post('/', array($scheduleDisbursementCtrl, 'create'));

    // Generate Schedule
    $app->post('/generate/', array($scheduleDisbursementCtrl, 'generate'));

    // Generate Indices
    $app->post('/generateIndex/', array($scheduleDisbursementCtrl, 'generateIndex'));
    
    // Generate Indices
    $app->post('/generateIndex2/', array($scheduleDisbursementCtrl, 'generateIndex2'));

    // Generate Payment Schedule
    $app->post('/generatePayment/', array($scheduleDisbursementCtrl, 'generatePayment'));

    // Generate Indices
//    $app->post('/generateIndex/', array($scheduleDisbursementCtrl, 'generateIndex'));PRI_SCHEDULE_GENERATEPAYMENT

    // Save Payment
    $app->post('/savepayment/', array($scheduleDisbursementCtrl, 'savePayment'));

    // Save Indices
    $app->post('/saveindices/', array($scheduleDisbursementCtrl, 'saveIndices'));

    // Save Indices
    $app->post('/scheduleexists/', array($scheduleDisbursementCtrl, 'scheduleexists'));

    // Update Revenue Disbursment
//    $app->post('/disbursment/', array($scheduleDisbursementCtrl, 'disbursement'));

    // Update Schedule with id
    $app->put('/', array($scheduleDisbursementCtrl, 'update'));
//    $app->put('/:id', array($scheduleDisbursementCtrl, 'update'));

    // Update Schedule with id
    $app->put('/update-multiple', array($scheduleDisbursementCtrl, 'updateMultiple'));

    // Delete Schedule with id
    $app->delete('/:id', array($scheduleDisbursementCtrl, 'delete'));

    // Delete Schedule with id
    $app->delete('/:id1/:id2/:id3/:id4', array($scheduleDisbursementCtrl, 'deletePayment'));
    
    // Delete Schedule with id
    $app->delete('/:id1/:id2/:id3/:id5/:id6', array($scheduleDisbursementCtrl, 'deleteDisbursement'));

    // Import RC
    $app->post('/importrecords', array($scheduleDisbursementCtrl, 'importrecords'));
    
    // Convert Excel to CSV
    $app->post('/converttocsv', array($scheduleDisbursementCtrl, 'convertExcelToCSV'));
    
    // Convert Excel to CSV
    $app->post('/revenuedisbursementgrid', array($scheduleDisbursementCtrl, 'revenueDisbursementGrid'));

});
