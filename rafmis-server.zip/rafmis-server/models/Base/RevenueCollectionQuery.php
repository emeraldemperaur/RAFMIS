<?php

namespace Base;

use \RevenueCollection as ChildRevenueCollection;
use \RevenueCollectionQuery as ChildRevenueCollectionQuery;
use \Exception;
use \PDO;
use Map\RevenueCollectionTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'revenue_collection' table.
 *
 * 
 *
 * @method     ChildRevenueCollectionQuery orderByRevenueCollectionId($order = Criteria::ASC) Order by the revenue_collection_id column
 * @method     ChildRevenueCollectionQuery orderByRevenueHeadId($order = Criteria::ASC) Order by the revenue_head_id column
 * @method     ChildRevenueCollectionQuery orderByMdaCode($order = Criteria::ASC) Order by the mda_code column
 * @method     ChildRevenueCollectionQuery orderByExpectedPaymentMonth($order = Criteria::ASC) Order by the expected_payment_month column
 * @method     ChildRevenueCollectionQuery orderByExpectedPaymentYear($order = Criteria::ASC) Order by the expected_payment_year column
 * @method     ChildRevenueCollectionQuery orderByAmount($order = Criteria::ASC) Order by the amount column
 * @method     ChildRevenueCollectionQuery orderByState($order = Criteria::ASC) Order by the state column
 * @method     ChildRevenueCollectionQuery orderByPayerName($order = Criteria::ASC) Order by the payer_name column
 * @method     ChildRevenueCollectionQuery orderByRcNumber($order = Criteria::ASC) Order by the rc_number column
 * @method     ChildRevenueCollectionQuery orderBySourceId($order = Criteria::ASC) Order by the source_id column
 * @method     ChildRevenueCollectionQuery orderByTinNumber($order = Criteria::ASC) Order by the tin_number column
 * @method     ChildRevenueCollectionQuery orderByPaymentDate($order = Criteria::ASC) Order by the payment_date column
 * @method     ChildRevenueCollectionQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method     ChildRevenueCollectionQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method     ChildRevenueCollectionQuery orderByDateModified($order = Criteria::ASC) Order by the date_modified column
 * @method     ChildRevenueCollectionQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method     ChildRevenueCollectionQuery groupByRevenueCollectionId() Group by the revenue_collection_id column
 * @method     ChildRevenueCollectionQuery groupByRevenueHeadId() Group by the revenue_head_id column
 * @method     ChildRevenueCollectionQuery groupByMdaCode() Group by the mda_code column
 * @method     ChildRevenueCollectionQuery groupByExpectedPaymentMonth() Group by the expected_payment_month column
 * @method     ChildRevenueCollectionQuery groupByExpectedPaymentYear() Group by the expected_payment_year column
 * @method     ChildRevenueCollectionQuery groupByAmount() Group by the amount column
 * @method     ChildRevenueCollectionQuery groupByState() Group by the state column
 * @method     ChildRevenueCollectionQuery groupByPayerName() Group by the payer_name column
 * @method     ChildRevenueCollectionQuery groupByRcNumber() Group by the rc_number column
 * @method     ChildRevenueCollectionQuery groupBySourceId() Group by the source_id column
 * @method     ChildRevenueCollectionQuery groupByTinNumber() Group by the tin_number column
 * @method     ChildRevenueCollectionQuery groupByPaymentDate() Group by the payment_date column
 * @method     ChildRevenueCollectionQuery groupByDateCreated() Group by the date_created column
 * @method     ChildRevenueCollectionQuery groupByCreatedBy() Group by the created_by column
 * @method     ChildRevenueCollectionQuery groupByDateModified() Group by the date_modified column
 * @method     ChildRevenueCollectionQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method     ChildRevenueCollectionQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildRevenueCollectionQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildRevenueCollectionQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildRevenueCollectionQuery leftJoinRevenueHead($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueHead relation
 * @method     ChildRevenueCollectionQuery rightJoinRevenueHead($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueHead relation
 * @method     ChildRevenueCollectionQuery innerJoinRevenueHead($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueHead relation
 *
 * @method     ChildRevenueCollectionQuery leftJoinRevenueCollectionEntity($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueCollectionEntity relation
 * @method     ChildRevenueCollectionQuery rightJoinRevenueCollectionEntity($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueCollectionEntity relation
 * @method     ChildRevenueCollectionQuery innerJoinRevenueCollectionEntity($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueCollectionEntity relation
 *
 * @method     \RevenueHeadQuery|\RevenueCollectionEntityQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildRevenueCollection findOne(ConnectionInterface $con = null) Return the first ChildRevenueCollection matching the query
 * @method     ChildRevenueCollection findOneOrCreate(ConnectionInterface $con = null) Return the first ChildRevenueCollection matching the query, or a new ChildRevenueCollection object populated from the query conditions when no match is found
 *
 * @method     ChildRevenueCollection findOneByRevenueCollectionId(int $revenue_collection_id) Return the first ChildRevenueCollection filtered by the revenue_collection_id column
 * @method     ChildRevenueCollection findOneByRevenueHeadId(string $revenue_head_id) Return the first ChildRevenueCollection filtered by the revenue_head_id column
 * @method     ChildRevenueCollection findOneByMdaCode(string $mda_code) Return the first ChildRevenueCollection filtered by the mda_code column
 * @method     ChildRevenueCollection findOneByExpectedPaymentMonth(int $expected_payment_month) Return the first ChildRevenueCollection filtered by the expected_payment_month column
 * @method     ChildRevenueCollection findOneByExpectedPaymentYear(int $expected_payment_year) Return the first ChildRevenueCollection filtered by the expected_payment_year column
 * @method     ChildRevenueCollection findOneByAmount(double $amount) Return the first ChildRevenueCollection filtered by the amount column
 * @method     ChildRevenueCollection findOneByState(string $state) Return the first ChildRevenueCollection filtered by the state column
 * @method     ChildRevenueCollection findOneByPayerName(string $payer_name) Return the first ChildRevenueCollection filtered by the payer_name column
 * @method     ChildRevenueCollection findOneByRcNumber(string $rc_number) Return the first ChildRevenueCollection filtered by the rc_number column
 * @method     ChildRevenueCollection findOneBySourceId(string $source_id) Return the first ChildRevenueCollection filtered by the source_id column
 * @method     ChildRevenueCollection findOneByTinNumber(string $tin_number) Return the first ChildRevenueCollection filtered by the tin_number column
 * @method     ChildRevenueCollection findOneByPaymentDate(string $payment_date) Return the first ChildRevenueCollection filtered by the payment_date column
 * @method     ChildRevenueCollection findOneByDateCreated(string $date_created) Return the first ChildRevenueCollection filtered by the date_created column
 * @method     ChildRevenueCollection findOneByCreatedBy(string $created_by) Return the first ChildRevenueCollection filtered by the created_by column
 * @method     ChildRevenueCollection findOneByDateModified(string $date_modified) Return the first ChildRevenueCollection filtered by the date_modified column
 * @method     ChildRevenueCollection findOneByModifiedBy(string $modified_by) Return the first ChildRevenueCollection filtered by the modified_by column *

 * @method     ChildRevenueCollection requirePk($key, ConnectionInterface $con = null) Return the ChildRevenueCollection by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOne(ConnectionInterface $con = null) Return the first ChildRevenueCollection matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildRevenueCollection requireOneByRevenueCollectionId(int $revenue_collection_id) Return the first ChildRevenueCollection filtered by the revenue_collection_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByRevenueHeadId(string $revenue_head_id) Return the first ChildRevenueCollection filtered by the revenue_head_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByMdaCode(string $mda_code) Return the first ChildRevenueCollection filtered by the mda_code column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByExpectedPaymentMonth(int $expected_payment_month) Return the first ChildRevenueCollection filtered by the expected_payment_month column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByExpectedPaymentYear(int $expected_payment_year) Return the first ChildRevenueCollection filtered by the expected_payment_year column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByAmount(double $amount) Return the first ChildRevenueCollection filtered by the amount column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByState(string $state) Return the first ChildRevenueCollection filtered by the state column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByPayerName(string $payer_name) Return the first ChildRevenueCollection filtered by the payer_name column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByRcNumber(string $rc_number) Return the first ChildRevenueCollection filtered by the rc_number column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneBySourceId(string $source_id) Return the first ChildRevenueCollection filtered by the source_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByTinNumber(string $tin_number) Return the first ChildRevenueCollection filtered by the tin_number column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByPaymentDate(string $payment_date) Return the first ChildRevenueCollection filtered by the payment_date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByDateCreated(string $date_created) Return the first ChildRevenueCollection filtered by the date_created column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByCreatedBy(string $created_by) Return the first ChildRevenueCollection filtered by the created_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByDateModified(string $date_modified) Return the first ChildRevenueCollection filtered by the date_modified column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollection requireOneByModifiedBy(string $modified_by) Return the first ChildRevenueCollection filtered by the modified_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildRevenueCollection[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildRevenueCollection objects based on current ModelCriteria
 * @method     ChildRevenueCollection[]|ObjectCollection findByRevenueCollectionId(int $revenue_collection_id) Return ChildRevenueCollection objects filtered by the revenue_collection_id column
 * @method     ChildRevenueCollection[]|ObjectCollection findByRevenueHeadId(string $revenue_head_id) Return ChildRevenueCollection objects filtered by the revenue_head_id column
 * @method     ChildRevenueCollection[]|ObjectCollection findByMdaCode(string $mda_code) Return ChildRevenueCollection objects filtered by the mda_code column
 * @method     ChildRevenueCollection[]|ObjectCollection findByExpectedPaymentMonth(int $expected_payment_month) Return ChildRevenueCollection objects filtered by the expected_payment_month column
 * @method     ChildRevenueCollection[]|ObjectCollection findByExpectedPaymentYear(int $expected_payment_year) Return ChildRevenueCollection objects filtered by the expected_payment_year column
 * @method     ChildRevenueCollection[]|ObjectCollection findByAmount(double $amount) Return ChildRevenueCollection objects filtered by the amount column
 * @method     ChildRevenueCollection[]|ObjectCollection findByState(string $state) Return ChildRevenueCollection objects filtered by the state column
 * @method     ChildRevenueCollection[]|ObjectCollection findByPayerName(string $payer_name) Return ChildRevenueCollection objects filtered by the payer_name column
 * @method     ChildRevenueCollection[]|ObjectCollection findByRcNumber(string $rc_number) Return ChildRevenueCollection objects filtered by the rc_number column
 * @method     ChildRevenueCollection[]|ObjectCollection findBySourceId(string $source_id) Return ChildRevenueCollection objects filtered by the source_id column
 * @method     ChildRevenueCollection[]|ObjectCollection findByTinNumber(string $tin_number) Return ChildRevenueCollection objects filtered by the tin_number column
 * @method     ChildRevenueCollection[]|ObjectCollection findByPaymentDate(string $payment_date) Return ChildRevenueCollection objects filtered by the payment_date column
 * @method     ChildRevenueCollection[]|ObjectCollection findByDateCreated(string $date_created) Return ChildRevenueCollection objects filtered by the date_created column
 * @method     ChildRevenueCollection[]|ObjectCollection findByCreatedBy(string $created_by) Return ChildRevenueCollection objects filtered by the created_by column
 * @method     ChildRevenueCollection[]|ObjectCollection findByDateModified(string $date_modified) Return ChildRevenueCollection objects filtered by the date_modified column
 * @method     ChildRevenueCollection[]|ObjectCollection findByModifiedBy(string $modified_by) Return ChildRevenueCollection objects filtered by the modified_by column
 * @method     ChildRevenueCollection[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class RevenueCollectionQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Base\RevenueCollectionQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'rafmis', $modelName = '\\RevenueCollection', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildRevenueCollectionQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildRevenueCollectionQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildRevenueCollectionQuery) {
            return $criteria;
        }
        $query = new ChildRevenueCollectionQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildRevenueCollection|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = RevenueCollectionTableMap::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(RevenueCollectionTableMap::DATABASE_NAME);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenueCollection A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT revenue_collection_id, revenue_head_id, mda_code, expected_payment_month, expected_payment_year, amount, state, payer_name, rc_number, source_id, tin_number, payment_date, date_created, created_by, date_modified, modified_by FROM revenue_collection WHERE revenue_collection_id = :p0';
        try {
            $stmt = $con->prepare($sql);            
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildRevenueCollection $obj */
            $obj = new ChildRevenueCollection();
            $obj->hydrate($row);
            RevenueCollectionTableMap::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildRevenueCollection|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_REVENUE_COLLECTION_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_REVENUE_COLLECTION_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the revenue_collection_id column
     *
     * Example usage:
     * <code>
     * $query->filterByRevenueCollectionId(1234); // WHERE revenue_collection_id = 1234
     * $query->filterByRevenueCollectionId(array(12, 34)); // WHERE revenue_collection_id IN (12, 34)
     * $query->filterByRevenueCollectionId(array('min' => 12)); // WHERE revenue_collection_id > 12
     * </code>
     *
     * @param     mixed $revenueCollectionId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByRevenueCollectionId($revenueCollectionId = null, $comparison = null)
    {
        if (is_array($revenueCollectionId)) {
            $useMinMax = false;
            if (isset($revenueCollectionId['min'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_REVENUE_COLLECTION_ID, $revenueCollectionId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($revenueCollectionId['max'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_REVENUE_COLLECTION_ID, $revenueCollectionId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_REVENUE_COLLECTION_ID, $revenueCollectionId, $comparison);
    }

    /**
     * Filter the query on the revenue_head_id column
     *
     * Example usage:
     * <code>
     * $query->filterByRevenueHeadId('fooValue');   // WHERE revenue_head_id = 'fooValue'
     * $query->filterByRevenueHeadId('%fooValue%'); // WHERE revenue_head_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $revenueHeadId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByRevenueHeadId($revenueHeadId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($revenueHeadId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $revenueHeadId)) {
                $revenueHeadId = str_replace('*', '%', $revenueHeadId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_REVENUE_HEAD_ID, $revenueHeadId, $comparison);
    }

    /**
     * Filter the query on the mda_code column
     *
     * Example usage:
     * <code>
     * $query->filterByMdaCode('fooValue');   // WHERE mda_code = 'fooValue'
     * $query->filterByMdaCode('%fooValue%'); // WHERE mda_code LIKE '%fooValue%'
     * </code>
     *
     * @param     string $mdaCode The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByMdaCode($mdaCode = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($mdaCode)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $mdaCode)) {
                $mdaCode = str_replace('*', '%', $mdaCode);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_MDA_CODE, $mdaCode, $comparison);
    }

    /**
     * Filter the query on the expected_payment_month column
     *
     * Example usage:
     * <code>
     * $query->filterByExpectedPaymentMonth(1234); // WHERE expected_payment_month = 1234
     * $query->filterByExpectedPaymentMonth(array(12, 34)); // WHERE expected_payment_month IN (12, 34)
     * $query->filterByExpectedPaymentMonth(array('min' => 12)); // WHERE expected_payment_month > 12
     * </code>
     *
     * @param     mixed $expectedPaymentMonth The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByExpectedPaymentMonth($expectedPaymentMonth = null, $comparison = null)
    {
        if (is_array($expectedPaymentMonth)) {
            $useMinMax = false;
            if (isset($expectedPaymentMonth['min'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_EXPECTED_PAYMENT_MONTH, $expectedPaymentMonth['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($expectedPaymentMonth['max'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_EXPECTED_PAYMENT_MONTH, $expectedPaymentMonth['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_EXPECTED_PAYMENT_MONTH, $expectedPaymentMonth, $comparison);
    }

    /**
     * Filter the query on the expected_payment_year column
     *
     * Example usage:
     * <code>
     * $query->filterByExpectedPaymentYear(1234); // WHERE expected_payment_year = 1234
     * $query->filterByExpectedPaymentYear(array(12, 34)); // WHERE expected_payment_year IN (12, 34)
     * $query->filterByExpectedPaymentYear(array('min' => 12)); // WHERE expected_payment_year > 12
     * </code>
     *
     * @param     mixed $expectedPaymentYear The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByExpectedPaymentYear($expectedPaymentYear = null, $comparison = null)
    {
        if (is_array($expectedPaymentYear)) {
            $useMinMax = false;
            if (isset($expectedPaymentYear['min'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_EXPECTED_PAYMENT_YEAR, $expectedPaymentYear['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($expectedPaymentYear['max'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_EXPECTED_PAYMENT_YEAR, $expectedPaymentYear['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_EXPECTED_PAYMENT_YEAR, $expectedPaymentYear, $comparison);
    }

    /**
     * Filter the query on the amount column
     *
     * Example usage:
     * <code>
     * $query->filterByAmount(1234); // WHERE amount = 1234
     * $query->filterByAmount(array(12, 34)); // WHERE amount IN (12, 34)
     * $query->filterByAmount(array('min' => 12)); // WHERE amount > 12
     * </code>
     *
     * @param     mixed $amount The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByAmount($amount = null, $comparison = null)
    {
        if (is_array($amount)) {
            $useMinMax = false;
            if (isset($amount['min'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_AMOUNT, $amount['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($amount['max'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_AMOUNT, $amount['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_AMOUNT, $amount, $comparison);
    }

    /**
     * Filter the query on the state column
     *
     * Example usage:
     * <code>
     * $query->filterByState('fooValue');   // WHERE state = 'fooValue'
     * $query->filterByState('%fooValue%'); // WHERE state LIKE '%fooValue%'
     * </code>
     *
     * @param     string $state The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByState($state = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($state)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $state)) {
                $state = str_replace('*', '%', $state);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_STATE, $state, $comparison);
    }

    /**
     * Filter the query on the payer_name column
     *
     * Example usage:
     * <code>
     * $query->filterByPayerName('fooValue');   // WHERE payer_name = 'fooValue'
     * $query->filterByPayerName('%fooValue%'); // WHERE payer_name LIKE '%fooValue%'
     * </code>
     *
     * @param     string $payerName The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByPayerName($payerName = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($payerName)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $payerName)) {
                $payerName = str_replace('*', '%', $payerName);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_PAYER_NAME, $payerName, $comparison);
    }

    /**
     * Filter the query on the rc_number column
     *
     * Example usage:
     * <code>
     * $query->filterByRcNumber('fooValue');   // WHERE rc_number = 'fooValue'
     * $query->filterByRcNumber('%fooValue%'); // WHERE rc_number LIKE '%fooValue%'
     * </code>
     *
     * @param     string $rcNumber The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByRcNumber($rcNumber = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($rcNumber)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $rcNumber)) {
                $rcNumber = str_replace('*', '%', $rcNumber);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_RC_NUMBER, $rcNumber, $comparison);
    }

    /**
     * Filter the query on the source_id column
     *
     * Example usage:
     * <code>
     * $query->filterBySourceId('fooValue');   // WHERE source_id = 'fooValue'
     * $query->filterBySourceId('%fooValue%'); // WHERE source_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $sourceId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterBySourceId($sourceId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($sourceId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $sourceId)) {
                $sourceId = str_replace('*', '%', $sourceId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_SOURCE_ID, $sourceId, $comparison);
    }

    /**
     * Filter the query on the tin_number column
     *
     * Example usage:
     * <code>
     * $query->filterByTinNumber('fooValue');   // WHERE tin_number = 'fooValue'
     * $query->filterByTinNumber('%fooValue%'); // WHERE tin_number LIKE '%fooValue%'
     * </code>
     *
     * @param     string $tinNumber The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByTinNumber($tinNumber = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($tinNumber)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $tinNumber)) {
                $tinNumber = str_replace('*', '%', $tinNumber);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_TIN_NUMBER, $tinNumber, $comparison);
    }

    /**
     * Filter the query on the payment_date column
     *
     * Example usage:
     * <code>
     * $query->filterByPaymentDate('2011-03-14'); // WHERE payment_date = '2011-03-14'
     * $query->filterByPaymentDate('now'); // WHERE payment_date = '2011-03-14'
     * $query->filterByPaymentDate(array('max' => 'yesterday')); // WHERE payment_date > '2011-03-13'
     * </code>
     *
     * @param     mixed $paymentDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByPaymentDate($paymentDate = null, $comparison = null)
    {
        if (is_array($paymentDate)) {
            $useMinMax = false;
            if (isset($paymentDate['min'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_PAYMENT_DATE, $paymentDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($paymentDate['max'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_PAYMENT_DATE, $paymentDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_PAYMENT_DATE, $paymentDate, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy('fooValue');   // WHERE created_by = 'fooValue'
     * $query->filterByCreatedBy('%fooValue%'); // WHERE created_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $createdBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($createdBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $createdBy)) {
                $createdBy = str_replace('*', '%', $createdBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the date_modified column
     *
     * Example usage:
     * <code>
     * $query->filterByDateModified('2011-03-14'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified('now'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified(array('max' => 'yesterday')); // WHERE date_modified > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateModified The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByDateModified($dateModified = null, $comparison = null)
    {
        if (is_array($dateModified)) {
            $useMinMax = false;
            if (isset($dateModified['min'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_DATE_MODIFIED, $dateModified['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateModified['max'])) {
                $this->addUsingAlias(RevenueCollectionTableMap::COL_DATE_MODIFIED, $dateModified['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_DATE_MODIFIED, $dateModified, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy('fooValue');   // WHERE modified_by = 'fooValue'
     * $query->filterByModifiedBy('%fooValue%'); // WHERE modified_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $modifiedBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($modifiedBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $modifiedBy)) {
                $modifiedBy = str_replace('*', '%', $modifiedBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueCollectionTableMap::COL_MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related \RevenueHead object
     *
     * @param \RevenueHead|ObjectCollection $revenueHead The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByRevenueHead($revenueHead, $comparison = null)
    {
        if ($revenueHead instanceof \RevenueHead) {
            return $this
                ->addUsingAlias(RevenueCollectionTableMap::COL_REVENUE_HEAD_ID, $revenueHead->getRevenueHeadId(), $comparison);
        } elseif ($revenueHead instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(RevenueCollectionTableMap::COL_REVENUE_HEAD_ID, $revenueHead->toKeyValue('PrimaryKey', 'RevenueHeadId'), $comparison);
        } else {
            throw new PropelException('filterByRevenueHead() only accepts arguments of type \RevenueHead or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueHead relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function joinRevenueHead($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueHead');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueHead');
        }

        return $this;
    }

    /**
     * Use the RevenueHead relation RevenueHead object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueHeadQuery A secondary query class using the current class as primary query
     */
    public function useRevenueHeadQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueHead($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueHead', '\RevenueHeadQuery');
    }

    /**
     * Filter the query by a related \RevenueCollectionEntity object
     *
     * @param \RevenueCollectionEntity|ObjectCollection $revenueCollectionEntity The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByRevenueCollectionEntity($revenueCollectionEntity, $comparison = null)
    {
        if ($revenueCollectionEntity instanceof \RevenueCollectionEntity) {
            return $this
                ->addUsingAlias(RevenueCollectionTableMap::COL_MDA_CODE, $revenueCollectionEntity->getMdaCode(), $comparison);
        } elseif ($revenueCollectionEntity instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(RevenueCollectionTableMap::COL_MDA_CODE, $revenueCollectionEntity->toKeyValue('PrimaryKey', 'MdaCode'), $comparison);
        } else {
            throw new PropelException('filterByRevenueCollectionEntity() only accepts arguments of type \RevenueCollectionEntity or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueCollectionEntity relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function joinRevenueCollectionEntity($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueCollectionEntity');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueCollectionEntity');
        }

        return $this;
    }

    /**
     * Use the RevenueCollectionEntity relation RevenueCollectionEntity object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueCollectionEntityQuery A secondary query class using the current class as primary query
     */
    public function useRevenueCollectionEntityQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueCollectionEntity($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueCollectionEntity', '\RevenueCollectionEntityQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   ChildRevenueCollection $revenueCollection Object to remove from the list of results
     *
     * @return $this|ChildRevenueCollectionQuery The current query, for fluid interface
     */
    public function prune($revenueCollection = null)
    {
        if ($revenueCollection) {
            $this->addUsingAlias(RevenueCollectionTableMap::COL_REVENUE_COLLECTION_ID, $revenueCollection->getRevenueCollectionId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the revenue_collection table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RevenueCollectionTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            RevenueCollectionTableMap::clearInstancePool();
            RevenueCollectionTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RevenueCollectionTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(RevenueCollectionTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            
            RevenueCollectionTableMap::removeInstanceFromPool($criteria);
        
            $affectedRows += ModelCriteria::delete($con);
            RevenueCollectionTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // RevenueCollectionQuery
