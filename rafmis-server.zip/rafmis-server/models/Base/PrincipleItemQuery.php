<?php

namespace Base;

use \PrincipleItem as ChildPrincipleItem;
use \PrincipleItemQuery as ChildPrincipleItemQuery;
use \Exception;
use \PDO;
use Map\PrincipleItemTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'principle_item' table.
 *
 * 
 *
 * @method     ChildPrincipleItemQuery orderByPrincipleItemId($order = Criteria::ASC) Order by the principle_item_id column
 * @method     ChildPrincipleItemQuery orderByPrincipleItemName($order = Criteria::ASC) Order by the principle_item_name column
 * @method     ChildPrincipleItemQuery orderByPrincipleId($order = Criteria::ASC) Order by the principle_id column
 * @method     ChildPrincipleItemQuery orderByBeneficiaryCategoryId($order = Criteria::ASC) Order by the beneficiary_category_id column
 * @method     ChildPrincipleItemQuery orderByIsEqual($order = Criteria::ASC) Order by the is_equal column
 * @method     ChildPrincipleItemQuery orderByPercentageAllocation($order = Criteria::ASC) Order by the percentage_allocation column
 * @method     ChildPrincipleItemQuery orderByParentId($order = Criteria::ASC) Order by the parent_id column
 * @method     ChildPrincipleItemQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method     ChildPrincipleItemQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method     ChildPrincipleItemQuery orderByDateModified($order = Criteria::ASC) Order by the date_modified column
 * @method     ChildPrincipleItemQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method     ChildPrincipleItemQuery groupByPrincipleItemId() Group by the principle_item_id column
 * @method     ChildPrincipleItemQuery groupByPrincipleItemName() Group by the principle_item_name column
 * @method     ChildPrincipleItemQuery groupByPrincipleId() Group by the principle_id column
 * @method     ChildPrincipleItemQuery groupByBeneficiaryCategoryId() Group by the beneficiary_category_id column
 * @method     ChildPrincipleItemQuery groupByIsEqual() Group by the is_equal column
 * @method     ChildPrincipleItemQuery groupByPercentageAllocation() Group by the percentage_allocation column
 * @method     ChildPrincipleItemQuery groupByParentId() Group by the parent_id column
 * @method     ChildPrincipleItemQuery groupByDateCreated() Group by the date_created column
 * @method     ChildPrincipleItemQuery groupByCreatedBy() Group by the created_by column
 * @method     ChildPrincipleItemQuery groupByDateModified() Group by the date_modified column
 * @method     ChildPrincipleItemQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method     ChildPrincipleItemQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildPrincipleItemQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildPrincipleItemQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildPrincipleItemQuery leftJoinBeneficiaryCategory($relationAlias = null) Adds a LEFT JOIN clause to the query using the BeneficiaryCategory relation
 * @method     ChildPrincipleItemQuery rightJoinBeneficiaryCategory($relationAlias = null) Adds a RIGHT JOIN clause to the query using the BeneficiaryCategory relation
 * @method     ChildPrincipleItemQuery innerJoinBeneficiaryCategory($relationAlias = null) Adds a INNER JOIN clause to the query using the BeneficiaryCategory relation
 *
 * @method     ChildPrincipleItemQuery leftJoinPrinciple($relationAlias = null) Adds a LEFT JOIN clause to the query using the Principle relation
 * @method     ChildPrincipleItemQuery rightJoinPrinciple($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Principle relation
 * @method     ChildPrincipleItemQuery innerJoinPrinciple($relationAlias = null) Adds a INNER JOIN clause to the query using the Principle relation
 *
 * @method     ChildPrincipleItemQuery leftJoinBeneficiaryIndex($relationAlias = null) Adds a LEFT JOIN clause to the query using the BeneficiaryIndex relation
 * @method     ChildPrincipleItemQuery rightJoinBeneficiaryIndex($relationAlias = null) Adds a RIGHT JOIN clause to the query using the BeneficiaryIndex relation
 * @method     ChildPrincipleItemQuery innerJoinBeneficiaryIndex($relationAlias = null) Adds a INNER JOIN clause to the query using the BeneficiaryIndex relation
 *
 * @method     ChildPrincipleItemQuery leftJoinRawData($relationAlias = null) Adds a LEFT JOIN clause to the query using the RawData relation
 * @method     ChildPrincipleItemQuery rightJoinRawData($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RawData relation
 * @method     ChildPrincipleItemQuery innerJoinRawData($relationAlias = null) Adds a INNER JOIN clause to the query using the RawData relation
 *
 * @method     \BeneficiaryCategoryQuery|\PrincipleQuery|\BeneficiaryIndexQuery|\RawDataQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildPrincipleItem findOne(ConnectionInterface $con = null) Return the first ChildPrincipleItem matching the query
 * @method     ChildPrincipleItem findOneOrCreate(ConnectionInterface $con = null) Return the first ChildPrincipleItem matching the query, or a new ChildPrincipleItem object populated from the query conditions when no match is found
 *
 * @method     ChildPrincipleItem findOneByPrincipleItemId(string $principle_item_id) Return the first ChildPrincipleItem filtered by the principle_item_id column
 * @method     ChildPrincipleItem findOneByPrincipleItemName(string $principle_item_name) Return the first ChildPrincipleItem filtered by the principle_item_name column
 * @method     ChildPrincipleItem findOneByPrincipleId(string $principle_id) Return the first ChildPrincipleItem filtered by the principle_id column
 * @method     ChildPrincipleItem findOneByBeneficiaryCategoryId(string $beneficiary_category_id) Return the first ChildPrincipleItem filtered by the beneficiary_category_id column
 * @method     ChildPrincipleItem findOneByIsEqual(int $is_equal) Return the first ChildPrincipleItem filtered by the is_equal column
 * @method     ChildPrincipleItem findOneByPercentageAllocation(string $percentage_allocation) Return the first ChildPrincipleItem filtered by the percentage_allocation column
 * @method     ChildPrincipleItem findOneByParentId(string $parent_id) Return the first ChildPrincipleItem filtered by the parent_id column
 * @method     ChildPrincipleItem findOneByDateCreated(string $date_created) Return the first ChildPrincipleItem filtered by the date_created column
 * @method     ChildPrincipleItem findOneByCreatedBy(string $created_by) Return the first ChildPrincipleItem filtered by the created_by column
 * @method     ChildPrincipleItem findOneByDateModified(string $date_modified) Return the first ChildPrincipleItem filtered by the date_modified column
 * @method     ChildPrincipleItem findOneByModifiedBy(string $modified_by) Return the first ChildPrincipleItem filtered by the modified_by column *

 * @method     ChildPrincipleItem requirePk($key, ConnectionInterface $con = null) Return the ChildPrincipleItem by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildPrincipleItem requireOne(ConnectionInterface $con = null) Return the first ChildPrincipleItem matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildPrincipleItem requireOneByPrincipleItemId(string $principle_item_id) Return the first ChildPrincipleItem filtered by the principle_item_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildPrincipleItem requireOneByPrincipleItemName(string $principle_item_name) Return the first ChildPrincipleItem filtered by the principle_item_name column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildPrincipleItem requireOneByPrincipleId(string $principle_id) Return the first ChildPrincipleItem filtered by the principle_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildPrincipleItem requireOneByBeneficiaryCategoryId(string $beneficiary_category_id) Return the first ChildPrincipleItem filtered by the beneficiary_category_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildPrincipleItem requireOneByIsEqual(int $is_equal) Return the first ChildPrincipleItem filtered by the is_equal column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildPrincipleItem requireOneByPercentageAllocation(string $percentage_allocation) Return the first ChildPrincipleItem filtered by the percentage_allocation column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildPrincipleItem requireOneByParentId(string $parent_id) Return the first ChildPrincipleItem filtered by the parent_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildPrincipleItem requireOneByDateCreated(string $date_created) Return the first ChildPrincipleItem filtered by the date_created column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildPrincipleItem requireOneByCreatedBy(string $created_by) Return the first ChildPrincipleItem filtered by the created_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildPrincipleItem requireOneByDateModified(string $date_modified) Return the first ChildPrincipleItem filtered by the date_modified column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildPrincipleItem requireOneByModifiedBy(string $modified_by) Return the first ChildPrincipleItem filtered by the modified_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildPrincipleItem[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildPrincipleItem objects based on current ModelCriteria
 * @method     ChildPrincipleItem[]|ObjectCollection findByPrincipleItemId(string $principle_item_id) Return ChildPrincipleItem objects filtered by the principle_item_id column
 * @method     ChildPrincipleItem[]|ObjectCollection findByPrincipleItemName(string $principle_item_name) Return ChildPrincipleItem objects filtered by the principle_item_name column
 * @method     ChildPrincipleItem[]|ObjectCollection findByPrincipleId(string $principle_id) Return ChildPrincipleItem objects filtered by the principle_id column
 * @method     ChildPrincipleItem[]|ObjectCollection findByBeneficiaryCategoryId(string $beneficiary_category_id) Return ChildPrincipleItem objects filtered by the beneficiary_category_id column
 * @method     ChildPrincipleItem[]|ObjectCollection findByIsEqual(int $is_equal) Return ChildPrincipleItem objects filtered by the is_equal column
 * @method     ChildPrincipleItem[]|ObjectCollection findByPercentageAllocation(string $percentage_allocation) Return ChildPrincipleItem objects filtered by the percentage_allocation column
 * @method     ChildPrincipleItem[]|ObjectCollection findByParentId(string $parent_id) Return ChildPrincipleItem objects filtered by the parent_id column
 * @method     ChildPrincipleItem[]|ObjectCollection findByDateCreated(string $date_created) Return ChildPrincipleItem objects filtered by the date_created column
 * @method     ChildPrincipleItem[]|ObjectCollection findByCreatedBy(string $created_by) Return ChildPrincipleItem objects filtered by the created_by column
 * @method     ChildPrincipleItem[]|ObjectCollection findByDateModified(string $date_modified) Return ChildPrincipleItem objects filtered by the date_modified column
 * @method     ChildPrincipleItem[]|ObjectCollection findByModifiedBy(string $modified_by) Return ChildPrincipleItem objects filtered by the modified_by column
 * @method     ChildPrincipleItem[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class PrincipleItemQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Base\PrincipleItemQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'rafmis', $modelName = '\\PrincipleItem', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildPrincipleItemQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildPrincipleItemQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildPrincipleItemQuery) {
            return $criteria;
        }
        $query = new ChildPrincipleItemQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildPrincipleItem|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = PrincipleItemTableMap::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(PrincipleItemTableMap::DATABASE_NAME);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildPrincipleItem A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT principle_item_id, principle_item_name, principle_id, beneficiary_category_id, is_equal, percentage_allocation, parent_id, date_created, created_by, date_modified, modified_by FROM principle_item WHERE principle_item_id = :p0';
        try {
            $stmt = $con->prepare($sql);            
            $stmt->bindValue(':p0', $key, PDO::PARAM_STR);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildPrincipleItem $obj */
            $obj = new ChildPrincipleItem();
            $obj->hydrate($row);
            PrincipleItemTableMap::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildPrincipleItem|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(PrincipleItemTableMap::COL_PRINCIPLE_ITEM_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(PrincipleItemTableMap::COL_PRINCIPLE_ITEM_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the principle_item_id column
     *
     * Example usage:
     * <code>
     * $query->filterByPrincipleItemId('fooValue');   // WHERE principle_item_id = 'fooValue'
     * $query->filterByPrincipleItemId('%fooValue%'); // WHERE principle_item_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $principleItemId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByPrincipleItemId($principleItemId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($principleItemId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $principleItemId)) {
                $principleItemId = str_replace('*', '%', $principleItemId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(PrincipleItemTableMap::COL_PRINCIPLE_ITEM_ID, $principleItemId, $comparison);
    }

    /**
     * Filter the query on the principle_item_name column
     *
     * Example usage:
     * <code>
     * $query->filterByPrincipleItemName('fooValue');   // WHERE principle_item_name = 'fooValue'
     * $query->filterByPrincipleItemName('%fooValue%'); // WHERE principle_item_name LIKE '%fooValue%'
     * </code>
     *
     * @param     string $principleItemName The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByPrincipleItemName($principleItemName = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($principleItemName)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $principleItemName)) {
                $principleItemName = str_replace('*', '%', $principleItemName);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(PrincipleItemTableMap::COL_PRINCIPLE_ITEM_NAME, $principleItemName, $comparison);
    }

    /**
     * Filter the query on the principle_id column
     *
     * Example usage:
     * <code>
     * $query->filterByPrincipleId('fooValue');   // WHERE principle_id = 'fooValue'
     * $query->filterByPrincipleId('%fooValue%'); // WHERE principle_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $principleId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByPrincipleId($principleId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($principleId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $principleId)) {
                $principleId = str_replace('*', '%', $principleId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(PrincipleItemTableMap::COL_PRINCIPLE_ID, $principleId, $comparison);
    }

    /**
     * Filter the query on the beneficiary_category_id column
     *
     * Example usage:
     * <code>
     * $query->filterByBeneficiaryCategoryId('fooValue');   // WHERE beneficiary_category_id = 'fooValue'
     * $query->filterByBeneficiaryCategoryId('%fooValue%'); // WHERE beneficiary_category_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $beneficiaryCategoryId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByBeneficiaryCategoryId($beneficiaryCategoryId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($beneficiaryCategoryId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $beneficiaryCategoryId)) {
                $beneficiaryCategoryId = str_replace('*', '%', $beneficiaryCategoryId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(PrincipleItemTableMap::COL_BENEFICIARY_CATEGORY_ID, $beneficiaryCategoryId, $comparison);
    }

    /**
     * Filter the query on the is_equal column
     *
     * Example usage:
     * <code>
     * $query->filterByIsEqual(1234); // WHERE is_equal = 1234
     * $query->filterByIsEqual(array(12, 34)); // WHERE is_equal IN (12, 34)
     * $query->filterByIsEqual(array('min' => 12)); // WHERE is_equal > 12
     * </code>
     *
     * @param     mixed $isEqual The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByIsEqual($isEqual = null, $comparison = null)
    {
        if (is_array($isEqual)) {
            $useMinMax = false;
            if (isset($isEqual['min'])) {
                $this->addUsingAlias(PrincipleItemTableMap::COL_IS_EQUAL, $isEqual['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($isEqual['max'])) {
                $this->addUsingAlias(PrincipleItemTableMap::COL_IS_EQUAL, $isEqual['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(PrincipleItemTableMap::COL_IS_EQUAL, $isEqual, $comparison);
    }

    /**
     * Filter the query on the percentage_allocation column
     *
     * Example usage:
     * <code>
     * $query->filterByPercentageAllocation(1234); // WHERE percentage_allocation = 1234
     * $query->filterByPercentageAllocation(array(12, 34)); // WHERE percentage_allocation IN (12, 34)
     * $query->filterByPercentageAllocation(array('min' => 12)); // WHERE percentage_allocation > 12
     * </code>
     *
     * @param     mixed $percentageAllocation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByPercentageAllocation($percentageAllocation = null, $comparison = null)
    {
        if (is_array($percentageAllocation)) {
            $useMinMax = false;
            if (isset($percentageAllocation['min'])) {
                $this->addUsingAlias(PrincipleItemTableMap::COL_PERCENTAGE_ALLOCATION, $percentageAllocation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($percentageAllocation['max'])) {
                $this->addUsingAlias(PrincipleItemTableMap::COL_PERCENTAGE_ALLOCATION, $percentageAllocation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(PrincipleItemTableMap::COL_PERCENTAGE_ALLOCATION, $percentageAllocation, $comparison);
    }

    /**
     * Filter the query on the parent_id column
     *
     * Example usage:
     * <code>
     * $query->filterByParentId('fooValue');   // WHERE parent_id = 'fooValue'
     * $query->filterByParentId('%fooValue%'); // WHERE parent_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $parentId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByParentId($parentId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($parentId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $parentId)) {
                $parentId = str_replace('*', '%', $parentId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(PrincipleItemTableMap::COL_PARENT_ID, $parentId, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(PrincipleItemTableMap::COL_DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(PrincipleItemTableMap::COL_DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(PrincipleItemTableMap::COL_DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy('fooValue');   // WHERE created_by = 'fooValue'
     * $query->filterByCreatedBy('%fooValue%'); // WHERE created_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $createdBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($createdBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $createdBy)) {
                $createdBy = str_replace('*', '%', $createdBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(PrincipleItemTableMap::COL_CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the date_modified column
     *
     * Example usage:
     * <code>
     * $query->filterByDateModified('2011-03-14'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified('now'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified(array('max' => 'yesterday')); // WHERE date_modified > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateModified The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByDateModified($dateModified = null, $comparison = null)
    {
        if (is_array($dateModified)) {
            $useMinMax = false;
            if (isset($dateModified['min'])) {
                $this->addUsingAlias(PrincipleItemTableMap::COL_DATE_MODIFIED, $dateModified['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateModified['max'])) {
                $this->addUsingAlias(PrincipleItemTableMap::COL_DATE_MODIFIED, $dateModified['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(PrincipleItemTableMap::COL_DATE_MODIFIED, $dateModified, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy('fooValue');   // WHERE modified_by = 'fooValue'
     * $query->filterByModifiedBy('%fooValue%'); // WHERE modified_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $modifiedBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($modifiedBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $modifiedBy)) {
                $modifiedBy = str_replace('*', '%', $modifiedBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(PrincipleItemTableMap::COL_MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related \BeneficiaryCategory object
     *
     * @param \BeneficiaryCategory|ObjectCollection $beneficiaryCategory The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByBeneficiaryCategory($beneficiaryCategory, $comparison = null)
    {
        if ($beneficiaryCategory instanceof \BeneficiaryCategory) {
            return $this
                ->addUsingAlias(PrincipleItemTableMap::COL_BENEFICIARY_CATEGORY_ID, $beneficiaryCategory->getBeneficiaryCategoryId(), $comparison);
        } elseif ($beneficiaryCategory instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(PrincipleItemTableMap::COL_BENEFICIARY_CATEGORY_ID, $beneficiaryCategory->toKeyValue('PrimaryKey', 'BeneficiaryCategoryId'), $comparison);
        } else {
            throw new PropelException('filterByBeneficiaryCategory() only accepts arguments of type \BeneficiaryCategory or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the BeneficiaryCategory relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function joinBeneficiaryCategory($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('BeneficiaryCategory');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'BeneficiaryCategory');
        }

        return $this;
    }

    /**
     * Use the BeneficiaryCategory relation BeneficiaryCategory object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \BeneficiaryCategoryQuery A secondary query class using the current class as primary query
     */
    public function useBeneficiaryCategoryQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinBeneficiaryCategory($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'BeneficiaryCategory', '\BeneficiaryCategoryQuery');
    }

    /**
     * Filter the query by a related \Principle object
     *
     * @param \Principle|ObjectCollection $principle The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByPrinciple($principle, $comparison = null)
    {
        if ($principle instanceof \Principle) {
            return $this
                ->addUsingAlias(PrincipleItemTableMap::COL_PRINCIPLE_ID, $principle->getPrincipleId(), $comparison);
        } elseif ($principle instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(PrincipleItemTableMap::COL_PRINCIPLE_ID, $principle->toKeyValue('PrimaryKey', 'PrincipleId'), $comparison);
        } else {
            throw new PropelException('filterByPrinciple() only accepts arguments of type \Principle or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Principle relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function joinPrinciple($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Principle');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Principle');
        }

        return $this;
    }

    /**
     * Use the Principle relation Principle object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \PrincipleQuery A secondary query class using the current class as primary query
     */
    public function usePrincipleQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinPrinciple($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Principle', '\PrincipleQuery');
    }

    /**
     * Filter the query by a related \BeneficiaryIndex object
     *
     * @param \BeneficiaryIndex|ObjectCollection $beneficiaryIndex the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByBeneficiaryIndex($beneficiaryIndex, $comparison = null)
    {
        if ($beneficiaryIndex instanceof \BeneficiaryIndex) {
            return $this
                ->addUsingAlias(PrincipleItemTableMap::COL_PRINCIPLE_ITEM_ID, $beneficiaryIndex->getPrincipleItemId(), $comparison);
        } elseif ($beneficiaryIndex instanceof ObjectCollection) {
            return $this
                ->useBeneficiaryIndexQuery()
                ->filterByPrimaryKeys($beneficiaryIndex->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByBeneficiaryIndex() only accepts arguments of type \BeneficiaryIndex or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the BeneficiaryIndex relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function joinBeneficiaryIndex($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('BeneficiaryIndex');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'BeneficiaryIndex');
        }

        return $this;
    }

    /**
     * Use the BeneficiaryIndex relation BeneficiaryIndex object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \BeneficiaryIndexQuery A secondary query class using the current class as primary query
     */
    public function useBeneficiaryIndexQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinBeneficiaryIndex($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'BeneficiaryIndex', '\BeneficiaryIndexQuery');
    }

    /**
     * Filter the query by a related \RawData object
     *
     * @param \RawData|ObjectCollection $rawData the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function filterByRawData($rawData, $comparison = null)
    {
        if ($rawData instanceof \RawData) {
            return $this
                ->addUsingAlias(PrincipleItemTableMap::COL_PRINCIPLE_ITEM_ID, $rawData->getPrincipleItemId(), $comparison);
        } elseif ($rawData instanceof ObjectCollection) {
            return $this
                ->useRawDataQuery()
                ->filterByPrimaryKeys($rawData->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByRawData() only accepts arguments of type \RawData or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RawData relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function joinRawData($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RawData');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RawData');
        }

        return $this;
    }

    /**
     * Use the RawData relation RawData object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RawDataQuery A secondary query class using the current class as primary query
     */
    public function useRawDataQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRawData($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RawData', '\RawDataQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   ChildPrincipleItem $principleItem Object to remove from the list of results
     *
     * @return $this|ChildPrincipleItemQuery The current query, for fluid interface
     */
    public function prune($principleItem = null)
    {
        if ($principleItem) {
            $this->addUsingAlias(PrincipleItemTableMap::COL_PRINCIPLE_ITEM_ID, $principleItem->getPrincipleItemId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the principle_item table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(PrincipleItemTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            PrincipleItemTableMap::clearInstancePool();
            PrincipleItemTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(PrincipleItemTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(PrincipleItemTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            
            PrincipleItemTableMap::removeInstanceFromPool($criteria);
        
            $affectedRows += ModelCriteria::delete($con);
            PrincipleItemTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // PrincipleItemQuery
