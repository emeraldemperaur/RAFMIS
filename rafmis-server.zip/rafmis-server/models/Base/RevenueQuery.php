<?php

namespace Base;

use \Revenue as ChildRevenue;
use \RevenueQuery as ChildRevenueQuery;
use \Exception;
use \PDO;
use Map\RevenueTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'revenue' table.
 *
 * 
 *
 * @method     ChildRevenueQuery orderByRevenueTypeId($order = Criteria::ASC) Order by the revenue_type_id column
 * @method     ChildRevenueQuery orderByMonth($order = Criteria::ASC) Order by the month column
 * @method     ChildRevenueQuery orderByYear($order = Criteria::ASC) Order by the year column
 * @method     ChildRevenueQuery orderByAmount($order = Criteria::ASC) Order by the amount column
 * @method     ChildRevenueQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method     ChildRevenueQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method     ChildRevenueQuery orderByDateModified($order = Criteria::ASC) Order by the date_modified column
 * @method     ChildRevenueQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method     ChildRevenueQuery groupByRevenueTypeId() Group by the revenue_type_id column
 * @method     ChildRevenueQuery groupByMonth() Group by the month column
 * @method     ChildRevenueQuery groupByYear() Group by the year column
 * @method     ChildRevenueQuery groupByAmount() Group by the amount column
 * @method     ChildRevenueQuery groupByDateCreated() Group by the date_created column
 * @method     ChildRevenueQuery groupByCreatedBy() Group by the created_by column
 * @method     ChildRevenueQuery groupByDateModified() Group by the date_modified column
 * @method     ChildRevenueQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method     ChildRevenueQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildRevenueQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildRevenueQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildRevenueQuery leftJoinRevenueType($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueType relation
 * @method     ChildRevenueQuery rightJoinRevenueType($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueType relation
 * @method     ChildRevenueQuery innerJoinRevenueType($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueType relation
 *
 * @method     \RevenueTypeQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildRevenue findOne(ConnectionInterface $con = null) Return the first ChildRevenue matching the query
 * @method     ChildRevenue findOneOrCreate(ConnectionInterface $con = null) Return the first ChildRevenue matching the query, or a new ChildRevenue object populated from the query conditions when no match is found
 *
 * @method     ChildRevenue findOneByRevenueTypeId(string $revenue_type_id) Return the first ChildRevenue filtered by the revenue_type_id column
 * @method     ChildRevenue findOneByMonth(int $month) Return the first ChildRevenue filtered by the month column
 * @method     ChildRevenue findOneByYear(int $year) Return the first ChildRevenue filtered by the year column
 * @method     ChildRevenue findOneByAmount(double $amount) Return the first ChildRevenue filtered by the amount column
 * @method     ChildRevenue findOneByDateCreated(string $date_created) Return the first ChildRevenue filtered by the date_created column
 * @method     ChildRevenue findOneByCreatedBy(string $created_by) Return the first ChildRevenue filtered by the created_by column
 * @method     ChildRevenue findOneByDateModified(string $date_modified) Return the first ChildRevenue filtered by the date_modified column
 * @method     ChildRevenue findOneByModifiedBy(string $modified_by) Return the first ChildRevenue filtered by the modified_by column *

 * @method     ChildRevenue requirePk($key, ConnectionInterface $con = null) Return the ChildRevenue by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenue requireOne(ConnectionInterface $con = null) Return the first ChildRevenue matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildRevenue requireOneByRevenueTypeId(string $revenue_type_id) Return the first ChildRevenue filtered by the revenue_type_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenue requireOneByMonth(int $month) Return the first ChildRevenue filtered by the month column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenue requireOneByYear(int $year) Return the first ChildRevenue filtered by the year column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenue requireOneByAmount(double $amount) Return the first ChildRevenue filtered by the amount column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenue requireOneByDateCreated(string $date_created) Return the first ChildRevenue filtered by the date_created column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenue requireOneByCreatedBy(string $created_by) Return the first ChildRevenue filtered by the created_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenue requireOneByDateModified(string $date_modified) Return the first ChildRevenue filtered by the date_modified column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenue requireOneByModifiedBy(string $modified_by) Return the first ChildRevenue filtered by the modified_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildRevenue[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildRevenue objects based on current ModelCriteria
 * @method     ChildRevenue[]|ObjectCollection findByRevenueTypeId(string $revenue_type_id) Return ChildRevenue objects filtered by the revenue_type_id column
 * @method     ChildRevenue[]|ObjectCollection findByMonth(int $month) Return ChildRevenue objects filtered by the month column
 * @method     ChildRevenue[]|ObjectCollection findByYear(int $year) Return ChildRevenue objects filtered by the year column
 * @method     ChildRevenue[]|ObjectCollection findByAmount(double $amount) Return ChildRevenue objects filtered by the amount column
 * @method     ChildRevenue[]|ObjectCollection findByDateCreated(string $date_created) Return ChildRevenue objects filtered by the date_created column
 * @method     ChildRevenue[]|ObjectCollection findByCreatedBy(string $created_by) Return ChildRevenue objects filtered by the created_by column
 * @method     ChildRevenue[]|ObjectCollection findByDateModified(string $date_modified) Return ChildRevenue objects filtered by the date_modified column
 * @method     ChildRevenue[]|ObjectCollection findByModifiedBy(string $modified_by) Return ChildRevenue objects filtered by the modified_by column
 * @method     ChildRevenue[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class RevenueQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Base\RevenueQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'rafmis', $modelName = '\\Revenue', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildRevenueQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildRevenueQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildRevenueQuery) {
            return $criteria;
        }
        $query = new ChildRevenueQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj = $c->findPk(array(12, 34, 56), $con);
     * </code>
     *
     * @param array[$revenue_type_id, $month, $year] $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildRevenue|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = RevenueTableMap::getInstanceFromPool(serialize(array((string) $key[0], (string) $key[1], (string) $key[2]))))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(RevenueTableMap::DATABASE_NAME);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenue A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT revenue_type_id, month, year, amount, date_created, created_by, date_modified, modified_by FROM revenue WHERE revenue_type_id = :p0 AND month = :p1 AND year = :p2';
        try {
            $stmt = $con->prepare($sql);            
            $stmt->bindValue(':p0', $key[0], PDO::PARAM_STR);            
            $stmt->bindValue(':p1', $key[1], PDO::PARAM_INT);            
            $stmt->bindValue(':p2', $key[2], PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildRevenue $obj */
            $obj = new ChildRevenue();
            $obj->hydrate($row);
            RevenueTableMap::addInstanceToPool($obj, serialize(array((string) $key[0], (string) $key[1], (string) $key[2])));
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildRevenue|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(array(12, 56), array(832, 123), array(123, 456)), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildRevenueQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {
        $this->addUsingAlias(RevenueTableMap::COL_REVENUE_TYPE_ID, $key[0], Criteria::EQUAL);
        $this->addUsingAlias(RevenueTableMap::COL_MONTH, $key[1], Criteria::EQUAL);
        $this->addUsingAlias(RevenueTableMap::COL_YEAR, $key[2], Criteria::EQUAL);

        return $this;
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildRevenueQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {
        if (empty($keys)) {
            return $this->add(null, '1<>1', Criteria::CUSTOM);
        }
        foreach ($keys as $key) {
            $cton0 = $this->getNewCriterion(RevenueTableMap::COL_REVENUE_TYPE_ID, $key[0], Criteria::EQUAL);
            $cton1 = $this->getNewCriterion(RevenueTableMap::COL_MONTH, $key[1], Criteria::EQUAL);
            $cton0->addAnd($cton1);
            $cton2 = $this->getNewCriterion(RevenueTableMap::COL_YEAR, $key[2], Criteria::EQUAL);
            $cton0->addAnd($cton2);
            $this->addOr($cton0);
        }

        return $this;
    }

    /**
     * Filter the query on the revenue_type_id column
     *
     * Example usage:
     * <code>
     * $query->filterByRevenueTypeId('fooValue');   // WHERE revenue_type_id = 'fooValue'
     * $query->filterByRevenueTypeId('%fooValue%'); // WHERE revenue_type_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $revenueTypeId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueQuery The current query, for fluid interface
     */
    public function filterByRevenueTypeId($revenueTypeId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($revenueTypeId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $revenueTypeId)) {
                $revenueTypeId = str_replace('*', '%', $revenueTypeId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueTableMap::COL_REVENUE_TYPE_ID, $revenueTypeId, $comparison);
    }

    /**
     * Filter the query on the month column
     *
     * Example usage:
     * <code>
     * $query->filterByMonth(1234); // WHERE month = 1234
     * $query->filterByMonth(array(12, 34)); // WHERE month IN (12, 34)
     * $query->filterByMonth(array('min' => 12)); // WHERE month > 12
     * </code>
     *
     * @param     mixed $month The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueQuery The current query, for fluid interface
     */
    public function filterByMonth($month = null, $comparison = null)
    {
        if (is_array($month)) {
            $useMinMax = false;
            if (isset($month['min'])) {
                $this->addUsingAlias(RevenueTableMap::COL_MONTH, $month['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($month['max'])) {
                $this->addUsingAlias(RevenueTableMap::COL_MONTH, $month['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueTableMap::COL_MONTH, $month, $comparison);
    }

    /**
     * Filter the query on the year column
     *
     * Example usage:
     * <code>
     * $query->filterByYear(1234); // WHERE year = 1234
     * $query->filterByYear(array(12, 34)); // WHERE year IN (12, 34)
     * $query->filterByYear(array('min' => 12)); // WHERE year > 12
     * </code>
     *
     * @param     mixed $year The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueQuery The current query, for fluid interface
     */
    public function filterByYear($year = null, $comparison = null)
    {
        if (is_array($year)) {
            $useMinMax = false;
            if (isset($year['min'])) {
                $this->addUsingAlias(RevenueTableMap::COL_YEAR, $year['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($year['max'])) {
                $this->addUsingAlias(RevenueTableMap::COL_YEAR, $year['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueTableMap::COL_YEAR, $year, $comparison);
    }

    /**
     * Filter the query on the amount column
     *
     * Example usage:
     * <code>
     * $query->filterByAmount(1234); // WHERE amount = 1234
     * $query->filterByAmount(array(12, 34)); // WHERE amount IN (12, 34)
     * $query->filterByAmount(array('min' => 12)); // WHERE amount > 12
     * </code>
     *
     * @param     mixed $amount The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueQuery The current query, for fluid interface
     */
    public function filterByAmount($amount = null, $comparison = null)
    {
        if (is_array($amount)) {
            $useMinMax = false;
            if (isset($amount['min'])) {
                $this->addUsingAlias(RevenueTableMap::COL_AMOUNT, $amount['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($amount['max'])) {
                $this->addUsingAlias(RevenueTableMap::COL_AMOUNT, $amount['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueTableMap::COL_AMOUNT, $amount, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(RevenueTableMap::COL_DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(RevenueTableMap::COL_DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueTableMap::COL_DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy('fooValue');   // WHERE created_by = 'fooValue'
     * $query->filterByCreatedBy('%fooValue%'); // WHERE created_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $createdBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($createdBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $createdBy)) {
                $createdBy = str_replace('*', '%', $createdBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueTableMap::COL_CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the date_modified column
     *
     * Example usage:
     * <code>
     * $query->filterByDateModified('2011-03-14'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified('now'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified(array('max' => 'yesterday')); // WHERE date_modified > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateModified The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueQuery The current query, for fluid interface
     */
    public function filterByDateModified($dateModified = null, $comparison = null)
    {
        if (is_array($dateModified)) {
            $useMinMax = false;
            if (isset($dateModified['min'])) {
                $this->addUsingAlias(RevenueTableMap::COL_DATE_MODIFIED, $dateModified['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateModified['max'])) {
                $this->addUsingAlias(RevenueTableMap::COL_DATE_MODIFIED, $dateModified['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueTableMap::COL_DATE_MODIFIED, $dateModified, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy('fooValue');   // WHERE modified_by = 'fooValue'
     * $query->filterByModifiedBy('%fooValue%'); // WHERE modified_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $modifiedBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($modifiedBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $modifiedBy)) {
                $modifiedBy = str_replace('*', '%', $modifiedBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueTableMap::COL_MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related \RevenueType object
     *
     * @param \RevenueType|ObjectCollection $revenueType The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenueQuery The current query, for fluid interface
     */
    public function filterByRevenueType($revenueType, $comparison = null)
    {
        if ($revenueType instanceof \RevenueType) {
            return $this
                ->addUsingAlias(RevenueTableMap::COL_REVENUE_TYPE_ID, $revenueType->getRevenueTypeId(), $comparison);
        } elseif ($revenueType instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(RevenueTableMap::COL_REVENUE_TYPE_ID, $revenueType->toKeyValue('PrimaryKey', 'RevenueTypeId'), $comparison);
        } else {
            throw new PropelException('filterByRevenueType() only accepts arguments of type \RevenueType or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueType relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueQuery The current query, for fluid interface
     */
    public function joinRevenueType($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueType');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueType');
        }

        return $this;
    }

    /**
     * Use the RevenueType relation RevenueType object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueTypeQuery A secondary query class using the current class as primary query
     */
    public function useRevenueTypeQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueType($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueType', '\RevenueTypeQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   ChildRevenue $revenue Object to remove from the list of results
     *
     * @return $this|ChildRevenueQuery The current query, for fluid interface
     */
    public function prune($revenue = null)
    {
        if ($revenue) {
            $this->addCond('pruneCond0', $this->getAliasedColName(RevenueTableMap::COL_REVENUE_TYPE_ID), $revenue->getRevenueTypeId(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond1', $this->getAliasedColName(RevenueTableMap::COL_MONTH), $revenue->getMonth(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond2', $this->getAliasedColName(RevenueTableMap::COL_YEAR), $revenue->getYear(), Criteria::NOT_EQUAL);
            $this->combine(array('pruneCond0', 'pruneCond1', 'pruneCond2'), Criteria::LOGICAL_OR);
        }

        return $this;
    }

    /**
     * Deletes all rows from the revenue table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RevenueTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            RevenueTableMap::clearInstancePool();
            RevenueTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RevenueTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(RevenueTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            
            RevenueTableMap::removeInstanceFromPool($criteria);
        
            $affectedRows += ModelCriteria::delete($con);
            RevenueTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // RevenueQuery
