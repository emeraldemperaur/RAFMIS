<?php

namespace Base;

use \AppUser as ChildAppUser;
use \AppUserQuery as ChildAppUserQuery;
use \Exception;
use \PDO;
use Map\AppUserTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'app_user' table.
 *
 * 
 *
 * @method     ChildAppUserQuery orderByUsername($order = Criteria::ASC) Order by the username column
 * @method     ChildAppUserQuery orderByEmail($order = Criteria::ASC) Order by the email column
 * @method     ChildAppUserQuery orderByRoleId($order = Criteria::ASC) Order by the role_id column
 * @method     ChildAppUserQuery orderByPassword($order = Criteria::ASC) Order by the password column
 * @method     ChildAppUserQuery orderByFirstName($order = Criteria::ASC) Order by the first_name column
 * @method     ChildAppUserQuery orderByLastName($order = Criteria::ASC) Order by the last_name column
 * @method     ChildAppUserQuery orderByActive($order = Criteria::ASC) Order by the active column
 * @method     ChildAppUserQuery orderByLastLoginDate($order = Criteria::ASC) Order by the last_login_date column
 * @method     ChildAppUserQuery orderByLoginAttempt($order = Criteria::ASC) Order by the login_attempt column
 * @method     ChildAppUserQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method     ChildAppUserQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method     ChildAppUserQuery orderByDateModified($order = Criteria::ASC) Order by the date_modified column
 * @method     ChildAppUserQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method     ChildAppUserQuery groupByUsername() Group by the username column
 * @method     ChildAppUserQuery groupByEmail() Group by the email column
 * @method     ChildAppUserQuery groupByRoleId() Group by the role_id column
 * @method     ChildAppUserQuery groupByPassword() Group by the password column
 * @method     ChildAppUserQuery groupByFirstName() Group by the first_name column
 * @method     ChildAppUserQuery groupByLastName() Group by the last_name column
 * @method     ChildAppUserQuery groupByActive() Group by the active column
 * @method     ChildAppUserQuery groupByLastLoginDate() Group by the last_login_date column
 * @method     ChildAppUserQuery groupByLoginAttempt() Group by the login_attempt column
 * @method     ChildAppUserQuery groupByDateCreated() Group by the date_created column
 * @method     ChildAppUserQuery groupByCreatedBy() Group by the created_by column
 * @method     ChildAppUserQuery groupByDateModified() Group by the date_modified column
 * @method     ChildAppUserQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method     ChildAppUserQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildAppUserQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildAppUserQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildAppUserQuery leftJoinRole($relationAlias = null) Adds a LEFT JOIN clause to the query using the Role relation
 * @method     ChildAppUserQuery rightJoinRole($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Role relation
 * @method     ChildAppUserQuery innerJoinRole($relationAlias = null) Adds a INNER JOIN clause to the query using the Role relation
 *
 * @method     \RoleQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildAppUser findOne(ConnectionInterface $con = null) Return the first ChildAppUser matching the query
 * @method     ChildAppUser findOneOrCreate(ConnectionInterface $con = null) Return the first ChildAppUser matching the query, or a new ChildAppUser object populated from the query conditions when no match is found
 *
 * @method     ChildAppUser findOneByUsername(string $username) Return the first ChildAppUser filtered by the username column
 * @method     ChildAppUser findOneByEmail(string $email) Return the first ChildAppUser filtered by the email column
 * @method     ChildAppUser findOneByRoleId(string $role_id) Return the first ChildAppUser filtered by the role_id column
 * @method     ChildAppUser findOneByPassword(string $password) Return the first ChildAppUser filtered by the password column
 * @method     ChildAppUser findOneByFirstName(string $first_name) Return the first ChildAppUser filtered by the first_name column
 * @method     ChildAppUser findOneByLastName(string $last_name) Return the first ChildAppUser filtered by the last_name column
 * @method     ChildAppUser findOneByActive(int $active) Return the first ChildAppUser filtered by the active column
 * @method     ChildAppUser findOneByLastLoginDate(string $last_login_date) Return the first ChildAppUser filtered by the last_login_date column
 * @method     ChildAppUser findOneByLoginAttempt(int $login_attempt) Return the first ChildAppUser filtered by the login_attempt column
 * @method     ChildAppUser findOneByDateCreated(string $date_created) Return the first ChildAppUser filtered by the date_created column
 * @method     ChildAppUser findOneByCreatedBy(string $created_by) Return the first ChildAppUser filtered by the created_by column
 * @method     ChildAppUser findOneByDateModified(string $date_modified) Return the first ChildAppUser filtered by the date_modified column
 * @method     ChildAppUser findOneByModifiedBy(string $modified_by) Return the first ChildAppUser filtered by the modified_by column *

 * @method     ChildAppUser requirePk($key, ConnectionInterface $con = null) Return the ChildAppUser by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildAppUser requireOne(ConnectionInterface $con = null) Return the first ChildAppUser matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildAppUser requireOneByUsername(string $username) Return the first ChildAppUser filtered by the username column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildAppUser requireOneByEmail(string $email) Return the first ChildAppUser filtered by the email column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildAppUser requireOneByRoleId(string $role_id) Return the first ChildAppUser filtered by the role_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildAppUser requireOneByPassword(string $password) Return the first ChildAppUser filtered by the password column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildAppUser requireOneByFirstName(string $first_name) Return the first ChildAppUser filtered by the first_name column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildAppUser requireOneByLastName(string $last_name) Return the first ChildAppUser filtered by the last_name column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildAppUser requireOneByActive(int $active) Return the first ChildAppUser filtered by the active column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildAppUser requireOneByLastLoginDate(string $last_login_date) Return the first ChildAppUser filtered by the last_login_date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildAppUser requireOneByLoginAttempt(int $login_attempt) Return the first ChildAppUser filtered by the login_attempt column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildAppUser requireOneByDateCreated(string $date_created) Return the first ChildAppUser filtered by the date_created column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildAppUser requireOneByCreatedBy(string $created_by) Return the first ChildAppUser filtered by the created_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildAppUser requireOneByDateModified(string $date_modified) Return the first ChildAppUser filtered by the date_modified column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildAppUser requireOneByModifiedBy(string $modified_by) Return the first ChildAppUser filtered by the modified_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildAppUser[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildAppUser objects based on current ModelCriteria
 * @method     ChildAppUser[]|ObjectCollection findByUsername(string $username) Return ChildAppUser objects filtered by the username column
 * @method     ChildAppUser[]|ObjectCollection findByEmail(string $email) Return ChildAppUser objects filtered by the email column
 * @method     ChildAppUser[]|ObjectCollection findByRoleId(string $role_id) Return ChildAppUser objects filtered by the role_id column
 * @method     ChildAppUser[]|ObjectCollection findByPassword(string $password) Return ChildAppUser objects filtered by the password column
 * @method     ChildAppUser[]|ObjectCollection findByFirstName(string $first_name) Return ChildAppUser objects filtered by the first_name column
 * @method     ChildAppUser[]|ObjectCollection findByLastName(string $last_name) Return ChildAppUser objects filtered by the last_name column
 * @method     ChildAppUser[]|ObjectCollection findByActive(int $active) Return ChildAppUser objects filtered by the active column
 * @method     ChildAppUser[]|ObjectCollection findByLastLoginDate(string $last_login_date) Return ChildAppUser objects filtered by the last_login_date column
 * @method     ChildAppUser[]|ObjectCollection findByLoginAttempt(int $login_attempt) Return ChildAppUser objects filtered by the login_attempt column
 * @method     ChildAppUser[]|ObjectCollection findByDateCreated(string $date_created) Return ChildAppUser objects filtered by the date_created column
 * @method     ChildAppUser[]|ObjectCollection findByCreatedBy(string $created_by) Return ChildAppUser objects filtered by the created_by column
 * @method     ChildAppUser[]|ObjectCollection findByDateModified(string $date_modified) Return ChildAppUser objects filtered by the date_modified column
 * @method     ChildAppUser[]|ObjectCollection findByModifiedBy(string $modified_by) Return ChildAppUser objects filtered by the modified_by column
 * @method     ChildAppUser[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class AppUserQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Base\AppUserQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'rafmis', $modelName = '\\AppUser', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildAppUserQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildAppUserQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildAppUserQuery) {
            return $criteria;
        }
        $query = new ChildAppUserQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildAppUser|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = AppUserTableMap::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(AppUserTableMap::DATABASE_NAME);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildAppUser A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT username, email, role_id, password, first_name, last_name, active, last_login_date, login_attempt, date_created, created_by, date_modified, modified_by FROM app_user WHERE username = :p0';
        try {
            $stmt = $con->prepare($sql);            
            $stmt->bindValue(':p0', $key, PDO::PARAM_STR);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildAppUser $obj */
            $obj = new ChildAppUser();
            $obj->hydrate($row);
            AppUserTableMap::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildAppUser|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(AppUserTableMap::COL_USERNAME, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(AppUserTableMap::COL_USERNAME, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the username column
     *
     * Example usage:
     * <code>
     * $query->filterByUsername('fooValue');   // WHERE username = 'fooValue'
     * $query->filterByUsername('%fooValue%'); // WHERE username LIKE '%fooValue%'
     * </code>
     *
     * @param     string $username The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByUsername($username = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($username)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $username)) {
                $username = str_replace('*', '%', $username);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppUserTableMap::COL_USERNAME, $username, $comparison);
    }

    /**
     * Filter the query on the email column
     *
     * Example usage:
     * <code>
     * $query->filterByEmail('fooValue');   // WHERE email = 'fooValue'
     * $query->filterByEmail('%fooValue%'); // WHERE email LIKE '%fooValue%'
     * </code>
     *
     * @param     string $email The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByEmail($email = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($email)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $email)) {
                $email = str_replace('*', '%', $email);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppUserTableMap::COL_EMAIL, $email, $comparison);
    }

    /**
     * Filter the query on the role_id column
     *
     * Example usage:
     * <code>
     * $query->filterByRoleId('fooValue');   // WHERE role_id = 'fooValue'
     * $query->filterByRoleId('%fooValue%'); // WHERE role_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $roleId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByRoleId($roleId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($roleId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $roleId)) {
                $roleId = str_replace('*', '%', $roleId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppUserTableMap::COL_ROLE_ID, $roleId, $comparison);
    }

    /**
     * Filter the query on the password column
     *
     * Example usage:
     * <code>
     * $query->filterByPassword('fooValue');   // WHERE password = 'fooValue'
     * $query->filterByPassword('%fooValue%'); // WHERE password LIKE '%fooValue%'
     * </code>
     *
     * @param     string $password The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByPassword($password = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($password)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $password)) {
                $password = str_replace('*', '%', $password);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppUserTableMap::COL_PASSWORD, $password, $comparison);
    }

    /**
     * Filter the query on the first_name column
     *
     * Example usage:
     * <code>
     * $query->filterByFirstName('fooValue');   // WHERE first_name = 'fooValue'
     * $query->filterByFirstName('%fooValue%'); // WHERE first_name LIKE '%fooValue%'
     * </code>
     *
     * @param     string $firstName The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByFirstName($firstName = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($firstName)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $firstName)) {
                $firstName = str_replace('*', '%', $firstName);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppUserTableMap::COL_FIRST_NAME, $firstName, $comparison);
    }

    /**
     * Filter the query on the last_name column
     *
     * Example usage:
     * <code>
     * $query->filterByLastName('fooValue');   // WHERE last_name = 'fooValue'
     * $query->filterByLastName('%fooValue%'); // WHERE last_name LIKE '%fooValue%'
     * </code>
     *
     * @param     string $lastName The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByLastName($lastName = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($lastName)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $lastName)) {
                $lastName = str_replace('*', '%', $lastName);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppUserTableMap::COL_LAST_NAME, $lastName, $comparison);
    }

    /**
     * Filter the query on the active column
     *
     * Example usage:
     * <code>
     * $query->filterByActive(1234); // WHERE active = 1234
     * $query->filterByActive(array(12, 34)); // WHERE active IN (12, 34)
     * $query->filterByActive(array('min' => 12)); // WHERE active > 12
     * </code>
     *
     * @param     mixed $active The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByActive($active = null, $comparison = null)
    {
        if (is_array($active)) {
            $useMinMax = false;
            if (isset($active['min'])) {
                $this->addUsingAlias(AppUserTableMap::COL_ACTIVE, $active['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($active['max'])) {
                $this->addUsingAlias(AppUserTableMap::COL_ACTIVE, $active['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AppUserTableMap::COL_ACTIVE, $active, $comparison);
    }

    /**
     * Filter the query on the last_login_date column
     *
     * Example usage:
     * <code>
     * $query->filterByLastLoginDate('2011-03-14'); // WHERE last_login_date = '2011-03-14'
     * $query->filterByLastLoginDate('now'); // WHERE last_login_date = '2011-03-14'
     * $query->filterByLastLoginDate(array('max' => 'yesterday')); // WHERE last_login_date > '2011-03-13'
     * </code>
     *
     * @param     mixed $lastLoginDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByLastLoginDate($lastLoginDate = null, $comparison = null)
    {
        if (is_array($lastLoginDate)) {
            $useMinMax = false;
            if (isset($lastLoginDate['min'])) {
                $this->addUsingAlias(AppUserTableMap::COL_LAST_LOGIN_DATE, $lastLoginDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($lastLoginDate['max'])) {
                $this->addUsingAlias(AppUserTableMap::COL_LAST_LOGIN_DATE, $lastLoginDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AppUserTableMap::COL_LAST_LOGIN_DATE, $lastLoginDate, $comparison);
    }

    /**
     * Filter the query on the login_attempt column
     *
     * Example usage:
     * <code>
     * $query->filterByLoginAttempt(1234); // WHERE login_attempt = 1234
     * $query->filterByLoginAttempt(array(12, 34)); // WHERE login_attempt IN (12, 34)
     * $query->filterByLoginAttempt(array('min' => 12)); // WHERE login_attempt > 12
     * </code>
     *
     * @param     mixed $loginAttempt The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByLoginAttempt($loginAttempt = null, $comparison = null)
    {
        if (is_array($loginAttempt)) {
            $useMinMax = false;
            if (isset($loginAttempt['min'])) {
                $this->addUsingAlias(AppUserTableMap::COL_LOGIN_ATTEMPT, $loginAttempt['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($loginAttempt['max'])) {
                $this->addUsingAlias(AppUserTableMap::COL_LOGIN_ATTEMPT, $loginAttempt['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AppUserTableMap::COL_LOGIN_ATTEMPT, $loginAttempt, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(AppUserTableMap::COL_DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(AppUserTableMap::COL_DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AppUserTableMap::COL_DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy('fooValue');   // WHERE created_by = 'fooValue'
     * $query->filterByCreatedBy('%fooValue%'); // WHERE created_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $createdBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($createdBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $createdBy)) {
                $createdBy = str_replace('*', '%', $createdBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppUserTableMap::COL_CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the date_modified column
     *
     * Example usage:
     * <code>
     * $query->filterByDateModified('2011-03-14'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified('now'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified(array('max' => 'yesterday')); // WHERE date_modified > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateModified The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByDateModified($dateModified = null, $comparison = null)
    {
        if (is_array($dateModified)) {
            $useMinMax = false;
            if (isset($dateModified['min'])) {
                $this->addUsingAlias(AppUserTableMap::COL_DATE_MODIFIED, $dateModified['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateModified['max'])) {
                $this->addUsingAlias(AppUserTableMap::COL_DATE_MODIFIED, $dateModified['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(AppUserTableMap::COL_DATE_MODIFIED, $dateModified, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy('fooValue');   // WHERE modified_by = 'fooValue'
     * $query->filterByModifiedBy('%fooValue%'); // WHERE modified_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $modifiedBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($modifiedBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $modifiedBy)) {
                $modifiedBy = str_replace('*', '%', $modifiedBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(AppUserTableMap::COL_MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related \Role object
     *
     * @param \Role|ObjectCollection $role The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildAppUserQuery The current query, for fluid interface
     */
    public function filterByRole($role, $comparison = null)
    {
        if ($role instanceof \Role) {
            return $this
                ->addUsingAlias(AppUserTableMap::COL_ROLE_ID, $role->getRoleId(), $comparison);
        } elseif ($role instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(AppUserTableMap::COL_ROLE_ID, $role->toKeyValue('PrimaryKey', 'RoleId'), $comparison);
        } else {
            throw new PropelException('filterByRole() only accepts arguments of type \Role or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Role relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function joinRole($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Role');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Role');
        }

        return $this;
    }

    /**
     * Use the Role relation Role object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RoleQuery A secondary query class using the current class as primary query
     */
    public function useRoleQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRole($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Role', '\RoleQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   ChildAppUser $appUser Object to remove from the list of results
     *
     * @return $this|ChildAppUserQuery The current query, for fluid interface
     */
    public function prune($appUser = null)
    {
        if ($appUser) {
            $this->addUsingAlias(AppUserTableMap::COL_USERNAME, $appUser->getUsername(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the app_user table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(AppUserTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            AppUserTableMap::clearInstancePool();
            AppUserTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(AppUserTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(AppUserTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            
            AppUserTableMap::removeInstanceFromPool($criteria);
        
            $affectedRows += ModelCriteria::delete($con);
            AppUserTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // AppUserQuery
