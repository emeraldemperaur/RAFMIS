<?php

namespace Base;

use \InhouseRevenueCollectionQuery as ChildInhouseRevenueCollectionQuery;
use \RevenueCollectionEntity as ChildRevenueCollectionEntity;
use \RevenueCollectionEntityQuery as ChildRevenueCollectionEntityQuery;
use \RevenueHead as ChildRevenueHead;
use \RevenueHeadQuery as ChildRevenueHeadQuery;
use \DateTime;
use \Exception;
use \PDO;
use Map\InhouseRevenueCollectionTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveRecord\ActiveRecordInterface;
use Propel\Runtime\Collection\Collection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\BadMethodCallException;
use Propel\Runtime\Exception\LogicException;
use Propel\Runtime\Exception\PropelException;
use Propel\Runtime\Map\TableMap;
use Propel\Runtime\Parser\AbstractParser;
use Propel\Runtime\Util\PropelDateTime;

/**
 * Base class that represents a row from the 'inhouse_revenue_collection' table.
 *
 * 
 *
* @package    propel.generator..Base
*/
abstract class InhouseRevenueCollection implements ActiveRecordInterface 
{
    /**
     * TableMap class name
     */
    const TABLE_MAP = '\\Map\\InhouseRevenueCollectionTableMap';


    /**
     * attribute to determine if this object has previously been saved.
     * @var boolean
     */
    protected $new = true;

    /**
     * attribute to determine whether this object has been deleted.
     * @var boolean
     */
    protected $deleted = false;

    /**
     * The columns that have been modified in current object.
     * Tracking modified columns allows us to only update modified columns.
     * @var array
     */
    protected $modifiedColumns = array();

    /**
     * The (virtual) columns that are added at runtime
     * The formatters can add supplementary columns based on a resultset
     * @var array
     */
    protected $virtualColumns = array();

    /**
     * The value for the inhouse_revenue_collection_id field.
     * @var        int
     */
    protected $inhouse_revenue_collection_id;

    /**
     * The value for the revenue_head_id field.
     * @var        string
     */
    protected $revenue_head_id;

    /**
     * The value for the mda_code field.
     * @var        string
     */
    protected $mda_code;

    /**
     * The value for the expected_payment_month field.
     * @var        int
     */
    protected $expected_payment_month;

    /**
     * The value for the expected_payment_year field.
     * @var        int
     */
    protected $expected_payment_year;

    /**
     * The value for the amount field.
     * @var        double
     */
    protected $amount;

    /**
     * The value for the state field.
     * @var        string
     */
    protected $state;

    /**
     * The value for the payer_name field.
     * @var        string
     */
    protected $payer_name;

    /**
     * The value for the rc_number field.
     * @var        string
     */
    protected $rc_number;

    /**
     * The value for the source_id field.
     * @var        string
     */
    protected $source_id;

    /**
     * The value for the tin_number field.
     * @var        string
     */
    protected $tin_number;

    /**
     * The value for the payment_date field.
     * @var        \DateTime
     */
    protected $payment_date;

    /**
     * The value for the date_created field.
     * @var        \DateTime
     */
    protected $date_created;

    /**
     * The value for the created_by field.
     * @var        string
     */
    protected $created_by;

    /**
     * The value for the date_modified field.
     * @var        \DateTime
     */
    protected $date_modified;

    /**
     * The value for the modified_by field.
     * @var        string
     */
    protected $modified_by;

    /**
     * @var        ChildRevenueHead
     */
    protected $aRevenueHead;

    /**
     * @var        ChildRevenueCollectionEntity
     */
    protected $aRevenueCollectionEntity;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     *
     * @var boolean
     */
    protected $alreadyInSave = false;

    /**
     * Initializes internal state of Base\InhouseRevenueCollection object.
     */
    public function __construct()
    {
    }

    /**
     * Returns whether the object has been modified.
     *
     * @return boolean True if the object has been modified.
     */
    public function isModified()
    {
        return !!$this->modifiedColumns;
    }

    /**
     * Has specified column been modified?
     *
     * @param  string  $col column fully qualified name (TableMap::TYPE_COLNAME), e.g. Book::AUTHOR_ID
     * @return boolean True if $col has been modified.
     */
    public function isColumnModified($col)
    {
        return $this->modifiedColumns && isset($this->modifiedColumns[$col]);
    }

    /**
     * Get the columns that have been modified in this object.
     * @return array A unique list of the modified column names for this object.
     */
    public function getModifiedColumns()
    {
        return $this->modifiedColumns ? array_keys($this->modifiedColumns) : [];
    }

    /**
     * Returns whether the object has ever been saved.  This will
     * be false, if the object was retrieved from storage or was created
     * and then saved.
     *
     * @return boolean true, if the object has never been persisted.
     */
    public function isNew()
    {
        return $this->new;
    }

    /**
     * Setter for the isNew attribute.  This method will be called
     * by Propel-generated children and objects.
     *
     * @param boolean $b the state of the object.
     */
    public function setNew($b)
    {
        $this->new = (boolean) $b;
    }

    /**
     * Whether this object has been deleted.
     * @return boolean The deleted state of this object.
     */
    public function isDeleted()
    {
        return $this->deleted;
    }

    /**
     * Specify whether this object has been deleted.
     * @param  boolean $b The deleted state of this object.
     * @return void
     */
    public function setDeleted($b)
    {
        $this->deleted = (boolean) $b;
    }

    /**
     * Sets the modified state for the object to be false.
     * @param  string $col If supplied, only the specified column is reset.
     * @return void
     */
    public function resetModified($col = null)
    {
        if (null !== $col) {
            if (isset($this->modifiedColumns[$col])) {
                unset($this->modifiedColumns[$col]);
            }
        } else {
            $this->modifiedColumns = array();
        }
    }

    /**
     * Compares this with another <code>InhouseRevenueCollection</code> instance.  If
     * <code>obj</code> is an instance of <code>InhouseRevenueCollection</code>, delegates to
     * <code>equals(InhouseRevenueCollection)</code>.  Otherwise, returns <code>false</code>.
     *
     * @param  mixed   $obj The object to compare to.
     * @return boolean Whether equal to the object specified.
     */
    public function equals($obj)
    {
        if (!$obj instanceof static) {
            return false;
        }

        if ($this === $obj) {
            return true;
        }

        if (null === $this->getPrimaryKey() || null === $obj->getPrimaryKey()) {
            return false;
        }

        return $this->getPrimaryKey() === $obj->getPrimaryKey();
    }

    /**
     * Get the associative array of the virtual columns in this object
     *
     * @return array
     */
    public function getVirtualColumns()
    {
        return $this->virtualColumns;
    }

    /**
     * Checks the existence of a virtual column in this object
     *
     * @param  string  $name The virtual column name
     * @return boolean
     */
    public function hasVirtualColumn($name)
    {
        return array_key_exists($name, $this->virtualColumns);
    }

    /**
     * Get the value of a virtual column in this object
     *
     * @param  string $name The virtual column name
     * @return mixed
     *
     * @throws PropelException
     */
    public function getVirtualColumn($name)
    {
        if (!$this->hasVirtualColumn($name)) {
            throw new PropelException(sprintf('Cannot get value of inexistent virtual column %s.', $name));
        }

        return $this->virtualColumns[$name];
    }

    /**
     * Set the value of a virtual column in this object
     *
     * @param string $name  The virtual column name
     * @param mixed  $value The value to give to the virtual column
     *
     * @return $this|InhouseRevenueCollection The current object, for fluid interface
     */
    public function setVirtualColumn($name, $value)
    {
        $this->virtualColumns[$name] = $value;

        return $this;
    }

    /**
     * Logs a message using Propel::log().
     *
     * @param  string  $msg
     * @param  int     $priority One of the Propel::LOG_* logging levels
     * @return boolean
     */
    protected function log($msg, $priority = Propel::LOG_INFO)
    {
        return Propel::log(get_class($this) . ': ' . $msg, $priority);
    }

    /**
     * Export the current object properties to a string, using a given parser format
     * <code>
     * $book = BookQuery::create()->findPk(9012);
     * echo $book->exportTo('JSON');
     *  => {"Id":9012,"Title":"Don Juan","ISBN":"0140422161","Price":12.99,"PublisherId":1234,"AuthorId":5678}');
     * </code>
     *
     * @param  mixed   $parser                 A AbstractParser instance, or a format name ('XML', 'YAML', 'JSON', 'CSV')
     * @param  boolean $includeLazyLoadColumns (optional) Whether to include lazy load(ed) columns. Defaults to TRUE.
     * @return string  The exported data
     */
    public function exportTo($parser, $includeLazyLoadColumns = true)
    {
        if (!$parser instanceof AbstractParser) {
            $parser = AbstractParser::getParser($parser);
        }

        return $parser->fromArray($this->toArray(TableMap::TYPE_PHPNAME, $includeLazyLoadColumns, array(), true));
    }

    /**
     * Clean up internal collections prior to serializing
     * Avoids recursive loops that turn into segmentation faults when serializing
     */
    public function __sleep()
    {
        $this->clearAllReferences();

        return array_keys(get_object_vars($this));
    }

    /**
     * Get the [inhouse_revenue_collection_id] column value.
     * 
     * @return int
     */
    public function getInhouseRevenueCollectionId()
    {
        return $this->inhouse_revenue_collection_id;
    }

    /**
     * Get the [revenue_head_id] column value.
     * 
     * @return string
     */
    public function getRevenueHeadId()
    {
        return $this->revenue_head_id;
    }

    /**
     * Get the [mda_code] column value.
     * 
     * @return string
     */
    public function getMdaCode()
    {
        return $this->mda_code;
    }

    /**
     * Get the [expected_payment_month] column value.
     * 
     * @return int
     */
    public function getExpectedPaymentMonth()
    {
        return $this->expected_payment_month;
    }

    /**
     * Get the [expected_payment_year] column value.
     * 
     * @return int
     */
    public function getExpectedPaymentYear()
    {
        return $this->expected_payment_year;
    }

    /**
     * Get the [amount] column value.
     * 
     * @return double
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Get the [state] column value.
     * 
     * @return string
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * Get the [payer_name] column value.
     * 
     * @return string
     */
    public function getPayerName()
    {
        return $this->payer_name;
    }

    /**
     * Get the [rc_number] column value.
     * 
     * @return string
     */
    public function getRcNumber()
    {
        return $this->rc_number;
    }

    /**
     * Get the [source_id] column value.
     * 
     * @return string
     */
    public function getSourceId()
    {
        return $this->source_id;
    }

    /**
     * Get the [tin_number] column value.
     * 
     * @return string
     */
    public function getTinNumber()
    {
        return $this->tin_number;
    }

    /**
     * Get the [optionally formatted] temporal [payment_date] column value.
     * 
     *
     * @param      string $format The date/time format string (either date()-style or strftime()-style).
     *                            If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getPaymentDate($format = NULL)
    {
        if ($format === null) {
            return $this->payment_date;
        } else {
            return $this->payment_date instanceof \DateTime ? $this->payment_date->format($format) : null;
        }
    }

    /**
     * Get the [optionally formatted] temporal [date_created] column value.
     * 
     *
     * @param      string $format The date/time format string (either date()-style or strftime()-style).
     *                            If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00 00:00:00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateCreated($format = NULL)
    {
        if ($format === null) {
            return $this->date_created;
        } else {
            return $this->date_created instanceof \DateTime ? $this->date_created->format($format) : null;
        }
    }

    /**
     * Get the [created_by] column value.
     * 
     * @return string
     */
    public function getCreatedBy()
    {
        return $this->created_by;
    }

    /**
     * Get the [optionally formatted] temporal [date_modified] column value.
     * 
     *
     * @param      string $format The date/time format string (either date()-style or strftime()-style).
     *                            If format is NULL, then the raw DateTime object will be returned.
     *
     * @return string|DateTime Formatted date/time value as string or DateTime object (if format is NULL), NULL if column is NULL, and 0 if column value is 0000-00-00 00:00:00
     *
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateModified($format = NULL)
    {
        if ($format === null) {
            return $this->date_modified;
        } else {
            return $this->date_modified instanceof \DateTime ? $this->date_modified->format($format) : null;
        }
    }

    /**
     * Get the [modified_by] column value.
     * 
     * @return string
     */
    public function getModifiedBy()
    {
        return $this->modified_by;
    }

    /**
     * Set the value of [inhouse_revenue_collection_id] column.
     * 
     * @param int $v new value
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setInhouseRevenueCollectionId($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->inhouse_revenue_collection_id !== $v) {
            $this->inhouse_revenue_collection_id = $v;
            $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID] = true;
        }

        return $this;
    } // setInhouseRevenueCollectionId()

    /**
     * Set the value of [revenue_head_id] column.
     * 
     * @param string $v new value
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setRevenueHeadId($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->revenue_head_id !== $v) {
            $this->revenue_head_id = $v;
            $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_REVENUE_HEAD_ID] = true;
        }

        if ($this->aRevenueHead !== null && $this->aRevenueHead->getRevenueHeadId() !== $v) {
            $this->aRevenueHead = null;
        }

        return $this;
    } // setRevenueHeadId()

    /**
     * Set the value of [mda_code] column.
     * 
     * @param string $v new value
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setMdaCode($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->mda_code !== $v) {
            $this->mda_code = $v;
            $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_MDA_CODE] = true;
        }

        if ($this->aRevenueCollectionEntity !== null && $this->aRevenueCollectionEntity->getMdaCode() !== $v) {
            $this->aRevenueCollectionEntity = null;
        }

        return $this;
    } // setMdaCode()

    /**
     * Set the value of [expected_payment_month] column.
     * 
     * @param int $v new value
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setExpectedPaymentMonth($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->expected_payment_month !== $v) {
            $this->expected_payment_month = $v;
            $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_MONTH] = true;
        }

        return $this;
    } // setExpectedPaymentMonth()

    /**
     * Set the value of [expected_payment_year] column.
     * 
     * @param int $v new value
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setExpectedPaymentYear($v)
    {
        if ($v !== null) {
            $v = (int) $v;
        }

        if ($this->expected_payment_year !== $v) {
            $this->expected_payment_year = $v;
            $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_YEAR] = true;
        }

        return $this;
    } // setExpectedPaymentYear()

    /**
     * Set the value of [amount] column.
     * 
     * @param double $v new value
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setAmount($v)
    {
        if ($v !== null) {
            $v = (double) $v;
        }

        if ($this->amount !== $v) {
            $this->amount = $v;
            $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_AMOUNT] = true;
        }

        return $this;
    } // setAmount()

    /**
     * Set the value of [state] column.
     * 
     * @param string $v new value
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setState($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->state !== $v) {
            $this->state = $v;
            $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_STATE] = true;
        }

        return $this;
    } // setState()

    /**
     * Set the value of [payer_name] column.
     * 
     * @param string $v new value
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setPayerName($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->payer_name !== $v) {
            $this->payer_name = $v;
            $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_PAYER_NAME] = true;
        }

        return $this;
    } // setPayerName()

    /**
     * Set the value of [rc_number] column.
     * 
     * @param string $v new value
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setRcNumber($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->rc_number !== $v) {
            $this->rc_number = $v;
            $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_RC_NUMBER] = true;
        }

        return $this;
    } // setRcNumber()

    /**
     * Set the value of [source_id] column.
     * 
     * @param string $v new value
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setSourceId($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->source_id !== $v) {
            $this->source_id = $v;
            $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_SOURCE_ID] = true;
        }

        return $this;
    } // setSourceId()

    /**
     * Set the value of [tin_number] column.
     * 
     * @param string $v new value
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setTinNumber($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->tin_number !== $v) {
            $this->tin_number = $v;
            $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_TIN_NUMBER] = true;
        }

        return $this;
    } // setTinNumber()

    /**
     * Sets the value of [payment_date] column to a normalized version of the date/time value specified.
     * 
     * @param  mixed $v string, integer (timestamp), or \DateTime value.
     *               Empty strings are treated as NULL.
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setPaymentDate($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->payment_date !== null || $dt !== null) {
            if ($this->payment_date === null || $dt === null || $dt->format("Y-m-d") !== $this->payment_date->format("Y-m-d")) {
                $this->payment_date = $dt === null ? null : clone $dt;
                $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_PAYMENT_DATE] = true;
            }
        } // if either are not null

        return $this;
    } // setPaymentDate()

    /**
     * Sets the value of [date_created] column to a normalized version of the date/time value specified.
     * 
     * @param  mixed $v string, integer (timestamp), or \DateTime value.
     *               Empty strings are treated as NULL.
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setDateCreated($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_created !== null || $dt !== null) {
            if ($this->date_created === null || $dt === null || $dt->format("Y-m-d H:i:s") !== $this->date_created->format("Y-m-d H:i:s")) {
                $this->date_created = $dt === null ? null : clone $dt;
                $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_DATE_CREATED] = true;
            }
        } // if either are not null

        return $this;
    } // setDateCreated()

    /**
     * Set the value of [created_by] column.
     * 
     * @param string $v new value
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setCreatedBy($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->created_by !== $v) {
            $this->created_by = $v;
            $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_CREATED_BY] = true;
        }

        return $this;
    } // setCreatedBy()

    /**
     * Sets the value of [date_modified] column to a normalized version of the date/time value specified.
     * 
     * @param  mixed $v string, integer (timestamp), or \DateTime value.
     *               Empty strings are treated as NULL.
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setDateModified($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_modified !== null || $dt !== null) {
            if ($this->date_modified === null || $dt === null || $dt->format("Y-m-d H:i:s") !== $this->date_modified->format("Y-m-d H:i:s")) {
                $this->date_modified = $dt === null ? null : clone $dt;
                $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_DATE_MODIFIED] = true;
            }
        } // if either are not null

        return $this;
    } // setDateModified()

    /**
     * Set the value of [modified_by] column.
     * 
     * @param string $v new value
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     */
    public function setModifiedBy($v)
    {
        if ($v !== null) {
            $v = (string) $v;
        }

        if ($this->modified_by !== $v) {
            $this->modified_by = $v;
            $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_MODIFIED_BY] = true;
        }

        return $this;
    } // setModifiedBy()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
        // otherwise, everything was equal, so return TRUE
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array   $row       The row returned by DataFetcher->fetch().
     * @param int     $startcol  0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @param string  $indexType The index type of $row. Mostly DataFetcher->getIndexType().
                                  One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                            TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false, $indexType = TableMap::TYPE_NUM)
    {
        try {

            $col = $row[TableMap::TYPE_NUM == $indexType ? 0 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('InhouseRevenueCollectionId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->inhouse_revenue_collection_id = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 1 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('RevenueHeadId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->revenue_head_id = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 2 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('MdaCode', TableMap::TYPE_PHPNAME, $indexType)];
            $this->mda_code = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 3 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('ExpectedPaymentMonth', TableMap::TYPE_PHPNAME, $indexType)];
            $this->expected_payment_month = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 4 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('ExpectedPaymentYear', TableMap::TYPE_PHPNAME, $indexType)];
            $this->expected_payment_year = (null !== $col) ? (int) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 5 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('Amount', TableMap::TYPE_PHPNAME, $indexType)];
            $this->amount = (null !== $col) ? (double) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 6 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('State', TableMap::TYPE_PHPNAME, $indexType)];
            $this->state = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 7 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('PayerName', TableMap::TYPE_PHPNAME, $indexType)];
            $this->payer_name = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 8 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('RcNumber', TableMap::TYPE_PHPNAME, $indexType)];
            $this->rc_number = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 9 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('SourceId', TableMap::TYPE_PHPNAME, $indexType)];
            $this->source_id = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 10 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('TinNumber', TableMap::TYPE_PHPNAME, $indexType)];
            $this->tin_number = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 11 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('PaymentDate', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00') {
                $col = null;
            }
            $this->payment_date = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 12 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('DateCreated', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00 00:00:00') {
                $col = null;
            }
            $this->date_created = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 13 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('CreatedBy', TableMap::TYPE_PHPNAME, $indexType)];
            $this->created_by = (null !== $col) ? (string) $col : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 14 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('DateModified', TableMap::TYPE_PHPNAME, $indexType)];
            if ($col === '0000-00-00 00:00:00') {
                $col = null;
            }
            $this->date_modified = (null !== $col) ? PropelDateTime::newInstance($col, null, 'DateTime') : null;

            $col = $row[TableMap::TYPE_NUM == $indexType ? 15 + $startcol : InhouseRevenueCollectionTableMap::translateFieldName('ModifiedBy', TableMap::TYPE_PHPNAME, $indexType)];
            $this->modified_by = (null !== $col) ? (string) $col : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }

            return $startcol + 16; // 16 = InhouseRevenueCollectionTableMap::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException(sprintf('Error populating %s object', '\\InhouseRevenueCollection'), 0, $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {
        if ($this->aRevenueHead !== null && $this->revenue_head_id !== $this->aRevenueHead->getRevenueHeadId()) {
            $this->aRevenueHead = null;
        }
        if ($this->aRevenueCollectionEntity !== null && $this->mda_code !== $this->aRevenueCollectionEntity->getMdaCode()) {
            $this->aRevenueCollectionEntity = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param      boolean $deep (optional) Whether to also de-associated any related objects.
     * @param      ConnectionInterface $con (optional) The ConnectionInterface connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, ConnectionInterface $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(InhouseRevenueCollectionTableMap::DATABASE_NAME);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $dataFetcher = ChildInhouseRevenueCollectionQuery::create(null, $this->buildPkeyCriteria())->setFormatter(ModelCriteria::FORMAT_STATEMENT)->find($con);
        $row = $dataFetcher->fetch();
        $dataFetcher->close();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true, $dataFetcher->getIndexType()); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aRevenueHead = null;
            $this->aRevenueCollectionEntity = null;
        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param      ConnectionInterface $con
     * @return void
     * @throws PropelException
     * @see InhouseRevenueCollection::setDeleted()
     * @see InhouseRevenueCollection::isDeleted()
     */
    public function delete(ConnectionInterface $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getWriteConnection(InhouseRevenueCollectionTableMap::DATABASE_NAME);
        }

        $con->transaction(function () use ($con) {
            $deleteQuery = ChildInhouseRevenueCollectionQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $this->setDeleted(true);
            }
        });
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param      ConnectionInterface $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see doSave()
     */
    public function save(ConnectionInterface $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getServiceContainer()->getWriteConnection(InhouseRevenueCollectionTableMap::DATABASE_NAME);
        }

        return $con->transaction(function () use ($con) {
            $isInsert = $this->isNew();
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                InhouseRevenueCollectionTableMap::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }

            return $affectedRows;
        });
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param      ConnectionInterface $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see save()
     */
    protected function doSave(ConnectionInterface $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their corresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aRevenueHead !== null) {
                if ($this->aRevenueHead->isModified() || $this->aRevenueHead->isNew()) {
                    $affectedRows += $this->aRevenueHead->save($con);
                }
                $this->setRevenueHead($this->aRevenueHead);
            }

            if ($this->aRevenueCollectionEntity !== null) {
                if ($this->aRevenueCollectionEntity->isModified() || $this->aRevenueCollectionEntity->isNew()) {
                    $affectedRows += $this->aRevenueCollectionEntity->save($con);
                }
                $this->setRevenueCollectionEntity($this->aRevenueCollectionEntity);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                    $affectedRows += 1;
                } else {
                    $affectedRows += $this->doUpdate($con);
                }
                $this->resetModified();
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param      ConnectionInterface $con
     *
     * @throws PropelException
     * @see doSave()
     */
    protected function doInsert(ConnectionInterface $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID] = true;
        if (null !== $this->inhouse_revenue_collection_id) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID)) {
            $modifiedColumns[':p' . $index++]  = 'inhouse_revenue_collection_id';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_REVENUE_HEAD_ID)) {
            $modifiedColumns[':p' . $index++]  = 'revenue_head_id';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_MDA_CODE)) {
            $modifiedColumns[':p' . $index++]  = 'mda_code';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_MONTH)) {
            $modifiedColumns[':p' . $index++]  = 'expected_payment_month';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_YEAR)) {
            $modifiedColumns[':p' . $index++]  = 'expected_payment_year';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_AMOUNT)) {
            $modifiedColumns[':p' . $index++]  = 'amount';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_STATE)) {
            $modifiedColumns[':p' . $index++]  = 'state';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_PAYER_NAME)) {
            $modifiedColumns[':p' . $index++]  = 'payer_name';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_RC_NUMBER)) {
            $modifiedColumns[':p' . $index++]  = 'rc_number';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_SOURCE_ID)) {
            $modifiedColumns[':p' . $index++]  = 'source_id';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_TIN_NUMBER)) {
            $modifiedColumns[':p' . $index++]  = 'tin_number';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_PAYMENT_DATE)) {
            $modifiedColumns[':p' . $index++]  = 'payment_date';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_DATE_CREATED)) {
            $modifiedColumns[':p' . $index++]  = 'date_created';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_CREATED_BY)) {
            $modifiedColumns[':p' . $index++]  = 'created_by';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_DATE_MODIFIED)) {
            $modifiedColumns[':p' . $index++]  = 'date_modified';
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_MODIFIED_BY)) {
            $modifiedColumns[':p' . $index++]  = 'modified_by';
        }

        $sql = sprintf(
            'INSERT INTO inhouse_revenue_collection (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case 'inhouse_revenue_collection_id':                        
                        $stmt->bindValue($identifier, $this->inhouse_revenue_collection_id, PDO::PARAM_INT);
                        break;
                    case 'revenue_head_id':                        
                        $stmt->bindValue($identifier, $this->revenue_head_id, PDO::PARAM_STR);
                        break;
                    case 'mda_code':                        
                        $stmt->bindValue($identifier, $this->mda_code, PDO::PARAM_STR);
                        break;
                    case 'expected_payment_month':                        
                        $stmt->bindValue($identifier, $this->expected_payment_month, PDO::PARAM_INT);
                        break;
                    case 'expected_payment_year':                        
                        $stmt->bindValue($identifier, $this->expected_payment_year, PDO::PARAM_INT);
                        break;
                    case 'amount':                        
                        $stmt->bindValue($identifier, $this->amount, PDO::PARAM_STR);
                        break;
                    case 'state':                        
                        $stmt->bindValue($identifier, $this->state, PDO::PARAM_STR);
                        break;
                    case 'payer_name':                        
                        $stmt->bindValue($identifier, $this->payer_name, PDO::PARAM_STR);
                        break;
                    case 'rc_number':                        
                        $stmt->bindValue($identifier, $this->rc_number, PDO::PARAM_STR);
                        break;
                    case 'source_id':                        
                        $stmt->bindValue($identifier, $this->source_id, PDO::PARAM_STR);
                        break;
                    case 'tin_number':                        
                        $stmt->bindValue($identifier, $this->tin_number, PDO::PARAM_STR);
                        break;
                    case 'payment_date':                        
                        $stmt->bindValue($identifier, $this->payment_date ? $this->payment_date->format("Y-m-d H:i:s") : null, PDO::PARAM_STR);
                        break;
                    case 'date_created':                        
                        $stmt->bindValue($identifier, $this->date_created ? $this->date_created->format("Y-m-d H:i:s") : null, PDO::PARAM_STR);
                        break;
                    case 'created_by':                        
                        $stmt->bindValue($identifier, $this->created_by, PDO::PARAM_STR);
                        break;
                    case 'date_modified':                        
                        $stmt->bindValue($identifier, $this->date_modified ? $this->date_modified->format("Y-m-d H:i:s") : null, PDO::PARAM_STR);
                        break;
                    case 'modified_by':                        
                        $stmt->bindValue($identifier, $this->modified_by, PDO::PARAM_STR);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), 0, $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', 0, $e);
        }
        $this->setInhouseRevenueCollectionId($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param      ConnectionInterface $con
     *
     * @return Integer Number of updated rows
     * @see doSave()
     */
    protected function doUpdate(ConnectionInterface $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();

        return $selectCriteria->doUpdate($valuesCriteria, $con);
    }

    /**
     * Retrieves a field from the object by name passed in as a string.
     *
     * @param      string $name name
     * @param      string $type The type of fieldname the $name is of:
     *                     one of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                     TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *                     Defaults to TableMap::TYPE_PHPNAME.
     * @return mixed Value of field.
     */
    public function getByName($name, $type = TableMap::TYPE_PHPNAME)
    {
        $pos = InhouseRevenueCollectionTableMap::translateFieldName($name, $type, TableMap::TYPE_NUM);
        $field = $this->getByPosition($pos);

        return $field;
    }

    /**
     * Retrieves a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param      int $pos position in xml schema
     * @return mixed Value of field at $pos
     */
    public function getByPosition($pos)
    {
        switch ($pos) {
            case 0:
                return $this->getInhouseRevenueCollectionId();
                break;
            case 1:
                return $this->getRevenueHeadId();
                break;
            case 2:
                return $this->getMdaCode();
                break;
            case 3:
                return $this->getExpectedPaymentMonth();
                break;
            case 4:
                return $this->getExpectedPaymentYear();
                break;
            case 5:
                return $this->getAmount();
                break;
            case 6:
                return $this->getState();
                break;
            case 7:
                return $this->getPayerName();
                break;
            case 8:
                return $this->getRcNumber();
                break;
            case 9:
                return $this->getSourceId();
                break;
            case 10:
                return $this->getTinNumber();
                break;
            case 11:
                return $this->getPaymentDate();
                break;
            case 12:
                return $this->getDateCreated();
                break;
            case 13:
                return $this->getCreatedBy();
                break;
            case 14:
                return $this->getDateModified();
                break;
            case 15:
                return $this->getModifiedBy();
                break;
            default:
                return null;
                break;
        } // switch()
    }

    /**
     * Exports the object as an array.
     *
     * You can specify the key type of the array by passing one of the class
     * type constants.
     *
     * @param     string  $keyType (optional) One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME,
     *                    TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *                    Defaults to TableMap::TYPE_PHPNAME.
     * @param     boolean $includeLazyLoadColumns (optional) Whether to include lazy loaded columns. Defaults to TRUE.
     * @param     array $alreadyDumpedObjects List of objects to skip to avoid recursion
     * @param     boolean $includeForeignObjects (optional) Whether to include hydrated related objects. Default to FALSE.
     *
     * @return array an associative array containing the field names (as keys) and field values
     */
    public function toArray($keyType = TableMap::TYPE_PHPNAME, $includeLazyLoadColumns = true, $alreadyDumpedObjects = array(), $includeForeignObjects = false)
    {

        if (isset($alreadyDumpedObjects['InhouseRevenueCollection'][$this->hashCode()])) {
            return '*RECURSION*';
        }
        $alreadyDumpedObjects['InhouseRevenueCollection'][$this->hashCode()] = true;
        $keys = InhouseRevenueCollectionTableMap::getFieldNames($keyType);
        $result = array(
            $keys[0] => $this->getInhouseRevenueCollectionId(),
            $keys[1] => $this->getRevenueHeadId(),
            $keys[2] => $this->getMdaCode(),
            $keys[3] => $this->getExpectedPaymentMonth(),
            $keys[4] => $this->getExpectedPaymentYear(),
            $keys[5] => $this->getAmount(),
            $keys[6] => $this->getState(),
            $keys[7] => $this->getPayerName(),
            $keys[8] => $this->getRcNumber(),
            $keys[9] => $this->getSourceId(),
            $keys[10] => $this->getTinNumber(),
            $keys[11] => $this->getPaymentDate(),
            $keys[12] => $this->getDateCreated(),
            $keys[13] => $this->getCreatedBy(),
            $keys[14] => $this->getDateModified(),
            $keys[15] => $this->getModifiedBy(),
        );

        $utc = new \DateTimeZone('utc');
        if ($result[$keys[11]] instanceof \DateTime) {
            // When changing timezone we don't want to change existing instances
            $dateTime = clone $result[$keys[11]];
            $result[$keys[11]] = $dateTime->setTimezone($utc)->format('Y-m-d\TH:i:s\Z');
        }
        
        if ($result[$keys[12]] instanceof \DateTime) {
            // When changing timezone we don't want to change existing instances
            $dateTime = clone $result[$keys[12]];
            $result[$keys[12]] = $dateTime->setTimezone($utc)->format('Y-m-d\TH:i:s\Z');
        }
        
        if ($result[$keys[14]] instanceof \DateTime) {
            // When changing timezone we don't want to change existing instances
            $dateTime = clone $result[$keys[14]];
            $result[$keys[14]] = $dateTime->setTimezone($utc)->format('Y-m-d\TH:i:s\Z');
        }
        
        $virtualColumns = $this->virtualColumns;
        foreach ($virtualColumns as $key => $virtualColumn) {
            $result[$key] = $virtualColumn;
        }
        
        if ($includeForeignObjects) {
            if (null !== $this->aRevenueHead) {
                
                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'revenueHead';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'revenue_head';
                        break;
                    default:
                        $key = 'RevenueHead';
                }
        
                $result[$key] = $this->aRevenueHead->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
            if (null !== $this->aRevenueCollectionEntity) {
                
                switch ($keyType) {
                    case TableMap::TYPE_CAMELNAME:
                        $key = 'revenueCollectionEntity';
                        break;
                    case TableMap::TYPE_FIELDNAME:
                        $key = 'revenue_collection_entity';
                        break;
                    default:
                        $key = 'RevenueCollectionEntity';
                }
        
                $result[$key] = $this->aRevenueCollectionEntity->toArray($keyType, $includeLazyLoadColumns,  $alreadyDumpedObjects, true);
            }
        }

        return $result;
    }

    /**
     * Sets a field from the object by name passed in as a string.
     *
     * @param  string $name
     * @param  mixed  $value field value
     * @param  string $type The type of fieldname the $name is of:
     *                one of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *                Defaults to TableMap::TYPE_PHPNAME.
     * @return $this|\InhouseRevenueCollection
     */
    public function setByName($name, $value, $type = TableMap::TYPE_PHPNAME)
    {
        $pos = InhouseRevenueCollectionTableMap::translateFieldName($name, $type, TableMap::TYPE_NUM);

        return $this->setByPosition($pos, $value);
    }

    /**
     * Sets a field from the object by Position as specified in the xml schema.
     * Zero-based.
     *
     * @param  int $pos position in xml schema
     * @param  mixed $value field value
     * @return $this|\InhouseRevenueCollection
     */
    public function setByPosition($pos, $value)
    {
        switch ($pos) {
            case 0:
                $this->setInhouseRevenueCollectionId($value);
                break;
            case 1:
                $this->setRevenueHeadId($value);
                break;
            case 2:
                $this->setMdaCode($value);
                break;
            case 3:
                $this->setExpectedPaymentMonth($value);
                break;
            case 4:
                $this->setExpectedPaymentYear($value);
                break;
            case 5:
                $this->setAmount($value);
                break;
            case 6:
                $this->setState($value);
                break;
            case 7:
                $this->setPayerName($value);
                break;
            case 8:
                $this->setRcNumber($value);
                break;
            case 9:
                $this->setSourceId($value);
                break;
            case 10:
                $this->setTinNumber($value);
                break;
            case 11:
                $this->setPaymentDate($value);
                break;
            case 12:
                $this->setDateCreated($value);
                break;
            case 13:
                $this->setCreatedBy($value);
                break;
            case 14:
                $this->setDateModified($value);
                break;
            case 15:
                $this->setModifiedBy($value);
                break;
        } // switch()

        return $this;
    }

    /**
     * Populates the object using an array.
     *
     * This is particularly useful when populating an object from one of the
     * request arrays (e.g. $_POST).  This method goes through the column
     * names, checking to see whether a matching key exists in populated
     * array. If so the setByName() method is called for that column.
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME,
     * TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     * The default key type is the column's TableMap::TYPE_PHPNAME.
     *
     * @param      array  $arr     An array to populate the object from.
     * @param      string $keyType The type of keys the array uses.
     * @return void
     */
    public function fromArray($arr, $keyType = TableMap::TYPE_PHPNAME)
    {
        $keys = InhouseRevenueCollectionTableMap::getFieldNames($keyType);

        if (array_key_exists($keys[0], $arr)) {
            $this->setInhouseRevenueCollectionId($arr[$keys[0]]);
        }
        if (array_key_exists($keys[1], $arr)) {
            $this->setRevenueHeadId($arr[$keys[1]]);
        }
        if (array_key_exists($keys[2], $arr)) {
            $this->setMdaCode($arr[$keys[2]]);
        }
        if (array_key_exists($keys[3], $arr)) {
            $this->setExpectedPaymentMonth($arr[$keys[3]]);
        }
        if (array_key_exists($keys[4], $arr)) {
            $this->setExpectedPaymentYear($arr[$keys[4]]);
        }
        if (array_key_exists($keys[5], $arr)) {
            $this->setAmount($arr[$keys[5]]);
        }
        if (array_key_exists($keys[6], $arr)) {
            $this->setState($arr[$keys[6]]);
        }
        if (array_key_exists($keys[7], $arr)) {
            $this->setPayerName($arr[$keys[7]]);
        }
        if (array_key_exists($keys[8], $arr)) {
            $this->setRcNumber($arr[$keys[8]]);
        }
        if (array_key_exists($keys[9], $arr)) {
            $this->setSourceId($arr[$keys[9]]);
        }
        if (array_key_exists($keys[10], $arr)) {
            $this->setTinNumber($arr[$keys[10]]);
        }
        if (array_key_exists($keys[11], $arr)) {
            $this->setPaymentDate($arr[$keys[11]]);
        }
        if (array_key_exists($keys[12], $arr)) {
            $this->setDateCreated($arr[$keys[12]]);
        }
        if (array_key_exists($keys[13], $arr)) {
            $this->setCreatedBy($arr[$keys[13]]);
        }
        if (array_key_exists($keys[14], $arr)) {
            $this->setDateModified($arr[$keys[14]]);
        }
        if (array_key_exists($keys[15], $arr)) {
            $this->setModifiedBy($arr[$keys[15]]);
        }
    }

     /**
     * Populate the current object from a string, using a given parser format
     * <code>
     * $book = new Book();
     * $book->importFrom('JSON', '{"Id":9012,"Title":"Don Juan","ISBN":"0140422161","Price":12.99,"PublisherId":1234,"AuthorId":5678}');
     * </code>
     *
     * You can specify the key type of the array by additionally passing one
     * of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME,
     * TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     * The default key type is the column's TableMap::TYPE_PHPNAME.
     *
     * @param mixed $parser A AbstractParser instance,
     *                       or a format name ('XML', 'YAML', 'JSON', 'CSV')
     * @param string $data The source data to import from
     * @param string $keyType The type of keys the array uses.
     *
     * @return $this|\InhouseRevenueCollection The current object, for fluid interface
     */
    public function importFrom($parser, $data, $keyType = TableMap::TYPE_PHPNAME)
    {
        if (!$parser instanceof AbstractParser) {
            $parser = AbstractParser::getParser($parser);
        }

        $this->fromArray($parser->toArray($data), $keyType);

        return $this;
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(InhouseRevenueCollectionTableMap::DATABASE_NAME);

        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID, $this->inhouse_revenue_collection_id);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_REVENUE_HEAD_ID)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_REVENUE_HEAD_ID, $this->revenue_head_id);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_MDA_CODE)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_MDA_CODE, $this->mda_code);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_MONTH)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_MONTH, $this->expected_payment_month);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_YEAR)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_YEAR, $this->expected_payment_year);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_AMOUNT)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_AMOUNT, $this->amount);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_STATE)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_STATE, $this->state);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_PAYER_NAME)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_PAYER_NAME, $this->payer_name);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_RC_NUMBER)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_RC_NUMBER, $this->rc_number);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_SOURCE_ID)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_SOURCE_ID, $this->source_id);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_TIN_NUMBER)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_TIN_NUMBER, $this->tin_number);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_PAYMENT_DATE)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_PAYMENT_DATE, $this->payment_date);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_DATE_CREATED)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_DATE_CREATED, $this->date_created);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_CREATED_BY)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_CREATED_BY, $this->created_by);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_DATE_MODIFIED)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_DATE_MODIFIED, $this->date_modified);
        }
        if ($this->isColumnModified(InhouseRevenueCollectionTableMap::COL_MODIFIED_BY)) {
            $criteria->add(InhouseRevenueCollectionTableMap::COL_MODIFIED_BY, $this->modified_by);
        }

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @throws LogicException if no primary key is defined
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = ChildInhouseRevenueCollectionQuery::create();
        $criteria->add(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID, $this->inhouse_revenue_collection_id);

        return $criteria;
    }

    /**
     * If the primary key is not null, return the hashcode of the
     * primary key. Otherwise, return the hash code of the object.
     *
     * @return int Hashcode
     */
    public function hashCode()
    {
        $validPk = null !== $this->getInhouseRevenueCollectionId();

        $validPrimaryKeyFKs = 0;
        $primaryKeyFKs = [];

        if ($validPk) {
            return crc32(json_encode($this->getPrimaryKey(), JSON_UNESCAPED_UNICODE));
        } elseif ($validPrimaryKeyFKs) {
            return crc32(json_encode($primaryKeyFKs, JSON_UNESCAPED_UNICODE));
        }

        return spl_object_hash($this);
    }
        
    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getInhouseRevenueCollectionId();
    }

    /**
     * Generic method to set the primary key (inhouse_revenue_collection_id column).
     *
     * @param       int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setInhouseRevenueCollectionId($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {
        return null === $this->getInhouseRevenueCollectionId();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param      object $copyObj An object of \InhouseRevenueCollection (or compatible) type.
     * @param      boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param      boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setRevenueHeadId($this->getRevenueHeadId());
        $copyObj->setMdaCode($this->getMdaCode());
        $copyObj->setExpectedPaymentMonth($this->getExpectedPaymentMonth());
        $copyObj->setExpectedPaymentYear($this->getExpectedPaymentYear());
        $copyObj->setAmount($this->getAmount());
        $copyObj->setState($this->getState());
        $copyObj->setPayerName($this->getPayerName());
        $copyObj->setRcNumber($this->getRcNumber());
        $copyObj->setSourceId($this->getSourceId());
        $copyObj->setTinNumber($this->getTinNumber());
        $copyObj->setPaymentDate($this->getPaymentDate());
        $copyObj->setDateCreated($this->getDateCreated());
        $copyObj->setCreatedBy($this->getCreatedBy());
        $copyObj->setDateModified($this->getDateModified());
        $copyObj->setModifiedBy($this->getModifiedBy());
        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setInhouseRevenueCollectionId(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param  boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return \InhouseRevenueCollection Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Declares an association between this object and a ChildRevenueHead object.
     *
     * @param  ChildRevenueHead $v
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     * @throws PropelException
     */
    public function setRevenueHead(ChildRevenueHead $v = null)
    {
        if ($v === null) {
            $this->setRevenueHeadId(NULL);
        } else {
            $this->setRevenueHeadId($v->getRevenueHeadId());
        }

        $this->aRevenueHead = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildRevenueHead object, it will not be re-added.
        if ($v !== null) {
            $v->addInhouseRevenueCollection($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildRevenueHead object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildRevenueHead The associated ChildRevenueHead object.
     * @throws PropelException
     */
    public function getRevenueHead(ConnectionInterface $con = null)
    {
        if ($this->aRevenueHead === null && (($this->revenue_head_id !== "" && $this->revenue_head_id !== null))) {
            $this->aRevenueHead = ChildRevenueHeadQuery::create()->findPk($this->revenue_head_id, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aRevenueHead->addInhouseRevenueCollections($this);
             */
        }

        return $this->aRevenueHead;
    }

    /**
     * Declares an association between this object and a ChildRevenueCollectionEntity object.
     *
     * @param  ChildRevenueCollectionEntity $v
     * @return $this|\InhouseRevenueCollection The current object (for fluent API support)
     * @throws PropelException
     */
    public function setRevenueCollectionEntity(ChildRevenueCollectionEntity $v = null)
    {
        if ($v === null) {
            $this->setMdaCode(NULL);
        } else {
            $this->setMdaCode($v->getMdaCode());
        }

        $this->aRevenueCollectionEntity = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the ChildRevenueCollectionEntity object, it will not be re-added.
        if ($v !== null) {
            $v->addInhouseRevenueCollection($this);
        }


        return $this;
    }


    /**
     * Get the associated ChildRevenueCollectionEntity object
     *
     * @param  ConnectionInterface $con Optional Connection object.
     * @return ChildRevenueCollectionEntity The associated ChildRevenueCollectionEntity object.
     * @throws PropelException
     */
    public function getRevenueCollectionEntity(ConnectionInterface $con = null)
    {
        if ($this->aRevenueCollectionEntity === null && (($this->mda_code !== "" && $this->mda_code !== null))) {
            $this->aRevenueCollectionEntity = ChildRevenueCollectionEntityQuery::create()->findPk($this->mda_code, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aRevenueCollectionEntity->addInhouseRevenueCollections($this);
             */
        }

        return $this->aRevenueCollectionEntity;
    }

    /**
     * Clears the current object, sets all attributes to their default values and removes
     * outgoing references as well as back-references (from other objects to this one. Results probably in a database
     * change of those foreign objects when you call `save` there).
     */
    public function clear()
    {
        if (null !== $this->aRevenueHead) {
            $this->aRevenueHead->removeInhouseRevenueCollection($this);
        }
        if (null !== $this->aRevenueCollectionEntity) {
            $this->aRevenueCollectionEntity->removeInhouseRevenueCollection($this);
        }
        $this->inhouse_revenue_collection_id = null;
        $this->revenue_head_id = null;
        $this->mda_code = null;
        $this->expected_payment_month = null;
        $this->expected_payment_year = null;
        $this->amount = null;
        $this->state = null;
        $this->payer_name = null;
        $this->rc_number = null;
        $this->source_id = null;
        $this->tin_number = null;
        $this->payment_date = null;
        $this->date_created = null;
        $this->created_by = null;
        $this->date_modified = null;
        $this->modified_by = null;
        $this->alreadyInSave = false;
        $this->clearAllReferences();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references and back-references to other model objects or collections of model objects.
     *
     * This method is used to reset all php object references (not the actual reference in the database).
     * Necessary for object serialisation.
     *
     * @param      boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep) {
        } // if ($deep)

        $this->aRevenueHead = null;
        $this->aRevenueCollectionEntity = null;
    }

    /**
     * Return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(InhouseRevenueCollectionTableMap::DEFAULT_STRING_FORMAT);
    }

    /**
     * Code to be run before persisting the object
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preSave(ConnectionInterface $con = null)
    {
        return true;
    }

    /**
     * Code to be run after persisting the object
     * @param ConnectionInterface $con
     */
    public function postSave(ConnectionInterface $con = null)
    {

    }

    /**
     * Code to be run before inserting to database
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preInsert(ConnectionInterface $con = null)
    {
        return true;
    }

    /**
     * Code to be run after inserting to database
     * @param ConnectionInterface $con
     */
    public function postInsert(ConnectionInterface $con = null)
    {

    }

    /**
     * Code to be run before updating the object in database
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preUpdate(ConnectionInterface $con = null)
    {
        return true;
    }

    /**
     * Code to be run after updating the object in database
     * @param ConnectionInterface $con
     */
    public function postUpdate(ConnectionInterface $con = null)
    {

    }

    /**
     * Code to be run before deleting the object in database
     * @param  ConnectionInterface $con
     * @return boolean
     */
    public function preDelete(ConnectionInterface $con = null)
    {
        return true;
    }

    /**
     * Code to be run after deleting the object in database
     * @param ConnectionInterface $con
     */
    public function postDelete(ConnectionInterface $con = null)
    {

    }


    /**
     * Derived method to catches calls to undefined methods.
     *
     * Provides magic import/export method support (fromXML()/toXML(), fromYAML()/toYAML(), etc.).
     * Allows to define default __call() behavior if you overwrite __call()
     *
     * @param string $name
     * @param mixed  $params
     *
     * @return array|string
     */
    public function __call($name, $params)
    {
        if (0 === strpos($name, 'get')) {
            $virtualColumn = substr($name, 3);
            if ($this->hasVirtualColumn($virtualColumn)) {
                return $this->getVirtualColumn($virtualColumn);
            }

            $virtualColumn = lcfirst($virtualColumn);
            if ($this->hasVirtualColumn($virtualColumn)) {
                return $this->getVirtualColumn($virtualColumn);
            }
        }

        if (0 === strpos($name, 'from')) {
            $format = substr($name, 4);

            return $this->importFrom($format, reset($params));
        }

        if (0 === strpos($name, 'to')) {
            $format = substr($name, 2);
            $includeLazyLoadColumns = isset($params[0]) ? $params[0] : true;

            return $this->exportTo($format, $includeLazyLoadColumns);
        }

        throw new BadMethodCallException(sprintf('Call to undefined method: %s.', $name));
    }

}
