<?php

namespace Base;

use \BeneficiaryCategoryAllocation as ChildBeneficiaryCategoryAllocation;
use \BeneficiaryCategoryAllocationQuery as ChildBeneficiaryCategoryAllocationQuery;
use \Exception;
use \PDO;
use Map\BeneficiaryCategoryAllocationTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'beneficiary_category_allocation' table.
 *
 * 
 *
 * @method     ChildBeneficiaryCategoryAllocationQuery orderByBeneficiaryCatAllocationGroupId($order = Criteria::ASC) Order by the beneficiary_cat_allocation_group_id column
 * @method     ChildBeneficiaryCategoryAllocationQuery orderByBeneficiaryCategoryId($order = Criteria::ASC) Order by the beneficiary_category_id column
 * @method     ChildBeneficiaryCategoryAllocationQuery orderByPercentageAllocation($order = Criteria::ASC) Order by the percentage_allocation column
 * @method     ChildBeneficiaryCategoryAllocationQuery orderByPrincipleId($order = Criteria::ASC) Order by the principle_id column
 * @method     ChildBeneficiaryCategoryAllocationQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method     ChildBeneficiaryCategoryAllocationQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method     ChildBeneficiaryCategoryAllocationQuery orderByDateModified($order = Criteria::ASC) Order by the date_modified column
 * @method     ChildBeneficiaryCategoryAllocationQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method     ChildBeneficiaryCategoryAllocationQuery groupByBeneficiaryCatAllocationGroupId() Group by the beneficiary_cat_allocation_group_id column
 * @method     ChildBeneficiaryCategoryAllocationQuery groupByBeneficiaryCategoryId() Group by the beneficiary_category_id column
 * @method     ChildBeneficiaryCategoryAllocationQuery groupByPercentageAllocation() Group by the percentage_allocation column
 * @method     ChildBeneficiaryCategoryAllocationQuery groupByPrincipleId() Group by the principle_id column
 * @method     ChildBeneficiaryCategoryAllocationQuery groupByDateCreated() Group by the date_created column
 * @method     ChildBeneficiaryCategoryAllocationQuery groupByCreatedBy() Group by the created_by column
 * @method     ChildBeneficiaryCategoryAllocationQuery groupByDateModified() Group by the date_modified column
 * @method     ChildBeneficiaryCategoryAllocationQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method     ChildBeneficiaryCategoryAllocationQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildBeneficiaryCategoryAllocationQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildBeneficiaryCategoryAllocationQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildBeneficiaryCategoryAllocationQuery leftJoinBeneficiaryCategoryAllocationGroup($relationAlias = null) Adds a LEFT JOIN clause to the query using the BeneficiaryCategoryAllocationGroup relation
 * @method     ChildBeneficiaryCategoryAllocationQuery rightJoinBeneficiaryCategoryAllocationGroup($relationAlias = null) Adds a RIGHT JOIN clause to the query using the BeneficiaryCategoryAllocationGroup relation
 * @method     ChildBeneficiaryCategoryAllocationQuery innerJoinBeneficiaryCategoryAllocationGroup($relationAlias = null) Adds a INNER JOIN clause to the query using the BeneficiaryCategoryAllocationGroup relation
 *
 * @method     ChildBeneficiaryCategoryAllocationQuery leftJoinBeneficiaryCategory($relationAlias = null) Adds a LEFT JOIN clause to the query using the BeneficiaryCategory relation
 * @method     ChildBeneficiaryCategoryAllocationQuery rightJoinBeneficiaryCategory($relationAlias = null) Adds a RIGHT JOIN clause to the query using the BeneficiaryCategory relation
 * @method     ChildBeneficiaryCategoryAllocationQuery innerJoinBeneficiaryCategory($relationAlias = null) Adds a INNER JOIN clause to the query using the BeneficiaryCategory relation
 *
 * @method     ChildBeneficiaryCategoryAllocationQuery leftJoinPrinciple($relationAlias = null) Adds a LEFT JOIN clause to the query using the Principle relation
 * @method     ChildBeneficiaryCategoryAllocationQuery rightJoinPrinciple($relationAlias = null) Adds a RIGHT JOIN clause to the query using the Principle relation
 * @method     ChildBeneficiaryCategoryAllocationQuery innerJoinPrinciple($relationAlias = null) Adds a INNER JOIN clause to the query using the Principle relation
 *
 * @method     \BeneficiaryCategoryAllocationGroupQuery|\BeneficiaryCategoryQuery|\PrincipleQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildBeneficiaryCategoryAllocation findOne(ConnectionInterface $con = null) Return the first ChildBeneficiaryCategoryAllocation matching the query
 * @method     ChildBeneficiaryCategoryAllocation findOneOrCreate(ConnectionInterface $con = null) Return the first ChildBeneficiaryCategoryAllocation matching the query, or a new ChildBeneficiaryCategoryAllocation object populated from the query conditions when no match is found
 *
 * @method     ChildBeneficiaryCategoryAllocation findOneByBeneficiaryCatAllocationGroupId(string $beneficiary_cat_allocation_group_id) Return the first ChildBeneficiaryCategoryAllocation filtered by the beneficiary_cat_allocation_group_id column
 * @method     ChildBeneficiaryCategoryAllocation findOneByBeneficiaryCategoryId(string $beneficiary_category_id) Return the first ChildBeneficiaryCategoryAllocation filtered by the beneficiary_category_id column
 * @method     ChildBeneficiaryCategoryAllocation findOneByPercentageAllocation(string $percentage_allocation) Return the first ChildBeneficiaryCategoryAllocation filtered by the percentage_allocation column
 * @method     ChildBeneficiaryCategoryAllocation findOneByPrincipleId(string $principle_id) Return the first ChildBeneficiaryCategoryAllocation filtered by the principle_id column
 * @method     ChildBeneficiaryCategoryAllocation findOneByDateCreated(string $date_created) Return the first ChildBeneficiaryCategoryAllocation filtered by the date_created column
 * @method     ChildBeneficiaryCategoryAllocation findOneByCreatedBy(string $created_by) Return the first ChildBeneficiaryCategoryAllocation filtered by the created_by column
 * @method     ChildBeneficiaryCategoryAllocation findOneByDateModified(string $date_modified) Return the first ChildBeneficiaryCategoryAllocation filtered by the date_modified column
 * @method     ChildBeneficiaryCategoryAllocation findOneByModifiedBy(string $modified_by) Return the first ChildBeneficiaryCategoryAllocation filtered by the modified_by column *

 * @method     ChildBeneficiaryCategoryAllocation requirePk($key, ConnectionInterface $con = null) Return the ChildBeneficiaryCategoryAllocation by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildBeneficiaryCategoryAllocation requireOne(ConnectionInterface $con = null) Return the first ChildBeneficiaryCategoryAllocation matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildBeneficiaryCategoryAllocation requireOneByBeneficiaryCatAllocationGroupId(string $beneficiary_cat_allocation_group_id) Return the first ChildBeneficiaryCategoryAllocation filtered by the beneficiary_cat_allocation_group_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildBeneficiaryCategoryAllocation requireOneByBeneficiaryCategoryId(string $beneficiary_category_id) Return the first ChildBeneficiaryCategoryAllocation filtered by the beneficiary_category_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildBeneficiaryCategoryAllocation requireOneByPercentageAllocation(string $percentage_allocation) Return the first ChildBeneficiaryCategoryAllocation filtered by the percentage_allocation column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildBeneficiaryCategoryAllocation requireOneByPrincipleId(string $principle_id) Return the first ChildBeneficiaryCategoryAllocation filtered by the principle_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildBeneficiaryCategoryAllocation requireOneByDateCreated(string $date_created) Return the first ChildBeneficiaryCategoryAllocation filtered by the date_created column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildBeneficiaryCategoryAllocation requireOneByCreatedBy(string $created_by) Return the first ChildBeneficiaryCategoryAllocation filtered by the created_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildBeneficiaryCategoryAllocation requireOneByDateModified(string $date_modified) Return the first ChildBeneficiaryCategoryAllocation filtered by the date_modified column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildBeneficiaryCategoryAllocation requireOneByModifiedBy(string $modified_by) Return the first ChildBeneficiaryCategoryAllocation filtered by the modified_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildBeneficiaryCategoryAllocation[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildBeneficiaryCategoryAllocation objects based on current ModelCriteria
 * @method     ChildBeneficiaryCategoryAllocation[]|ObjectCollection findByBeneficiaryCatAllocationGroupId(string $beneficiary_cat_allocation_group_id) Return ChildBeneficiaryCategoryAllocation objects filtered by the beneficiary_cat_allocation_group_id column
 * @method     ChildBeneficiaryCategoryAllocation[]|ObjectCollection findByBeneficiaryCategoryId(string $beneficiary_category_id) Return ChildBeneficiaryCategoryAllocation objects filtered by the beneficiary_category_id column
 * @method     ChildBeneficiaryCategoryAllocation[]|ObjectCollection findByPercentageAllocation(string $percentage_allocation) Return ChildBeneficiaryCategoryAllocation objects filtered by the percentage_allocation column
 * @method     ChildBeneficiaryCategoryAllocation[]|ObjectCollection findByPrincipleId(string $principle_id) Return ChildBeneficiaryCategoryAllocation objects filtered by the principle_id column
 * @method     ChildBeneficiaryCategoryAllocation[]|ObjectCollection findByDateCreated(string $date_created) Return ChildBeneficiaryCategoryAllocation objects filtered by the date_created column
 * @method     ChildBeneficiaryCategoryAllocation[]|ObjectCollection findByCreatedBy(string $created_by) Return ChildBeneficiaryCategoryAllocation objects filtered by the created_by column
 * @method     ChildBeneficiaryCategoryAllocation[]|ObjectCollection findByDateModified(string $date_modified) Return ChildBeneficiaryCategoryAllocation objects filtered by the date_modified column
 * @method     ChildBeneficiaryCategoryAllocation[]|ObjectCollection findByModifiedBy(string $modified_by) Return ChildBeneficiaryCategoryAllocation objects filtered by the modified_by column
 * @method     ChildBeneficiaryCategoryAllocation[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class BeneficiaryCategoryAllocationQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Base\BeneficiaryCategoryAllocationQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'rafmis', $modelName = '\\BeneficiaryCategoryAllocation', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildBeneficiaryCategoryAllocationQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildBeneficiaryCategoryAllocationQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildBeneficiaryCategoryAllocationQuery) {
            return $criteria;
        }
        $query = new ChildBeneficiaryCategoryAllocationQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj = $c->findPk(array(12, 34), $con);
     * </code>
     *
     * @param array[$beneficiary_cat_allocation_group_id, $beneficiary_category_id] $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildBeneficiaryCategoryAllocation|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = BeneficiaryCategoryAllocationTableMap::getInstanceFromPool(serialize(array((string) $key[0], (string) $key[1]))))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(BeneficiaryCategoryAllocationTableMap::DATABASE_NAME);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildBeneficiaryCategoryAllocation A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT beneficiary_cat_allocation_group_id, beneficiary_category_id, percentage_allocation, principle_id, date_created, created_by, date_modified, modified_by FROM beneficiary_category_allocation WHERE beneficiary_cat_allocation_group_id = :p0 AND beneficiary_category_id = :p1';
        try {
            $stmt = $con->prepare($sql);            
            $stmt->bindValue(':p0', $key[0], PDO::PARAM_STR);            
            $stmt->bindValue(':p1', $key[1], PDO::PARAM_STR);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildBeneficiaryCategoryAllocation $obj */
            $obj = new ChildBeneficiaryCategoryAllocation();
            $obj->hydrate($row);
            BeneficiaryCategoryAllocationTableMap::addInstanceToPool($obj, serialize(array((string) $key[0], (string) $key[1])));
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildBeneficiaryCategoryAllocation|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(array(12, 56), array(832, 123), array(123, 456)), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {
        $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_BENEFICIARY_CAT_ALLOCATION_GROUP_ID, $key[0], Criteria::EQUAL);
        $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_BENEFICIARY_CATEGORY_ID, $key[1], Criteria::EQUAL);

        return $this;
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {
        if (empty($keys)) {
            return $this->add(null, '1<>1', Criteria::CUSTOM);
        }
        foreach ($keys as $key) {
            $cton0 = $this->getNewCriterion(BeneficiaryCategoryAllocationTableMap::COL_BENEFICIARY_CAT_ALLOCATION_GROUP_ID, $key[0], Criteria::EQUAL);
            $cton1 = $this->getNewCriterion(BeneficiaryCategoryAllocationTableMap::COL_BENEFICIARY_CATEGORY_ID, $key[1], Criteria::EQUAL);
            $cton0->addAnd($cton1);
            $this->addOr($cton0);
        }

        return $this;
    }

    /**
     * Filter the query on the beneficiary_cat_allocation_group_id column
     *
     * Example usage:
     * <code>
     * $query->filterByBeneficiaryCatAllocationGroupId('fooValue');   // WHERE beneficiary_cat_allocation_group_id = 'fooValue'
     * $query->filterByBeneficiaryCatAllocationGroupId('%fooValue%'); // WHERE beneficiary_cat_allocation_group_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $beneficiaryCatAllocationGroupId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function filterByBeneficiaryCatAllocationGroupId($beneficiaryCatAllocationGroupId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($beneficiaryCatAllocationGroupId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $beneficiaryCatAllocationGroupId)) {
                $beneficiaryCatAllocationGroupId = str_replace('*', '%', $beneficiaryCatAllocationGroupId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_BENEFICIARY_CAT_ALLOCATION_GROUP_ID, $beneficiaryCatAllocationGroupId, $comparison);
    }

    /**
     * Filter the query on the beneficiary_category_id column
     *
     * Example usage:
     * <code>
     * $query->filterByBeneficiaryCategoryId('fooValue');   // WHERE beneficiary_category_id = 'fooValue'
     * $query->filterByBeneficiaryCategoryId('%fooValue%'); // WHERE beneficiary_category_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $beneficiaryCategoryId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function filterByBeneficiaryCategoryId($beneficiaryCategoryId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($beneficiaryCategoryId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $beneficiaryCategoryId)) {
                $beneficiaryCategoryId = str_replace('*', '%', $beneficiaryCategoryId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_BENEFICIARY_CATEGORY_ID, $beneficiaryCategoryId, $comparison);
    }

    /**
     * Filter the query on the percentage_allocation column
     *
     * Example usage:
     * <code>
     * $query->filterByPercentageAllocation(1234); // WHERE percentage_allocation = 1234
     * $query->filterByPercentageAllocation(array(12, 34)); // WHERE percentage_allocation IN (12, 34)
     * $query->filterByPercentageAllocation(array('min' => 12)); // WHERE percentage_allocation > 12
     * </code>
     *
     * @param     mixed $percentageAllocation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function filterByPercentageAllocation($percentageAllocation = null, $comparison = null)
    {
        if (is_array($percentageAllocation)) {
            $useMinMax = false;
            if (isset($percentageAllocation['min'])) {
                $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_PERCENTAGE_ALLOCATION, $percentageAllocation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($percentageAllocation['max'])) {
                $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_PERCENTAGE_ALLOCATION, $percentageAllocation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_PERCENTAGE_ALLOCATION, $percentageAllocation, $comparison);
    }

    /**
     * Filter the query on the principle_id column
     *
     * Example usage:
     * <code>
     * $query->filterByPrincipleId('fooValue');   // WHERE principle_id = 'fooValue'
     * $query->filterByPrincipleId('%fooValue%'); // WHERE principle_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $principleId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function filterByPrincipleId($principleId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($principleId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $principleId)) {
                $principleId = str_replace('*', '%', $principleId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_PRINCIPLE_ID, $principleId, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy('fooValue');   // WHERE created_by = 'fooValue'
     * $query->filterByCreatedBy('%fooValue%'); // WHERE created_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $createdBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($createdBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $createdBy)) {
                $createdBy = str_replace('*', '%', $createdBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the date_modified column
     *
     * Example usage:
     * <code>
     * $query->filterByDateModified('2011-03-14'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified('now'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified(array('max' => 'yesterday')); // WHERE date_modified > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateModified The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function filterByDateModified($dateModified = null, $comparison = null)
    {
        if (is_array($dateModified)) {
            $useMinMax = false;
            if (isset($dateModified['min'])) {
                $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_DATE_MODIFIED, $dateModified['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateModified['max'])) {
                $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_DATE_MODIFIED, $dateModified['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_DATE_MODIFIED, $dateModified, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy('fooValue');   // WHERE modified_by = 'fooValue'
     * $query->filterByModifiedBy('%fooValue%'); // WHERE modified_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $modifiedBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($modifiedBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $modifiedBy)) {
                $modifiedBy = str_replace('*', '%', $modifiedBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related \BeneficiaryCategoryAllocationGroup object
     *
     * @param \BeneficiaryCategoryAllocationGroup|ObjectCollection $beneficiaryCategoryAllocationGroup The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function filterByBeneficiaryCategoryAllocationGroup($beneficiaryCategoryAllocationGroup, $comparison = null)
    {
        if ($beneficiaryCategoryAllocationGroup instanceof \BeneficiaryCategoryAllocationGroup) {
            return $this
                ->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_BENEFICIARY_CAT_ALLOCATION_GROUP_ID, $beneficiaryCategoryAllocationGroup->getBeneficiaryCatAllocationGroupId(), $comparison);
        } elseif ($beneficiaryCategoryAllocationGroup instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_BENEFICIARY_CAT_ALLOCATION_GROUP_ID, $beneficiaryCategoryAllocationGroup->toKeyValue('PrimaryKey', 'BeneficiaryCatAllocationGroupId'), $comparison);
        } else {
            throw new PropelException('filterByBeneficiaryCategoryAllocationGroup() only accepts arguments of type \BeneficiaryCategoryAllocationGroup or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the BeneficiaryCategoryAllocationGroup relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function joinBeneficiaryCategoryAllocationGroup($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('BeneficiaryCategoryAllocationGroup');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'BeneficiaryCategoryAllocationGroup');
        }

        return $this;
    }

    /**
     * Use the BeneficiaryCategoryAllocationGroup relation BeneficiaryCategoryAllocationGroup object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \BeneficiaryCategoryAllocationGroupQuery A secondary query class using the current class as primary query
     */
    public function useBeneficiaryCategoryAllocationGroupQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinBeneficiaryCategoryAllocationGroup($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'BeneficiaryCategoryAllocationGroup', '\BeneficiaryCategoryAllocationGroupQuery');
    }

    /**
     * Filter the query by a related \BeneficiaryCategory object
     *
     * @param \BeneficiaryCategory|ObjectCollection $beneficiaryCategory The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function filterByBeneficiaryCategory($beneficiaryCategory, $comparison = null)
    {
        if ($beneficiaryCategory instanceof \BeneficiaryCategory) {
            return $this
                ->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_BENEFICIARY_CATEGORY_ID, $beneficiaryCategory->getBeneficiaryCategoryId(), $comparison);
        } elseif ($beneficiaryCategory instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_BENEFICIARY_CATEGORY_ID, $beneficiaryCategory->toKeyValue('PrimaryKey', 'BeneficiaryCategoryId'), $comparison);
        } else {
            throw new PropelException('filterByBeneficiaryCategory() only accepts arguments of type \BeneficiaryCategory or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the BeneficiaryCategory relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function joinBeneficiaryCategory($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('BeneficiaryCategory');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'BeneficiaryCategory');
        }

        return $this;
    }

    /**
     * Use the BeneficiaryCategory relation BeneficiaryCategory object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \BeneficiaryCategoryQuery A secondary query class using the current class as primary query
     */
    public function useBeneficiaryCategoryQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinBeneficiaryCategory($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'BeneficiaryCategory', '\BeneficiaryCategoryQuery');
    }

    /**
     * Filter the query by a related \Principle object
     *
     * @param \Principle|ObjectCollection $principle The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function filterByPrinciple($principle, $comparison = null)
    {
        if ($principle instanceof \Principle) {
            return $this
                ->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_PRINCIPLE_ID, $principle->getPrincipleId(), $comparison);
        } elseif ($principle instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(BeneficiaryCategoryAllocationTableMap::COL_PRINCIPLE_ID, $principle->toKeyValue('PrimaryKey', 'PrincipleId'), $comparison);
        } else {
            throw new PropelException('filterByPrinciple() only accepts arguments of type \Principle or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the Principle relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function joinPrinciple($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('Principle');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'Principle');
        }

        return $this;
    }

    /**
     * Use the Principle relation Principle object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \PrincipleQuery A secondary query class using the current class as primary query
     */
    public function usePrincipleQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinPrinciple($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'Principle', '\PrincipleQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   ChildBeneficiaryCategoryAllocation $beneficiaryCategoryAllocation Object to remove from the list of results
     *
     * @return $this|ChildBeneficiaryCategoryAllocationQuery The current query, for fluid interface
     */
    public function prune($beneficiaryCategoryAllocation = null)
    {
        if ($beneficiaryCategoryAllocation) {
            $this->addCond('pruneCond0', $this->getAliasedColName(BeneficiaryCategoryAllocationTableMap::COL_BENEFICIARY_CAT_ALLOCATION_GROUP_ID), $beneficiaryCategoryAllocation->getBeneficiaryCatAllocationGroupId(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond1', $this->getAliasedColName(BeneficiaryCategoryAllocationTableMap::COL_BENEFICIARY_CATEGORY_ID), $beneficiaryCategoryAllocation->getBeneficiaryCategoryId(), Criteria::NOT_EQUAL);
            $this->combine(array('pruneCond0', 'pruneCond1'), Criteria::LOGICAL_OR);
        }

        return $this;
    }

    /**
     * Deletes all rows from the beneficiary_category_allocation table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(BeneficiaryCategoryAllocationTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            BeneficiaryCategoryAllocationTableMap::clearInstancePool();
            BeneficiaryCategoryAllocationTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(BeneficiaryCategoryAllocationTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(BeneficiaryCategoryAllocationTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            
            BeneficiaryCategoryAllocationTableMap::removeInstanceFromPool($criteria);
        
            $affectedRows += ModelCriteria::delete($con);
            BeneficiaryCategoryAllocationTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // BeneficiaryCategoryAllocationQuery
