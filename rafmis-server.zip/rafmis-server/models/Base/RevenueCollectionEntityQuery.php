<?php

namespace Base;

use \RevenueCollectionEntity as ChildRevenueCollectionEntity;
use \RevenueCollectionEntityQuery as ChildRevenueCollectionEntityQuery;
use \Exception;
use \PDO;
use Map\RevenueCollectionEntityTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'revenue_collection_entity' table.
 *
 * 
 *
 * @method     ChildRevenueCollectionEntityQuery orderByMdaCode($order = Criteria::ASC) Order by the mda_code column
 * @method     ChildRevenueCollectionEntityQuery orderByDescription($order = Criteria::ASC) Order by the description column
 * @method     ChildRevenueCollectionEntityQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method     ChildRevenueCollectionEntityQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method     ChildRevenueCollectionEntityQuery orderByDateModified($order = Criteria::ASC) Order by the date_modified column
 * @method     ChildRevenueCollectionEntityQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method     ChildRevenueCollectionEntityQuery groupByMdaCode() Group by the mda_code column
 * @method     ChildRevenueCollectionEntityQuery groupByDescription() Group by the description column
 * @method     ChildRevenueCollectionEntityQuery groupByDateCreated() Group by the date_created column
 * @method     ChildRevenueCollectionEntityQuery groupByCreatedBy() Group by the created_by column
 * @method     ChildRevenueCollectionEntityQuery groupByDateModified() Group by the date_modified column
 * @method     ChildRevenueCollectionEntityQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method     ChildRevenueCollectionEntityQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildRevenueCollectionEntityQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildRevenueCollectionEntityQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildRevenueCollectionEntityQuery leftJoinInhouseRevenueCollection($relationAlias = null) Adds a LEFT JOIN clause to the query using the InhouseRevenueCollection relation
 * @method     ChildRevenueCollectionEntityQuery rightJoinInhouseRevenueCollection($relationAlias = null) Adds a RIGHT JOIN clause to the query using the InhouseRevenueCollection relation
 * @method     ChildRevenueCollectionEntityQuery innerJoinInhouseRevenueCollection($relationAlias = null) Adds a INNER JOIN clause to the query using the InhouseRevenueCollection relation
 *
 * @method     ChildRevenueCollectionEntityQuery leftJoinRevenueCollection($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueCollection relation
 * @method     ChildRevenueCollectionEntityQuery rightJoinRevenueCollection($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueCollection relation
 * @method     ChildRevenueCollectionEntityQuery innerJoinRevenueCollection($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueCollection relation
 *
 * @method     ChildRevenueCollectionEntityQuery leftJoinRevenueHead($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueHead relation
 * @method     ChildRevenueCollectionEntityQuery rightJoinRevenueHead($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueHead relation
 * @method     ChildRevenueCollectionEntityQuery innerJoinRevenueHead($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueHead relation
 *
 * @method     ChildRevenueCollectionEntityQuery leftJoinRevenueHeadCollection($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueHeadCollection relation
 * @method     ChildRevenueCollectionEntityQuery rightJoinRevenueHeadCollection($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueHeadCollection relation
 * @method     ChildRevenueCollectionEntityQuery innerJoinRevenueHeadCollection($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueHeadCollection relation
 *
 * @method     ChildRevenueCollectionEntityQuery leftJoinRevenueHeadRemittance($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueHeadRemittance relation
 * @method     ChildRevenueCollectionEntityQuery rightJoinRevenueHeadRemittance($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueHeadRemittance relation
 * @method     ChildRevenueCollectionEntityQuery innerJoinRevenueHeadRemittance($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueHeadRemittance relation
 *
 * @method     \InhouseRevenueCollectionQuery|\RevenueCollectionQuery|\RevenueHeadQuery|\RevenueHeadCollectionQuery|\RevenueHeadRemittanceQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildRevenueCollectionEntity findOne(ConnectionInterface $con = null) Return the first ChildRevenueCollectionEntity matching the query
 * @method     ChildRevenueCollectionEntity findOneOrCreate(ConnectionInterface $con = null) Return the first ChildRevenueCollectionEntity matching the query, or a new ChildRevenueCollectionEntity object populated from the query conditions when no match is found
 *
 * @method     ChildRevenueCollectionEntity findOneByMdaCode(string $mda_code) Return the first ChildRevenueCollectionEntity filtered by the mda_code column
 * @method     ChildRevenueCollectionEntity findOneByDescription(string $description) Return the first ChildRevenueCollectionEntity filtered by the description column
 * @method     ChildRevenueCollectionEntity findOneByDateCreated(string $date_created) Return the first ChildRevenueCollectionEntity filtered by the date_created column
 * @method     ChildRevenueCollectionEntity findOneByCreatedBy(string $created_by) Return the first ChildRevenueCollectionEntity filtered by the created_by column
 * @method     ChildRevenueCollectionEntity findOneByDateModified(string $date_modified) Return the first ChildRevenueCollectionEntity filtered by the date_modified column
 * @method     ChildRevenueCollectionEntity findOneByModifiedBy(string $modified_by) Return the first ChildRevenueCollectionEntity filtered by the modified_by column *

 * @method     ChildRevenueCollectionEntity requirePk($key, ConnectionInterface $con = null) Return the ChildRevenueCollectionEntity by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollectionEntity requireOne(ConnectionInterface $con = null) Return the first ChildRevenueCollectionEntity matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildRevenueCollectionEntity requireOneByMdaCode(string $mda_code) Return the first ChildRevenueCollectionEntity filtered by the mda_code column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollectionEntity requireOneByDescription(string $description) Return the first ChildRevenueCollectionEntity filtered by the description column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollectionEntity requireOneByDateCreated(string $date_created) Return the first ChildRevenueCollectionEntity filtered by the date_created column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollectionEntity requireOneByCreatedBy(string $created_by) Return the first ChildRevenueCollectionEntity filtered by the created_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollectionEntity requireOneByDateModified(string $date_modified) Return the first ChildRevenueCollectionEntity filtered by the date_modified column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueCollectionEntity requireOneByModifiedBy(string $modified_by) Return the first ChildRevenueCollectionEntity filtered by the modified_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildRevenueCollectionEntity[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildRevenueCollectionEntity objects based on current ModelCriteria
 * @method     ChildRevenueCollectionEntity[]|ObjectCollection findByMdaCode(string $mda_code) Return ChildRevenueCollectionEntity objects filtered by the mda_code column
 * @method     ChildRevenueCollectionEntity[]|ObjectCollection findByDescription(string $description) Return ChildRevenueCollectionEntity objects filtered by the description column
 * @method     ChildRevenueCollectionEntity[]|ObjectCollection findByDateCreated(string $date_created) Return ChildRevenueCollectionEntity objects filtered by the date_created column
 * @method     ChildRevenueCollectionEntity[]|ObjectCollection findByCreatedBy(string $created_by) Return ChildRevenueCollectionEntity objects filtered by the created_by column
 * @method     ChildRevenueCollectionEntity[]|ObjectCollection findByDateModified(string $date_modified) Return ChildRevenueCollectionEntity objects filtered by the date_modified column
 * @method     ChildRevenueCollectionEntity[]|ObjectCollection findByModifiedBy(string $modified_by) Return ChildRevenueCollectionEntity objects filtered by the modified_by column
 * @method     ChildRevenueCollectionEntity[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class RevenueCollectionEntityQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Base\RevenueCollectionEntityQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'rafmis', $modelName = '\\RevenueCollectionEntity', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildRevenueCollectionEntityQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildRevenueCollectionEntityQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildRevenueCollectionEntityQuery) {
            return $criteria;
        }
        $query = new ChildRevenueCollectionEntityQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildRevenueCollectionEntity|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = RevenueCollectionEntityTableMap::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(RevenueCollectionEntityTableMap::DATABASE_NAME);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenueCollectionEntity A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT mda_code, description, date_created, created_by, date_modified, modified_by FROM revenue_collection_entity WHERE mda_code = :p0';
        try {
            $stmt = $con->prepare($sql);            
            $stmt->bindValue(':p0', $key, PDO::PARAM_STR);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildRevenueCollectionEntity $obj */
            $obj = new ChildRevenueCollectionEntity();
            $obj->hydrate($row);
            RevenueCollectionEntityTableMap::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildRevenueCollectionEntity|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(RevenueCollectionEntityTableMap::COL_MDA_CODE, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(RevenueCollectionEntityTableMap::COL_MDA_CODE, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the mda_code column
     *
     * Example usage:
     * <code>
     * $query->filterByMdaCode('fooValue');   // WHERE mda_code = 'fooValue'
     * $query->filterByMdaCode('%fooValue%'); // WHERE mda_code LIKE '%fooValue%'
     * </code>
     *
     * @param     string $mdaCode The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function filterByMdaCode($mdaCode = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($mdaCode)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $mdaCode)) {
                $mdaCode = str_replace('*', '%', $mdaCode);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueCollectionEntityTableMap::COL_MDA_CODE, $mdaCode, $comparison);
    }

    /**
     * Filter the query on the description column
     *
     * Example usage:
     * <code>
     * $query->filterByDescription('fooValue');   // WHERE description = 'fooValue'
     * $query->filterByDescription('%fooValue%'); // WHERE description LIKE '%fooValue%'
     * </code>
     *
     * @param     string $description The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function filterByDescription($description = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($description)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $description)) {
                $description = str_replace('*', '%', $description);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueCollectionEntityTableMap::COL_DESCRIPTION, $description, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(RevenueCollectionEntityTableMap::COL_DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(RevenueCollectionEntityTableMap::COL_DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueCollectionEntityTableMap::COL_DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy('fooValue');   // WHERE created_by = 'fooValue'
     * $query->filterByCreatedBy('%fooValue%'); // WHERE created_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $createdBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($createdBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $createdBy)) {
                $createdBy = str_replace('*', '%', $createdBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueCollectionEntityTableMap::COL_CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the date_modified column
     *
     * Example usage:
     * <code>
     * $query->filterByDateModified('2011-03-14'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified('now'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified(array('max' => 'yesterday')); // WHERE date_modified > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateModified The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function filterByDateModified($dateModified = null, $comparison = null)
    {
        if (is_array($dateModified)) {
            $useMinMax = false;
            if (isset($dateModified['min'])) {
                $this->addUsingAlias(RevenueCollectionEntityTableMap::COL_DATE_MODIFIED, $dateModified['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateModified['max'])) {
                $this->addUsingAlias(RevenueCollectionEntityTableMap::COL_DATE_MODIFIED, $dateModified['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueCollectionEntityTableMap::COL_DATE_MODIFIED, $dateModified, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy('fooValue');   // WHERE modified_by = 'fooValue'
     * $query->filterByModifiedBy('%fooValue%'); // WHERE modified_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $modifiedBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($modifiedBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $modifiedBy)) {
                $modifiedBy = str_replace('*', '%', $modifiedBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueCollectionEntityTableMap::COL_MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related \InhouseRevenueCollection object
     *
     * @param \InhouseRevenueCollection|ObjectCollection $inhouseRevenueCollection the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function filterByInhouseRevenueCollection($inhouseRevenueCollection, $comparison = null)
    {
        if ($inhouseRevenueCollection instanceof \InhouseRevenueCollection) {
            return $this
                ->addUsingAlias(RevenueCollectionEntityTableMap::COL_MDA_CODE, $inhouseRevenueCollection->getMdaCode(), $comparison);
        } elseif ($inhouseRevenueCollection instanceof ObjectCollection) {
            return $this
                ->useInhouseRevenueCollectionQuery()
                ->filterByPrimaryKeys($inhouseRevenueCollection->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByInhouseRevenueCollection() only accepts arguments of type \InhouseRevenueCollection or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the InhouseRevenueCollection relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function joinInhouseRevenueCollection($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('InhouseRevenueCollection');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'InhouseRevenueCollection');
        }

        return $this;
    }

    /**
     * Use the InhouseRevenueCollection relation InhouseRevenueCollection object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \InhouseRevenueCollectionQuery A secondary query class using the current class as primary query
     */
    public function useInhouseRevenueCollectionQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinInhouseRevenueCollection($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'InhouseRevenueCollection', '\InhouseRevenueCollectionQuery');
    }

    /**
     * Filter the query by a related \RevenueCollection object
     *
     * @param \RevenueCollection|ObjectCollection $revenueCollection the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function filterByRevenueCollection($revenueCollection, $comparison = null)
    {
        if ($revenueCollection instanceof \RevenueCollection) {
            return $this
                ->addUsingAlias(RevenueCollectionEntityTableMap::COL_MDA_CODE, $revenueCollection->getMdaCode(), $comparison);
        } elseif ($revenueCollection instanceof ObjectCollection) {
            return $this
                ->useRevenueCollectionQuery()
                ->filterByPrimaryKeys($revenueCollection->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByRevenueCollection() only accepts arguments of type \RevenueCollection or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueCollection relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function joinRevenueCollection($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueCollection');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueCollection');
        }

        return $this;
    }

    /**
     * Use the RevenueCollection relation RevenueCollection object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueCollectionQuery A secondary query class using the current class as primary query
     */
    public function useRevenueCollectionQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueCollection($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueCollection', '\RevenueCollectionQuery');
    }

    /**
     * Filter the query by a related \RevenueHead object
     *
     * @param \RevenueHead|ObjectCollection $revenueHead the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function filterByRevenueHead($revenueHead, $comparison = null)
    {
        if ($revenueHead instanceof \RevenueHead) {
            return $this
                ->addUsingAlias(RevenueCollectionEntityTableMap::COL_MDA_CODE, $revenueHead->getMdaCode(), $comparison);
        } elseif ($revenueHead instanceof ObjectCollection) {
            return $this
                ->useRevenueHeadQuery()
                ->filterByPrimaryKeys($revenueHead->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByRevenueHead() only accepts arguments of type \RevenueHead or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueHead relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function joinRevenueHead($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueHead');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueHead');
        }

        return $this;
    }

    /**
     * Use the RevenueHead relation RevenueHead object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueHeadQuery A secondary query class using the current class as primary query
     */
    public function useRevenueHeadQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueHead($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueHead', '\RevenueHeadQuery');
    }

    /**
     * Filter the query by a related \RevenueHeadCollection object
     *
     * @param \RevenueHeadCollection|ObjectCollection $revenueHeadCollection the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function filterByRevenueHeadCollection($revenueHeadCollection, $comparison = null)
    {
        if ($revenueHeadCollection instanceof \RevenueHeadCollection) {
            return $this
                ->addUsingAlias(RevenueCollectionEntityTableMap::COL_MDA_CODE, $revenueHeadCollection->getMdaCode(), $comparison);
        } elseif ($revenueHeadCollection instanceof ObjectCollection) {
            return $this
                ->useRevenueHeadCollectionQuery()
                ->filterByPrimaryKeys($revenueHeadCollection->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByRevenueHeadCollection() only accepts arguments of type \RevenueHeadCollection or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueHeadCollection relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function joinRevenueHeadCollection($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueHeadCollection');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueHeadCollection');
        }

        return $this;
    }

    /**
     * Use the RevenueHeadCollection relation RevenueHeadCollection object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueHeadCollectionQuery A secondary query class using the current class as primary query
     */
    public function useRevenueHeadCollectionQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueHeadCollection($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueHeadCollection', '\RevenueHeadCollectionQuery');
    }

    /**
     * Filter the query by a related \RevenueHeadRemittance object
     *
     * @param \RevenueHeadRemittance|ObjectCollection $revenueHeadRemittance the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function filterByRevenueHeadRemittance($revenueHeadRemittance, $comparison = null)
    {
        if ($revenueHeadRemittance instanceof \RevenueHeadRemittance) {
            return $this
                ->addUsingAlias(RevenueCollectionEntityTableMap::COL_MDA_CODE, $revenueHeadRemittance->getMdaCode(), $comparison);
        } elseif ($revenueHeadRemittance instanceof ObjectCollection) {
            return $this
                ->useRevenueHeadRemittanceQuery()
                ->filterByPrimaryKeys($revenueHeadRemittance->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByRevenueHeadRemittance() only accepts arguments of type \RevenueHeadRemittance or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueHeadRemittance relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function joinRevenueHeadRemittance($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueHeadRemittance');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueHeadRemittance');
        }

        return $this;
    }

    /**
     * Use the RevenueHeadRemittance relation RevenueHeadRemittance object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueHeadRemittanceQuery A secondary query class using the current class as primary query
     */
    public function useRevenueHeadRemittanceQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueHeadRemittance($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueHeadRemittance', '\RevenueHeadRemittanceQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   ChildRevenueCollectionEntity $revenueCollectionEntity Object to remove from the list of results
     *
     * @return $this|ChildRevenueCollectionEntityQuery The current query, for fluid interface
     */
    public function prune($revenueCollectionEntity = null)
    {
        if ($revenueCollectionEntity) {
            $this->addUsingAlias(RevenueCollectionEntityTableMap::COL_MDA_CODE, $revenueCollectionEntity->getMdaCode(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the revenue_collection_entity table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RevenueCollectionEntityTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            RevenueCollectionEntityTableMap::clearInstancePool();
            RevenueCollectionEntityTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RevenueCollectionEntityTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(RevenueCollectionEntityTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            
            RevenueCollectionEntityTableMap::removeInstanceFromPool($criteria);
        
            $affectedRows += ModelCriteria::delete($con);
            RevenueCollectionEntityTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // RevenueCollectionEntityQuery
