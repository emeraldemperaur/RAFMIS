<?php

namespace Base;

use \RevenueHead as ChildRevenueHead;
use \RevenueHeadQuery as ChildRevenueHeadQuery;
use \Exception;
use \PDO;
use Map\RevenueHeadTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'revenue_head' table.
 *
 * 
 *
 * @method     ChildRevenueHeadQuery orderByRevenueHeadId($order = Criteria::ASC) Order by the revenue_head_id column
 * @method     ChildRevenueHeadQuery orderByDescription($order = Criteria::ASC) Order by the description column
 * @method     ChildRevenueHeadQuery orderByMdaCode($order = Criteria::ASC) Order by the mda_code column
 * @method     ChildRevenueHeadQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method     ChildRevenueHeadQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method     ChildRevenueHeadQuery orderByDateModified($order = Criteria::ASC) Order by the date_modified column
 * @method     ChildRevenueHeadQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method     ChildRevenueHeadQuery groupByRevenueHeadId() Group by the revenue_head_id column
 * @method     ChildRevenueHeadQuery groupByDescription() Group by the description column
 * @method     ChildRevenueHeadQuery groupByMdaCode() Group by the mda_code column
 * @method     ChildRevenueHeadQuery groupByDateCreated() Group by the date_created column
 * @method     ChildRevenueHeadQuery groupByCreatedBy() Group by the created_by column
 * @method     ChildRevenueHeadQuery groupByDateModified() Group by the date_modified column
 * @method     ChildRevenueHeadQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method     ChildRevenueHeadQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildRevenueHeadQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildRevenueHeadQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildRevenueHeadQuery leftJoinRevenueCollectionEntity($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueCollectionEntity relation
 * @method     ChildRevenueHeadQuery rightJoinRevenueCollectionEntity($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueCollectionEntity relation
 * @method     ChildRevenueHeadQuery innerJoinRevenueCollectionEntity($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueCollectionEntity relation
 *
 * @method     ChildRevenueHeadQuery leftJoinInhouseRevenueCollection($relationAlias = null) Adds a LEFT JOIN clause to the query using the InhouseRevenueCollection relation
 * @method     ChildRevenueHeadQuery rightJoinInhouseRevenueCollection($relationAlias = null) Adds a RIGHT JOIN clause to the query using the InhouseRevenueCollection relation
 * @method     ChildRevenueHeadQuery innerJoinInhouseRevenueCollection($relationAlias = null) Adds a INNER JOIN clause to the query using the InhouseRevenueCollection relation
 *
 * @method     ChildRevenueHeadQuery leftJoinRevenueCollection($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueCollection relation
 * @method     ChildRevenueHeadQuery rightJoinRevenueCollection($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueCollection relation
 * @method     ChildRevenueHeadQuery innerJoinRevenueCollection($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueCollection relation
 *
 * @method     ChildRevenueHeadQuery leftJoinRevenueHeadCollection($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueHeadCollection relation
 * @method     ChildRevenueHeadQuery rightJoinRevenueHeadCollection($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueHeadCollection relation
 * @method     ChildRevenueHeadQuery innerJoinRevenueHeadCollection($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueHeadCollection relation
 *
 * @method     ChildRevenueHeadQuery leftJoinRevenueHeadRemittance($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueHeadRemittance relation
 * @method     ChildRevenueHeadQuery rightJoinRevenueHeadRemittance($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueHeadRemittance relation
 * @method     ChildRevenueHeadQuery innerJoinRevenueHeadRemittance($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueHeadRemittance relation
 *
 * @method     \RevenueCollectionEntityQuery|\InhouseRevenueCollectionQuery|\RevenueCollectionQuery|\RevenueHeadCollectionQuery|\RevenueHeadRemittanceQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildRevenueHead findOne(ConnectionInterface $con = null) Return the first ChildRevenueHead matching the query
 * @method     ChildRevenueHead findOneOrCreate(ConnectionInterface $con = null) Return the first ChildRevenueHead matching the query, or a new ChildRevenueHead object populated from the query conditions when no match is found
 *
 * @method     ChildRevenueHead findOneByRevenueHeadId(string $revenue_head_id) Return the first ChildRevenueHead filtered by the revenue_head_id column
 * @method     ChildRevenueHead findOneByDescription(string $description) Return the first ChildRevenueHead filtered by the description column
 * @method     ChildRevenueHead findOneByMdaCode(string $mda_code) Return the first ChildRevenueHead filtered by the mda_code column
 * @method     ChildRevenueHead findOneByDateCreated(string $date_created) Return the first ChildRevenueHead filtered by the date_created column
 * @method     ChildRevenueHead findOneByCreatedBy(string $created_by) Return the first ChildRevenueHead filtered by the created_by column
 * @method     ChildRevenueHead findOneByDateModified(string $date_modified) Return the first ChildRevenueHead filtered by the date_modified column
 * @method     ChildRevenueHead findOneByModifiedBy(string $modified_by) Return the first ChildRevenueHead filtered by the modified_by column *

 * @method     ChildRevenueHead requirePk($key, ConnectionInterface $con = null) Return the ChildRevenueHead by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHead requireOne(ConnectionInterface $con = null) Return the first ChildRevenueHead matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildRevenueHead requireOneByRevenueHeadId(string $revenue_head_id) Return the first ChildRevenueHead filtered by the revenue_head_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHead requireOneByDescription(string $description) Return the first ChildRevenueHead filtered by the description column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHead requireOneByMdaCode(string $mda_code) Return the first ChildRevenueHead filtered by the mda_code column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHead requireOneByDateCreated(string $date_created) Return the first ChildRevenueHead filtered by the date_created column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHead requireOneByCreatedBy(string $created_by) Return the first ChildRevenueHead filtered by the created_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHead requireOneByDateModified(string $date_modified) Return the first ChildRevenueHead filtered by the date_modified column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHead requireOneByModifiedBy(string $modified_by) Return the first ChildRevenueHead filtered by the modified_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildRevenueHead[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildRevenueHead objects based on current ModelCriteria
 * @method     ChildRevenueHead[]|ObjectCollection findByRevenueHeadId(string $revenue_head_id) Return ChildRevenueHead objects filtered by the revenue_head_id column
 * @method     ChildRevenueHead[]|ObjectCollection findByDescription(string $description) Return ChildRevenueHead objects filtered by the description column
 * @method     ChildRevenueHead[]|ObjectCollection findByMdaCode(string $mda_code) Return ChildRevenueHead objects filtered by the mda_code column
 * @method     ChildRevenueHead[]|ObjectCollection findByDateCreated(string $date_created) Return ChildRevenueHead objects filtered by the date_created column
 * @method     ChildRevenueHead[]|ObjectCollection findByCreatedBy(string $created_by) Return ChildRevenueHead objects filtered by the created_by column
 * @method     ChildRevenueHead[]|ObjectCollection findByDateModified(string $date_modified) Return ChildRevenueHead objects filtered by the date_modified column
 * @method     ChildRevenueHead[]|ObjectCollection findByModifiedBy(string $modified_by) Return ChildRevenueHead objects filtered by the modified_by column
 * @method     ChildRevenueHead[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class RevenueHeadQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Base\RevenueHeadQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'rafmis', $modelName = '\\RevenueHead', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildRevenueHeadQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildRevenueHeadQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildRevenueHeadQuery) {
            return $criteria;
        }
        $query = new ChildRevenueHeadQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildRevenueHead|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = RevenueHeadTableMap::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(RevenueHeadTableMap::DATABASE_NAME);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenueHead A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT revenue_head_id, description, mda_code, date_created, created_by, date_modified, modified_by FROM revenue_head WHERE revenue_head_id = :p0';
        try {
            $stmt = $con->prepare($sql);            
            $stmt->bindValue(':p0', $key, PDO::PARAM_STR);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildRevenueHead $obj */
            $obj = new ChildRevenueHead();
            $obj->hydrate($row);
            RevenueHeadTableMap::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildRevenueHead|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(RevenueHeadTableMap::COL_REVENUE_HEAD_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(RevenueHeadTableMap::COL_REVENUE_HEAD_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the revenue_head_id column
     *
     * Example usage:
     * <code>
     * $query->filterByRevenueHeadId('fooValue');   // WHERE revenue_head_id = 'fooValue'
     * $query->filterByRevenueHeadId('%fooValue%'); // WHERE revenue_head_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $revenueHeadId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByRevenueHeadId($revenueHeadId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($revenueHeadId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $revenueHeadId)) {
                $revenueHeadId = str_replace('*', '%', $revenueHeadId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueHeadTableMap::COL_REVENUE_HEAD_ID, $revenueHeadId, $comparison);
    }

    /**
     * Filter the query on the description column
     *
     * Example usage:
     * <code>
     * $query->filterByDescription('fooValue');   // WHERE description = 'fooValue'
     * $query->filterByDescription('%fooValue%'); // WHERE description LIKE '%fooValue%'
     * </code>
     *
     * @param     string $description The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByDescription($description = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($description)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $description)) {
                $description = str_replace('*', '%', $description);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueHeadTableMap::COL_DESCRIPTION, $description, $comparison);
    }

    /**
     * Filter the query on the mda_code column
     *
     * Example usage:
     * <code>
     * $query->filterByMdaCode('fooValue');   // WHERE mda_code = 'fooValue'
     * $query->filterByMdaCode('%fooValue%'); // WHERE mda_code LIKE '%fooValue%'
     * </code>
     *
     * @param     string $mdaCode The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByMdaCode($mdaCode = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($mdaCode)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $mdaCode)) {
                $mdaCode = str_replace('*', '%', $mdaCode);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueHeadTableMap::COL_MDA_CODE, $mdaCode, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(RevenueHeadTableMap::COL_DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(RevenueHeadTableMap::COL_DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueHeadTableMap::COL_DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy('fooValue');   // WHERE created_by = 'fooValue'
     * $query->filterByCreatedBy('%fooValue%'); // WHERE created_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $createdBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($createdBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $createdBy)) {
                $createdBy = str_replace('*', '%', $createdBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueHeadTableMap::COL_CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the date_modified column
     *
     * Example usage:
     * <code>
     * $query->filterByDateModified('2011-03-14'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified('now'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified(array('max' => 'yesterday')); // WHERE date_modified > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateModified The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByDateModified($dateModified = null, $comparison = null)
    {
        if (is_array($dateModified)) {
            $useMinMax = false;
            if (isset($dateModified['min'])) {
                $this->addUsingAlias(RevenueHeadTableMap::COL_DATE_MODIFIED, $dateModified['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateModified['max'])) {
                $this->addUsingAlias(RevenueHeadTableMap::COL_DATE_MODIFIED, $dateModified['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueHeadTableMap::COL_DATE_MODIFIED, $dateModified, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy('fooValue');   // WHERE modified_by = 'fooValue'
     * $query->filterByModifiedBy('%fooValue%'); // WHERE modified_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $modifiedBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($modifiedBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $modifiedBy)) {
                $modifiedBy = str_replace('*', '%', $modifiedBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueHeadTableMap::COL_MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related \RevenueCollectionEntity object
     *
     * @param \RevenueCollectionEntity|ObjectCollection $revenueCollectionEntity The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByRevenueCollectionEntity($revenueCollectionEntity, $comparison = null)
    {
        if ($revenueCollectionEntity instanceof \RevenueCollectionEntity) {
            return $this
                ->addUsingAlias(RevenueHeadTableMap::COL_MDA_CODE, $revenueCollectionEntity->getMdaCode(), $comparison);
        } elseif ($revenueCollectionEntity instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(RevenueHeadTableMap::COL_MDA_CODE, $revenueCollectionEntity->toKeyValue('PrimaryKey', 'MdaCode'), $comparison);
        } else {
            throw new PropelException('filterByRevenueCollectionEntity() only accepts arguments of type \RevenueCollectionEntity or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueCollectionEntity relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function joinRevenueCollectionEntity($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueCollectionEntity');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueCollectionEntity');
        }

        return $this;
    }

    /**
     * Use the RevenueCollectionEntity relation RevenueCollectionEntity object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueCollectionEntityQuery A secondary query class using the current class as primary query
     */
    public function useRevenueCollectionEntityQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueCollectionEntity($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueCollectionEntity', '\RevenueCollectionEntityQuery');
    }

    /**
     * Filter the query by a related \InhouseRevenueCollection object
     *
     * @param \InhouseRevenueCollection|ObjectCollection $inhouseRevenueCollection the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByInhouseRevenueCollection($inhouseRevenueCollection, $comparison = null)
    {
        if ($inhouseRevenueCollection instanceof \InhouseRevenueCollection) {
            return $this
                ->addUsingAlias(RevenueHeadTableMap::COL_REVENUE_HEAD_ID, $inhouseRevenueCollection->getRevenueHeadId(), $comparison);
        } elseif ($inhouseRevenueCollection instanceof ObjectCollection) {
            return $this
                ->useInhouseRevenueCollectionQuery()
                ->filterByPrimaryKeys($inhouseRevenueCollection->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByInhouseRevenueCollection() only accepts arguments of type \InhouseRevenueCollection or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the InhouseRevenueCollection relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function joinInhouseRevenueCollection($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('InhouseRevenueCollection');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'InhouseRevenueCollection');
        }

        return $this;
    }

    /**
     * Use the InhouseRevenueCollection relation InhouseRevenueCollection object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \InhouseRevenueCollectionQuery A secondary query class using the current class as primary query
     */
    public function useInhouseRevenueCollectionQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinInhouseRevenueCollection($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'InhouseRevenueCollection', '\InhouseRevenueCollectionQuery');
    }

    /**
     * Filter the query by a related \RevenueCollection object
     *
     * @param \RevenueCollection|ObjectCollection $revenueCollection the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByRevenueCollection($revenueCollection, $comparison = null)
    {
        if ($revenueCollection instanceof \RevenueCollection) {
            return $this
                ->addUsingAlias(RevenueHeadTableMap::COL_REVENUE_HEAD_ID, $revenueCollection->getRevenueHeadId(), $comparison);
        } elseif ($revenueCollection instanceof ObjectCollection) {
            return $this
                ->useRevenueCollectionQuery()
                ->filterByPrimaryKeys($revenueCollection->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByRevenueCollection() only accepts arguments of type \RevenueCollection or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueCollection relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function joinRevenueCollection($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueCollection');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueCollection');
        }

        return $this;
    }

    /**
     * Use the RevenueCollection relation RevenueCollection object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueCollectionQuery A secondary query class using the current class as primary query
     */
    public function useRevenueCollectionQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueCollection($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueCollection', '\RevenueCollectionQuery');
    }

    /**
     * Filter the query by a related \RevenueHeadCollection object
     *
     * @param \RevenueHeadCollection|ObjectCollection $revenueHeadCollection the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByRevenueHeadCollection($revenueHeadCollection, $comparison = null)
    {
        if ($revenueHeadCollection instanceof \RevenueHeadCollection) {
            return $this
                ->addUsingAlias(RevenueHeadTableMap::COL_REVENUE_HEAD_ID, $revenueHeadCollection->getRevenueHeadId(), $comparison);
        } elseif ($revenueHeadCollection instanceof ObjectCollection) {
            return $this
                ->useRevenueHeadCollectionQuery()
                ->filterByPrimaryKeys($revenueHeadCollection->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByRevenueHeadCollection() only accepts arguments of type \RevenueHeadCollection or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueHeadCollection relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function joinRevenueHeadCollection($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueHeadCollection');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueHeadCollection');
        }

        return $this;
    }

    /**
     * Use the RevenueHeadCollection relation RevenueHeadCollection object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueHeadCollectionQuery A secondary query class using the current class as primary query
     */
    public function useRevenueHeadCollectionQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueHeadCollection($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueHeadCollection', '\RevenueHeadCollectionQuery');
    }

    /**
     * Filter the query by a related \RevenueHeadRemittance object
     *
     * @param \RevenueHeadRemittance|ObjectCollection $revenueHeadRemittance the related object to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function filterByRevenueHeadRemittance($revenueHeadRemittance, $comparison = null)
    {
        if ($revenueHeadRemittance instanceof \RevenueHeadRemittance) {
            return $this
                ->addUsingAlias(RevenueHeadTableMap::COL_REVENUE_HEAD_ID, $revenueHeadRemittance->getRevenueHeadId(), $comparison);
        } elseif ($revenueHeadRemittance instanceof ObjectCollection) {
            return $this
                ->useRevenueHeadRemittanceQuery()
                ->filterByPrimaryKeys($revenueHeadRemittance->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByRevenueHeadRemittance() only accepts arguments of type \RevenueHeadRemittance or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueHeadRemittance relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function joinRevenueHeadRemittance($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueHeadRemittance');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueHeadRemittance');
        }

        return $this;
    }

    /**
     * Use the RevenueHeadRemittance relation RevenueHeadRemittance object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueHeadRemittanceQuery A secondary query class using the current class as primary query
     */
    public function useRevenueHeadRemittanceQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueHeadRemittance($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueHeadRemittance', '\RevenueHeadRemittanceQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   ChildRevenueHead $revenueHead Object to remove from the list of results
     *
     * @return $this|ChildRevenueHeadQuery The current query, for fluid interface
     */
    public function prune($revenueHead = null)
    {
        if ($revenueHead) {
            $this->addUsingAlias(RevenueHeadTableMap::COL_REVENUE_HEAD_ID, $revenueHead->getRevenueHeadId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the revenue_head table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RevenueHeadTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            RevenueHeadTableMap::clearInstancePool();
            RevenueHeadTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RevenueHeadTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(RevenueHeadTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            
            RevenueHeadTableMap::removeInstanceFromPool($criteria);
        
            $affectedRows += ModelCriteria::delete($con);
            RevenueHeadTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // RevenueHeadQuery
