<?php

namespace Base;

use \InhouseRevenueCollection as ChildInhouseRevenueCollection;
use \InhouseRevenueCollectionQuery as ChildInhouseRevenueCollectionQuery;
use \Exception;
use \PDO;
use Map\InhouseRevenueCollectionTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'inhouse_revenue_collection' table.
 *
 * 
 *
 * @method     ChildInhouseRevenueCollectionQuery orderByInhouseRevenueCollectionId($order = Criteria::ASC) Order by the inhouse_revenue_collection_id column
 * @method     ChildInhouseRevenueCollectionQuery orderByRevenueHeadId($order = Criteria::ASC) Order by the revenue_head_id column
 * @method     ChildInhouseRevenueCollectionQuery orderByMdaCode($order = Criteria::ASC) Order by the mda_code column
 * @method     ChildInhouseRevenueCollectionQuery orderByExpectedPaymentMonth($order = Criteria::ASC) Order by the expected_payment_month column
 * @method     ChildInhouseRevenueCollectionQuery orderByExpectedPaymentYear($order = Criteria::ASC) Order by the expected_payment_year column
 * @method     ChildInhouseRevenueCollectionQuery orderByAmount($order = Criteria::ASC) Order by the amount column
 * @method     ChildInhouseRevenueCollectionQuery orderByState($order = Criteria::ASC) Order by the state column
 * @method     ChildInhouseRevenueCollectionQuery orderByPayerName($order = Criteria::ASC) Order by the payer_name column
 * @method     ChildInhouseRevenueCollectionQuery orderByRcNumber($order = Criteria::ASC) Order by the rc_number column
 * @method     ChildInhouseRevenueCollectionQuery orderBySourceId($order = Criteria::ASC) Order by the source_id column
 * @method     ChildInhouseRevenueCollectionQuery orderByTinNumber($order = Criteria::ASC) Order by the tin_number column
 * @method     ChildInhouseRevenueCollectionQuery orderByPaymentDate($order = Criteria::ASC) Order by the payment_date column
 * @method     ChildInhouseRevenueCollectionQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method     ChildInhouseRevenueCollectionQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method     ChildInhouseRevenueCollectionQuery orderByDateModified($order = Criteria::ASC) Order by the date_modified column
 * @method     ChildInhouseRevenueCollectionQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method     ChildInhouseRevenueCollectionQuery groupByInhouseRevenueCollectionId() Group by the inhouse_revenue_collection_id column
 * @method     ChildInhouseRevenueCollectionQuery groupByRevenueHeadId() Group by the revenue_head_id column
 * @method     ChildInhouseRevenueCollectionQuery groupByMdaCode() Group by the mda_code column
 * @method     ChildInhouseRevenueCollectionQuery groupByExpectedPaymentMonth() Group by the expected_payment_month column
 * @method     ChildInhouseRevenueCollectionQuery groupByExpectedPaymentYear() Group by the expected_payment_year column
 * @method     ChildInhouseRevenueCollectionQuery groupByAmount() Group by the amount column
 * @method     ChildInhouseRevenueCollectionQuery groupByState() Group by the state column
 * @method     ChildInhouseRevenueCollectionQuery groupByPayerName() Group by the payer_name column
 * @method     ChildInhouseRevenueCollectionQuery groupByRcNumber() Group by the rc_number column
 * @method     ChildInhouseRevenueCollectionQuery groupBySourceId() Group by the source_id column
 * @method     ChildInhouseRevenueCollectionQuery groupByTinNumber() Group by the tin_number column
 * @method     ChildInhouseRevenueCollectionQuery groupByPaymentDate() Group by the payment_date column
 * @method     ChildInhouseRevenueCollectionQuery groupByDateCreated() Group by the date_created column
 * @method     ChildInhouseRevenueCollectionQuery groupByCreatedBy() Group by the created_by column
 * @method     ChildInhouseRevenueCollectionQuery groupByDateModified() Group by the date_modified column
 * @method     ChildInhouseRevenueCollectionQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method     ChildInhouseRevenueCollectionQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildInhouseRevenueCollectionQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildInhouseRevenueCollectionQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildInhouseRevenueCollectionQuery leftJoinRevenueHead($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueHead relation
 * @method     ChildInhouseRevenueCollectionQuery rightJoinRevenueHead($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueHead relation
 * @method     ChildInhouseRevenueCollectionQuery innerJoinRevenueHead($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueHead relation
 *
 * @method     ChildInhouseRevenueCollectionQuery leftJoinRevenueCollectionEntity($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueCollectionEntity relation
 * @method     ChildInhouseRevenueCollectionQuery rightJoinRevenueCollectionEntity($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueCollectionEntity relation
 * @method     ChildInhouseRevenueCollectionQuery innerJoinRevenueCollectionEntity($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueCollectionEntity relation
 *
 * @method     \RevenueHeadQuery|\RevenueCollectionEntityQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildInhouseRevenueCollection findOne(ConnectionInterface $con = null) Return the first ChildInhouseRevenueCollection matching the query
 * @method     ChildInhouseRevenueCollection findOneOrCreate(ConnectionInterface $con = null) Return the first ChildInhouseRevenueCollection matching the query, or a new ChildInhouseRevenueCollection object populated from the query conditions when no match is found
 *
 * @method     ChildInhouseRevenueCollection findOneByInhouseRevenueCollectionId(int $inhouse_revenue_collection_id) Return the first ChildInhouseRevenueCollection filtered by the inhouse_revenue_collection_id column
 * @method     ChildInhouseRevenueCollection findOneByRevenueHeadId(string $revenue_head_id) Return the first ChildInhouseRevenueCollection filtered by the revenue_head_id column
 * @method     ChildInhouseRevenueCollection findOneByMdaCode(string $mda_code) Return the first ChildInhouseRevenueCollection filtered by the mda_code column
 * @method     ChildInhouseRevenueCollection findOneByExpectedPaymentMonth(int $expected_payment_month) Return the first ChildInhouseRevenueCollection filtered by the expected_payment_month column
 * @method     ChildInhouseRevenueCollection findOneByExpectedPaymentYear(int $expected_payment_year) Return the first ChildInhouseRevenueCollection filtered by the expected_payment_year column
 * @method     ChildInhouseRevenueCollection findOneByAmount(double $amount) Return the first ChildInhouseRevenueCollection filtered by the amount column
 * @method     ChildInhouseRevenueCollection findOneByState(string $state) Return the first ChildInhouseRevenueCollection filtered by the state column
 * @method     ChildInhouseRevenueCollection findOneByPayerName(string $payer_name) Return the first ChildInhouseRevenueCollection filtered by the payer_name column
 * @method     ChildInhouseRevenueCollection findOneByRcNumber(string $rc_number) Return the first ChildInhouseRevenueCollection filtered by the rc_number column
 * @method     ChildInhouseRevenueCollection findOneBySourceId(string $source_id) Return the first ChildInhouseRevenueCollection filtered by the source_id column
 * @method     ChildInhouseRevenueCollection findOneByTinNumber(string $tin_number) Return the first ChildInhouseRevenueCollection filtered by the tin_number column
 * @method     ChildInhouseRevenueCollection findOneByPaymentDate(string $payment_date) Return the first ChildInhouseRevenueCollection filtered by the payment_date column
 * @method     ChildInhouseRevenueCollection findOneByDateCreated(string $date_created) Return the first ChildInhouseRevenueCollection filtered by the date_created column
 * @method     ChildInhouseRevenueCollection findOneByCreatedBy(string $created_by) Return the first ChildInhouseRevenueCollection filtered by the created_by column
 * @method     ChildInhouseRevenueCollection findOneByDateModified(string $date_modified) Return the first ChildInhouseRevenueCollection filtered by the date_modified column
 * @method     ChildInhouseRevenueCollection findOneByModifiedBy(string $modified_by) Return the first ChildInhouseRevenueCollection filtered by the modified_by column *

 * @method     ChildInhouseRevenueCollection requirePk($key, ConnectionInterface $con = null) Return the ChildInhouseRevenueCollection by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOne(ConnectionInterface $con = null) Return the first ChildInhouseRevenueCollection matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildInhouseRevenueCollection requireOneByInhouseRevenueCollectionId(int $inhouse_revenue_collection_id) Return the first ChildInhouseRevenueCollection filtered by the inhouse_revenue_collection_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByRevenueHeadId(string $revenue_head_id) Return the first ChildInhouseRevenueCollection filtered by the revenue_head_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByMdaCode(string $mda_code) Return the first ChildInhouseRevenueCollection filtered by the mda_code column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByExpectedPaymentMonth(int $expected_payment_month) Return the first ChildInhouseRevenueCollection filtered by the expected_payment_month column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByExpectedPaymentYear(int $expected_payment_year) Return the first ChildInhouseRevenueCollection filtered by the expected_payment_year column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByAmount(double $amount) Return the first ChildInhouseRevenueCollection filtered by the amount column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByState(string $state) Return the first ChildInhouseRevenueCollection filtered by the state column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByPayerName(string $payer_name) Return the first ChildInhouseRevenueCollection filtered by the payer_name column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByRcNumber(string $rc_number) Return the first ChildInhouseRevenueCollection filtered by the rc_number column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneBySourceId(string $source_id) Return the first ChildInhouseRevenueCollection filtered by the source_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByTinNumber(string $tin_number) Return the first ChildInhouseRevenueCollection filtered by the tin_number column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByPaymentDate(string $payment_date) Return the first ChildInhouseRevenueCollection filtered by the payment_date column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByDateCreated(string $date_created) Return the first ChildInhouseRevenueCollection filtered by the date_created column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByCreatedBy(string $created_by) Return the first ChildInhouseRevenueCollection filtered by the created_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByDateModified(string $date_modified) Return the first ChildInhouseRevenueCollection filtered by the date_modified column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildInhouseRevenueCollection requireOneByModifiedBy(string $modified_by) Return the first ChildInhouseRevenueCollection filtered by the modified_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildInhouseRevenueCollection objects based on current ModelCriteria
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByInhouseRevenueCollectionId(int $inhouse_revenue_collection_id) Return ChildInhouseRevenueCollection objects filtered by the inhouse_revenue_collection_id column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByRevenueHeadId(string $revenue_head_id) Return ChildInhouseRevenueCollection objects filtered by the revenue_head_id column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByMdaCode(string $mda_code) Return ChildInhouseRevenueCollection objects filtered by the mda_code column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByExpectedPaymentMonth(int $expected_payment_month) Return ChildInhouseRevenueCollection objects filtered by the expected_payment_month column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByExpectedPaymentYear(int $expected_payment_year) Return ChildInhouseRevenueCollection objects filtered by the expected_payment_year column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByAmount(double $amount) Return ChildInhouseRevenueCollection objects filtered by the amount column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByState(string $state) Return ChildInhouseRevenueCollection objects filtered by the state column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByPayerName(string $payer_name) Return ChildInhouseRevenueCollection objects filtered by the payer_name column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByRcNumber(string $rc_number) Return ChildInhouseRevenueCollection objects filtered by the rc_number column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findBySourceId(string $source_id) Return ChildInhouseRevenueCollection objects filtered by the source_id column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByTinNumber(string $tin_number) Return ChildInhouseRevenueCollection objects filtered by the tin_number column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByPaymentDate(string $payment_date) Return ChildInhouseRevenueCollection objects filtered by the payment_date column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByDateCreated(string $date_created) Return ChildInhouseRevenueCollection objects filtered by the date_created column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByCreatedBy(string $created_by) Return ChildInhouseRevenueCollection objects filtered by the created_by column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByDateModified(string $date_modified) Return ChildInhouseRevenueCollection objects filtered by the date_modified column
 * @method     ChildInhouseRevenueCollection[]|ObjectCollection findByModifiedBy(string $modified_by) Return ChildInhouseRevenueCollection objects filtered by the modified_by column
 * @method     ChildInhouseRevenueCollection[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class InhouseRevenueCollectionQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Base\InhouseRevenueCollectionQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'rafmis', $modelName = '\\InhouseRevenueCollection', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildInhouseRevenueCollectionQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildInhouseRevenueCollectionQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildInhouseRevenueCollectionQuery) {
            return $criteria;
        }
        $query = new ChildInhouseRevenueCollectionQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildInhouseRevenueCollection|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = InhouseRevenueCollectionTableMap::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(InhouseRevenueCollectionTableMap::DATABASE_NAME);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildInhouseRevenueCollection A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT inhouse_revenue_collection_id, revenue_head_id, mda_code, expected_payment_month, expected_payment_year, amount, state, payer_name, rc_number, source_id, tin_number, payment_date, date_created, created_by, date_modified, modified_by FROM inhouse_revenue_collection WHERE inhouse_revenue_collection_id = :p0';
        try {
            $stmt = $con->prepare($sql);            
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildInhouseRevenueCollection $obj */
            $obj = new ChildInhouseRevenueCollection();
            $obj->hydrate($row);
            InhouseRevenueCollectionTableMap::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildInhouseRevenueCollection|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the inhouse_revenue_collection_id column
     *
     * Example usage:
     * <code>
     * $query->filterByInhouseRevenueCollectionId(1234); // WHERE inhouse_revenue_collection_id = 1234
     * $query->filterByInhouseRevenueCollectionId(array(12, 34)); // WHERE inhouse_revenue_collection_id IN (12, 34)
     * $query->filterByInhouseRevenueCollectionId(array('min' => 12)); // WHERE inhouse_revenue_collection_id > 12
     * </code>
     *
     * @param     mixed $inhouseRevenueCollectionId The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByInhouseRevenueCollectionId($inhouseRevenueCollectionId = null, $comparison = null)
    {
        if (is_array($inhouseRevenueCollectionId)) {
            $useMinMax = false;
            if (isset($inhouseRevenueCollectionId['min'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID, $inhouseRevenueCollectionId['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($inhouseRevenueCollectionId['max'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID, $inhouseRevenueCollectionId['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID, $inhouseRevenueCollectionId, $comparison);
    }

    /**
     * Filter the query on the revenue_head_id column
     *
     * Example usage:
     * <code>
     * $query->filterByRevenueHeadId('fooValue');   // WHERE revenue_head_id = 'fooValue'
     * $query->filterByRevenueHeadId('%fooValue%'); // WHERE revenue_head_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $revenueHeadId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByRevenueHeadId($revenueHeadId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($revenueHeadId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $revenueHeadId)) {
                $revenueHeadId = str_replace('*', '%', $revenueHeadId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_REVENUE_HEAD_ID, $revenueHeadId, $comparison);
    }

    /**
     * Filter the query on the mda_code column
     *
     * Example usage:
     * <code>
     * $query->filterByMdaCode('fooValue');   // WHERE mda_code = 'fooValue'
     * $query->filterByMdaCode('%fooValue%'); // WHERE mda_code LIKE '%fooValue%'
     * </code>
     *
     * @param     string $mdaCode The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByMdaCode($mdaCode = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($mdaCode)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $mdaCode)) {
                $mdaCode = str_replace('*', '%', $mdaCode);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_MDA_CODE, $mdaCode, $comparison);
    }

    /**
     * Filter the query on the expected_payment_month column
     *
     * Example usage:
     * <code>
     * $query->filterByExpectedPaymentMonth(1234); // WHERE expected_payment_month = 1234
     * $query->filterByExpectedPaymentMonth(array(12, 34)); // WHERE expected_payment_month IN (12, 34)
     * $query->filterByExpectedPaymentMonth(array('min' => 12)); // WHERE expected_payment_month > 12
     * </code>
     *
     * @param     mixed $expectedPaymentMonth The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByExpectedPaymentMonth($expectedPaymentMonth = null, $comparison = null)
    {
        if (is_array($expectedPaymentMonth)) {
            $useMinMax = false;
            if (isset($expectedPaymentMonth['min'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_MONTH, $expectedPaymentMonth['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($expectedPaymentMonth['max'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_MONTH, $expectedPaymentMonth['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_MONTH, $expectedPaymentMonth, $comparison);
    }

    /**
     * Filter the query on the expected_payment_year column
     *
     * Example usage:
     * <code>
     * $query->filterByExpectedPaymentYear(1234); // WHERE expected_payment_year = 1234
     * $query->filterByExpectedPaymentYear(array(12, 34)); // WHERE expected_payment_year IN (12, 34)
     * $query->filterByExpectedPaymentYear(array('min' => 12)); // WHERE expected_payment_year > 12
     * </code>
     *
     * @param     mixed $expectedPaymentYear The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByExpectedPaymentYear($expectedPaymentYear = null, $comparison = null)
    {
        if (is_array($expectedPaymentYear)) {
            $useMinMax = false;
            if (isset($expectedPaymentYear['min'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_YEAR, $expectedPaymentYear['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($expectedPaymentYear['max'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_YEAR, $expectedPaymentYear['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_YEAR, $expectedPaymentYear, $comparison);
    }

    /**
     * Filter the query on the amount column
     *
     * Example usage:
     * <code>
     * $query->filterByAmount(1234); // WHERE amount = 1234
     * $query->filterByAmount(array(12, 34)); // WHERE amount IN (12, 34)
     * $query->filterByAmount(array('min' => 12)); // WHERE amount > 12
     * </code>
     *
     * @param     mixed $amount The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByAmount($amount = null, $comparison = null)
    {
        if (is_array($amount)) {
            $useMinMax = false;
            if (isset($amount['min'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_AMOUNT, $amount['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($amount['max'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_AMOUNT, $amount['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_AMOUNT, $amount, $comparison);
    }

    /**
     * Filter the query on the state column
     *
     * Example usage:
     * <code>
     * $query->filterByState('fooValue');   // WHERE state = 'fooValue'
     * $query->filterByState('%fooValue%'); // WHERE state LIKE '%fooValue%'
     * </code>
     *
     * @param     string $state The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByState($state = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($state)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $state)) {
                $state = str_replace('*', '%', $state);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_STATE, $state, $comparison);
    }

    /**
     * Filter the query on the payer_name column
     *
     * Example usage:
     * <code>
     * $query->filterByPayerName('fooValue');   // WHERE payer_name = 'fooValue'
     * $query->filterByPayerName('%fooValue%'); // WHERE payer_name LIKE '%fooValue%'
     * </code>
     *
     * @param     string $payerName The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByPayerName($payerName = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($payerName)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $payerName)) {
                $payerName = str_replace('*', '%', $payerName);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_PAYER_NAME, $payerName, $comparison);
    }

    /**
     * Filter the query on the rc_number column
     *
     * Example usage:
     * <code>
     * $query->filterByRcNumber('fooValue');   // WHERE rc_number = 'fooValue'
     * $query->filterByRcNumber('%fooValue%'); // WHERE rc_number LIKE '%fooValue%'
     * </code>
     *
     * @param     string $rcNumber The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByRcNumber($rcNumber = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($rcNumber)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $rcNumber)) {
                $rcNumber = str_replace('*', '%', $rcNumber);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_RC_NUMBER, $rcNumber, $comparison);
    }

    /**
     * Filter the query on the source_id column
     *
     * Example usage:
     * <code>
     * $query->filterBySourceId('fooValue');   // WHERE source_id = 'fooValue'
     * $query->filterBySourceId('%fooValue%'); // WHERE source_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $sourceId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterBySourceId($sourceId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($sourceId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $sourceId)) {
                $sourceId = str_replace('*', '%', $sourceId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_SOURCE_ID, $sourceId, $comparison);
    }

    /**
     * Filter the query on the tin_number column
     *
     * Example usage:
     * <code>
     * $query->filterByTinNumber('fooValue');   // WHERE tin_number = 'fooValue'
     * $query->filterByTinNumber('%fooValue%'); // WHERE tin_number LIKE '%fooValue%'
     * </code>
     *
     * @param     string $tinNumber The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByTinNumber($tinNumber = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($tinNumber)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $tinNumber)) {
                $tinNumber = str_replace('*', '%', $tinNumber);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_TIN_NUMBER, $tinNumber, $comparison);
    }

    /**
     * Filter the query on the payment_date column
     *
     * Example usage:
     * <code>
     * $query->filterByPaymentDate('2011-03-14'); // WHERE payment_date = '2011-03-14'
     * $query->filterByPaymentDate('now'); // WHERE payment_date = '2011-03-14'
     * $query->filterByPaymentDate(array('max' => 'yesterday')); // WHERE payment_date > '2011-03-13'
     * </code>
     *
     * @param     mixed $paymentDate The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByPaymentDate($paymentDate = null, $comparison = null)
    {
        if (is_array($paymentDate)) {
            $useMinMax = false;
            if (isset($paymentDate['min'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_PAYMENT_DATE, $paymentDate['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($paymentDate['max'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_PAYMENT_DATE, $paymentDate['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_PAYMENT_DATE, $paymentDate, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy('fooValue');   // WHERE created_by = 'fooValue'
     * $query->filterByCreatedBy('%fooValue%'); // WHERE created_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $createdBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($createdBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $createdBy)) {
                $createdBy = str_replace('*', '%', $createdBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the date_modified column
     *
     * Example usage:
     * <code>
     * $query->filterByDateModified('2011-03-14'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified('now'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified(array('max' => 'yesterday')); // WHERE date_modified > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateModified The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByDateModified($dateModified = null, $comparison = null)
    {
        if (is_array($dateModified)) {
            $useMinMax = false;
            if (isset($dateModified['min'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_DATE_MODIFIED, $dateModified['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateModified['max'])) {
                $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_DATE_MODIFIED, $dateModified['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_DATE_MODIFIED, $dateModified, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy('fooValue');   // WHERE modified_by = 'fooValue'
     * $query->filterByModifiedBy('%fooValue%'); // WHERE modified_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $modifiedBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($modifiedBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $modifiedBy)) {
                $modifiedBy = str_replace('*', '%', $modifiedBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related \RevenueHead object
     *
     * @param \RevenueHead|ObjectCollection $revenueHead The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByRevenueHead($revenueHead, $comparison = null)
    {
        if ($revenueHead instanceof \RevenueHead) {
            return $this
                ->addUsingAlias(InhouseRevenueCollectionTableMap::COL_REVENUE_HEAD_ID, $revenueHead->getRevenueHeadId(), $comparison);
        } elseif ($revenueHead instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(InhouseRevenueCollectionTableMap::COL_REVENUE_HEAD_ID, $revenueHead->toKeyValue('PrimaryKey', 'RevenueHeadId'), $comparison);
        } else {
            throw new PropelException('filterByRevenueHead() only accepts arguments of type \RevenueHead or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueHead relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function joinRevenueHead($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueHead');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueHead');
        }

        return $this;
    }

    /**
     * Use the RevenueHead relation RevenueHead object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueHeadQuery A secondary query class using the current class as primary query
     */
    public function useRevenueHeadQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueHead($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueHead', '\RevenueHeadQuery');
    }

    /**
     * Filter the query by a related \RevenueCollectionEntity object
     *
     * @param \RevenueCollectionEntity|ObjectCollection $revenueCollectionEntity The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function filterByRevenueCollectionEntity($revenueCollectionEntity, $comparison = null)
    {
        if ($revenueCollectionEntity instanceof \RevenueCollectionEntity) {
            return $this
                ->addUsingAlias(InhouseRevenueCollectionTableMap::COL_MDA_CODE, $revenueCollectionEntity->getMdaCode(), $comparison);
        } elseif ($revenueCollectionEntity instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(InhouseRevenueCollectionTableMap::COL_MDA_CODE, $revenueCollectionEntity->toKeyValue('PrimaryKey', 'MdaCode'), $comparison);
        } else {
            throw new PropelException('filterByRevenueCollectionEntity() only accepts arguments of type \RevenueCollectionEntity or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueCollectionEntity relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function joinRevenueCollectionEntity($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueCollectionEntity');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueCollectionEntity');
        }

        return $this;
    }

    /**
     * Use the RevenueCollectionEntity relation RevenueCollectionEntity object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueCollectionEntityQuery A secondary query class using the current class as primary query
     */
    public function useRevenueCollectionEntityQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueCollectionEntity($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueCollectionEntity', '\RevenueCollectionEntityQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   ChildInhouseRevenueCollection $inhouseRevenueCollection Object to remove from the list of results
     *
     * @return $this|ChildInhouseRevenueCollectionQuery The current query, for fluid interface
     */
    public function prune($inhouseRevenueCollection = null)
    {
        if ($inhouseRevenueCollection) {
            $this->addUsingAlias(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID, $inhouseRevenueCollection->getInhouseRevenueCollectionId(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

    /**
     * Deletes all rows from the inhouse_revenue_collection table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(InhouseRevenueCollectionTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            InhouseRevenueCollectionTableMap::clearInstancePool();
            InhouseRevenueCollectionTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(InhouseRevenueCollectionTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(InhouseRevenueCollectionTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            
            InhouseRevenueCollectionTableMap::removeInstanceFromPool($criteria);
        
            $affectedRows += ModelCriteria::delete($con);
            InhouseRevenueCollectionTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // InhouseRevenueCollectionQuery
