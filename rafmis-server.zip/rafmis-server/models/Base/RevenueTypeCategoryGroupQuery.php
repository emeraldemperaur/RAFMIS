<?php

namespace Base;

use \RevenueTypeCategoryGroup as ChildRevenueTypeCategoryGroup;
use \RevenueTypeCategoryGroupQuery as ChildRevenueTypeCategoryGroupQuery;
use \Exception;
use \PDO;
use Map\RevenueTypeCategoryGroupTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'revenue_type_category_group' table.
 *
 * 
 *
 * @method     ChildRevenueTypeCategoryGroupQuery orderByRevenueTypeId($order = Criteria::ASC) Order by the revenue_type_id column
 * @method     ChildRevenueTypeCategoryGroupQuery orderByRevenueTypeCategoryId($order = Criteria::ASC) Order by the revenue_type_category_id column
 * @method     ChildRevenueTypeCategoryGroupQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method     ChildRevenueTypeCategoryGroupQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method     ChildRevenueTypeCategoryGroupQuery orderByDateModified($order = Criteria::ASC) Order by the date_modified column
 * @method     ChildRevenueTypeCategoryGroupQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method     ChildRevenueTypeCategoryGroupQuery groupByRevenueTypeId() Group by the revenue_type_id column
 * @method     ChildRevenueTypeCategoryGroupQuery groupByRevenueTypeCategoryId() Group by the revenue_type_category_id column
 * @method     ChildRevenueTypeCategoryGroupQuery groupByDateCreated() Group by the date_created column
 * @method     ChildRevenueTypeCategoryGroupQuery groupByCreatedBy() Group by the created_by column
 * @method     ChildRevenueTypeCategoryGroupQuery groupByDateModified() Group by the date_modified column
 * @method     ChildRevenueTypeCategoryGroupQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method     ChildRevenueTypeCategoryGroupQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildRevenueTypeCategoryGroupQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildRevenueTypeCategoryGroupQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildRevenueTypeCategoryGroupQuery leftJoinRevenueType($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueType relation
 * @method     ChildRevenueTypeCategoryGroupQuery rightJoinRevenueType($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueType relation
 * @method     ChildRevenueTypeCategoryGroupQuery innerJoinRevenueType($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueType relation
 *
 * @method     ChildRevenueTypeCategoryGroupQuery leftJoinRevenueTypeCategory($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueTypeCategory relation
 * @method     ChildRevenueTypeCategoryGroupQuery rightJoinRevenueTypeCategory($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueTypeCategory relation
 * @method     ChildRevenueTypeCategoryGroupQuery innerJoinRevenueTypeCategory($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueTypeCategory relation
 *
 * @method     \RevenueTypeQuery|\RevenueTypeCategoryQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildRevenueTypeCategoryGroup findOne(ConnectionInterface $con = null) Return the first ChildRevenueTypeCategoryGroup matching the query
 * @method     ChildRevenueTypeCategoryGroup findOneOrCreate(ConnectionInterface $con = null) Return the first ChildRevenueTypeCategoryGroup matching the query, or a new ChildRevenueTypeCategoryGroup object populated from the query conditions when no match is found
 *
 * @method     ChildRevenueTypeCategoryGroup findOneByRevenueTypeId(string $revenue_type_id) Return the first ChildRevenueTypeCategoryGroup filtered by the revenue_type_id column
 * @method     ChildRevenueTypeCategoryGroup findOneByRevenueTypeCategoryId(string $revenue_type_category_id) Return the first ChildRevenueTypeCategoryGroup filtered by the revenue_type_category_id column
 * @method     ChildRevenueTypeCategoryGroup findOneByDateCreated(string $date_created) Return the first ChildRevenueTypeCategoryGroup filtered by the date_created column
 * @method     ChildRevenueTypeCategoryGroup findOneByCreatedBy(string $created_by) Return the first ChildRevenueTypeCategoryGroup filtered by the created_by column
 * @method     ChildRevenueTypeCategoryGroup findOneByDateModified(string $date_modified) Return the first ChildRevenueTypeCategoryGroup filtered by the date_modified column
 * @method     ChildRevenueTypeCategoryGroup findOneByModifiedBy(string $modified_by) Return the first ChildRevenueTypeCategoryGroup filtered by the modified_by column *

 * @method     ChildRevenueTypeCategoryGroup requirePk($key, ConnectionInterface $con = null) Return the ChildRevenueTypeCategoryGroup by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueTypeCategoryGroup requireOne(ConnectionInterface $con = null) Return the first ChildRevenueTypeCategoryGroup matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildRevenueTypeCategoryGroup requireOneByRevenueTypeId(string $revenue_type_id) Return the first ChildRevenueTypeCategoryGroup filtered by the revenue_type_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueTypeCategoryGroup requireOneByRevenueTypeCategoryId(string $revenue_type_category_id) Return the first ChildRevenueTypeCategoryGroup filtered by the revenue_type_category_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueTypeCategoryGroup requireOneByDateCreated(string $date_created) Return the first ChildRevenueTypeCategoryGroup filtered by the date_created column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueTypeCategoryGroup requireOneByCreatedBy(string $created_by) Return the first ChildRevenueTypeCategoryGroup filtered by the created_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueTypeCategoryGroup requireOneByDateModified(string $date_modified) Return the first ChildRevenueTypeCategoryGroup filtered by the date_modified column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueTypeCategoryGroup requireOneByModifiedBy(string $modified_by) Return the first ChildRevenueTypeCategoryGroup filtered by the modified_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildRevenueTypeCategoryGroup[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildRevenueTypeCategoryGroup objects based on current ModelCriteria
 * @method     ChildRevenueTypeCategoryGroup[]|ObjectCollection findByRevenueTypeId(string $revenue_type_id) Return ChildRevenueTypeCategoryGroup objects filtered by the revenue_type_id column
 * @method     ChildRevenueTypeCategoryGroup[]|ObjectCollection findByRevenueTypeCategoryId(string $revenue_type_category_id) Return ChildRevenueTypeCategoryGroup objects filtered by the revenue_type_category_id column
 * @method     ChildRevenueTypeCategoryGroup[]|ObjectCollection findByDateCreated(string $date_created) Return ChildRevenueTypeCategoryGroup objects filtered by the date_created column
 * @method     ChildRevenueTypeCategoryGroup[]|ObjectCollection findByCreatedBy(string $created_by) Return ChildRevenueTypeCategoryGroup objects filtered by the created_by column
 * @method     ChildRevenueTypeCategoryGroup[]|ObjectCollection findByDateModified(string $date_modified) Return ChildRevenueTypeCategoryGroup objects filtered by the date_modified column
 * @method     ChildRevenueTypeCategoryGroup[]|ObjectCollection findByModifiedBy(string $modified_by) Return ChildRevenueTypeCategoryGroup objects filtered by the modified_by column
 * @method     ChildRevenueTypeCategoryGroup[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class RevenueTypeCategoryGroupQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Base\RevenueTypeCategoryGroupQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'rafmis', $modelName = '\\RevenueTypeCategoryGroup', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildRevenueTypeCategoryGroupQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildRevenueTypeCategoryGroupQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildRevenueTypeCategoryGroupQuery) {
            return $criteria;
        }
        $query = new ChildRevenueTypeCategoryGroupQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj = $c->findPk(array(12, 34), $con);
     * </code>
     *
     * @param array[$revenue_type_id, $revenue_type_category_id] $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildRevenueTypeCategoryGroup|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = RevenueTypeCategoryGroupTableMap::getInstanceFromPool(serialize(array((string) $key[0], (string) $key[1]))))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(RevenueTypeCategoryGroupTableMap::DATABASE_NAME);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenueTypeCategoryGroup A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT revenue_type_id, revenue_type_category_id, date_created, created_by, date_modified, modified_by FROM revenue_type_category_group WHERE revenue_type_id = :p0 AND revenue_type_category_id = :p1';
        try {
            $stmt = $con->prepare($sql);            
            $stmt->bindValue(':p0', $key[0], PDO::PARAM_STR);            
            $stmt->bindValue(':p1', $key[1], PDO::PARAM_STR);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildRevenueTypeCategoryGroup $obj */
            $obj = new ChildRevenueTypeCategoryGroup();
            $obj->hydrate($row);
            RevenueTypeCategoryGroupTableMap::addInstanceToPool($obj, serialize(array((string) $key[0], (string) $key[1])));
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildRevenueTypeCategoryGroup|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(array(12, 56), array(832, 123), array(123, 456)), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildRevenueTypeCategoryGroupQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {
        $this->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_REVENUE_TYPE_ID, $key[0], Criteria::EQUAL);
        $this->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_REVENUE_TYPE_CATEGORY_ID, $key[1], Criteria::EQUAL);

        return $this;
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildRevenueTypeCategoryGroupQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {
        if (empty($keys)) {
            return $this->add(null, '1<>1', Criteria::CUSTOM);
        }
        foreach ($keys as $key) {
            $cton0 = $this->getNewCriterion(RevenueTypeCategoryGroupTableMap::COL_REVENUE_TYPE_ID, $key[0], Criteria::EQUAL);
            $cton1 = $this->getNewCriterion(RevenueTypeCategoryGroupTableMap::COL_REVENUE_TYPE_CATEGORY_ID, $key[1], Criteria::EQUAL);
            $cton0->addAnd($cton1);
            $this->addOr($cton0);
        }

        return $this;
    }

    /**
     * Filter the query on the revenue_type_id column
     *
     * Example usage:
     * <code>
     * $query->filterByRevenueTypeId('fooValue');   // WHERE revenue_type_id = 'fooValue'
     * $query->filterByRevenueTypeId('%fooValue%'); // WHERE revenue_type_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $revenueTypeId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueTypeCategoryGroupQuery The current query, for fluid interface
     */
    public function filterByRevenueTypeId($revenueTypeId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($revenueTypeId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $revenueTypeId)) {
                $revenueTypeId = str_replace('*', '%', $revenueTypeId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_REVENUE_TYPE_ID, $revenueTypeId, $comparison);
    }

    /**
     * Filter the query on the revenue_type_category_id column
     *
     * Example usage:
     * <code>
     * $query->filterByRevenueTypeCategoryId('fooValue');   // WHERE revenue_type_category_id = 'fooValue'
     * $query->filterByRevenueTypeCategoryId('%fooValue%'); // WHERE revenue_type_category_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $revenueTypeCategoryId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueTypeCategoryGroupQuery The current query, for fluid interface
     */
    public function filterByRevenueTypeCategoryId($revenueTypeCategoryId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($revenueTypeCategoryId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $revenueTypeCategoryId)) {
                $revenueTypeCategoryId = str_replace('*', '%', $revenueTypeCategoryId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_REVENUE_TYPE_CATEGORY_ID, $revenueTypeCategoryId, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueTypeCategoryGroupQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy('fooValue');   // WHERE created_by = 'fooValue'
     * $query->filterByCreatedBy('%fooValue%'); // WHERE created_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $createdBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueTypeCategoryGroupQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($createdBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $createdBy)) {
                $createdBy = str_replace('*', '%', $createdBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the date_modified column
     *
     * Example usage:
     * <code>
     * $query->filterByDateModified('2011-03-14'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified('now'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified(array('max' => 'yesterday')); // WHERE date_modified > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateModified The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueTypeCategoryGroupQuery The current query, for fluid interface
     */
    public function filterByDateModified($dateModified = null, $comparison = null)
    {
        if (is_array($dateModified)) {
            $useMinMax = false;
            if (isset($dateModified['min'])) {
                $this->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_DATE_MODIFIED, $dateModified['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateModified['max'])) {
                $this->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_DATE_MODIFIED, $dateModified['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_DATE_MODIFIED, $dateModified, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy('fooValue');   // WHERE modified_by = 'fooValue'
     * $query->filterByModifiedBy('%fooValue%'); // WHERE modified_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $modifiedBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueTypeCategoryGroupQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($modifiedBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $modifiedBy)) {
                $modifiedBy = str_replace('*', '%', $modifiedBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related \RevenueType object
     *
     * @param \RevenueType|ObjectCollection $revenueType The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenueTypeCategoryGroupQuery The current query, for fluid interface
     */
    public function filterByRevenueType($revenueType, $comparison = null)
    {
        if ($revenueType instanceof \RevenueType) {
            return $this
                ->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_REVENUE_TYPE_ID, $revenueType->getRevenueTypeId(), $comparison);
        } elseif ($revenueType instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_REVENUE_TYPE_ID, $revenueType->toKeyValue('PrimaryKey', 'RevenueTypeId'), $comparison);
        } else {
            throw new PropelException('filterByRevenueType() only accepts arguments of type \RevenueType or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueType relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueTypeCategoryGroupQuery The current query, for fluid interface
     */
    public function joinRevenueType($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueType');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueType');
        }

        return $this;
    }

    /**
     * Use the RevenueType relation RevenueType object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueTypeQuery A secondary query class using the current class as primary query
     */
    public function useRevenueTypeQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueType($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueType', '\RevenueTypeQuery');
    }

    /**
     * Filter the query by a related \RevenueTypeCategory object
     *
     * @param \RevenueTypeCategory|ObjectCollection $revenueTypeCategory The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenueTypeCategoryGroupQuery The current query, for fluid interface
     */
    public function filterByRevenueTypeCategory($revenueTypeCategory, $comparison = null)
    {
        if ($revenueTypeCategory instanceof \RevenueTypeCategory) {
            return $this
                ->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_REVENUE_TYPE_CATEGORY_ID, $revenueTypeCategory->getRevenueTypeCategoryId(), $comparison);
        } elseif ($revenueTypeCategory instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(RevenueTypeCategoryGroupTableMap::COL_REVENUE_TYPE_CATEGORY_ID, $revenueTypeCategory->toKeyValue('PrimaryKey', 'RevenueTypeCategoryId'), $comparison);
        } else {
            throw new PropelException('filterByRevenueTypeCategory() only accepts arguments of type \RevenueTypeCategory or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueTypeCategory relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueTypeCategoryGroupQuery The current query, for fluid interface
     */
    public function joinRevenueTypeCategory($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueTypeCategory');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueTypeCategory');
        }

        return $this;
    }

    /**
     * Use the RevenueTypeCategory relation RevenueTypeCategory object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueTypeCategoryQuery A secondary query class using the current class as primary query
     */
    public function useRevenueTypeCategoryQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueTypeCategory($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueTypeCategory', '\RevenueTypeCategoryQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   ChildRevenueTypeCategoryGroup $revenueTypeCategoryGroup Object to remove from the list of results
     *
     * @return $this|ChildRevenueTypeCategoryGroupQuery The current query, for fluid interface
     */
    public function prune($revenueTypeCategoryGroup = null)
    {
        if ($revenueTypeCategoryGroup) {
            $this->addCond('pruneCond0', $this->getAliasedColName(RevenueTypeCategoryGroupTableMap::COL_REVENUE_TYPE_ID), $revenueTypeCategoryGroup->getRevenueTypeId(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond1', $this->getAliasedColName(RevenueTypeCategoryGroupTableMap::COL_REVENUE_TYPE_CATEGORY_ID), $revenueTypeCategoryGroup->getRevenueTypeCategoryId(), Criteria::NOT_EQUAL);
            $this->combine(array('pruneCond0', 'pruneCond1'), Criteria::LOGICAL_OR);
        }

        return $this;
    }

    /**
     * Deletes all rows from the revenue_type_category_group table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RevenueTypeCategoryGroupTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            RevenueTypeCategoryGroupTableMap::clearInstancePool();
            RevenueTypeCategoryGroupTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RevenueTypeCategoryGroupTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(RevenueTypeCategoryGroupTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            
            RevenueTypeCategoryGroupTableMap::removeInstanceFromPool($criteria);
        
            $affectedRows += ModelCriteria::delete($con);
            RevenueTypeCategoryGroupTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // RevenueTypeCategoryGroupQuery
