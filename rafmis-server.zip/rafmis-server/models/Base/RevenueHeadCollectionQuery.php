<?php

namespace Base;

use \RevenueHeadCollection as ChildRevenueHeadCollection;
use \RevenueHeadCollectionQuery as ChildRevenueHeadCollectionQuery;
use \Exception;
use \PDO;
use Map\RevenueHeadCollectionTableMap;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\ModelCriteria;
use Propel\Runtime\ActiveQuery\ModelJoin;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\Exception\PropelException;

/**
 * Base class that represents a query for the 'revenue_head_collection' table.
 *
 * 
 *
 * @method     ChildRevenueHeadCollectionQuery orderByRevenueHeadId($order = Criteria::ASC) Order by the revenue_head_id column
 * @method     ChildRevenueHeadCollectionQuery orderByMdaCode($order = Criteria::ASC) Order by the mda_code column
 * @method     ChildRevenueHeadCollectionQuery orderByAmount($order = Criteria::ASC) Order by the amount column
 * @method     ChildRevenueHeadCollectionQuery orderByPaymentPeriodMonth($order = Criteria::ASC) Order by the payment_period_month column
 * @method     ChildRevenueHeadCollectionQuery orderByPaymentPeriodYear($order = Criteria::ASC) Order by the payment_period_year column
 * @method     ChildRevenueHeadCollectionQuery orderByDateCreated($order = Criteria::ASC) Order by the date_created column
 * @method     ChildRevenueHeadCollectionQuery orderByCreatedBy($order = Criteria::ASC) Order by the created_by column
 * @method     ChildRevenueHeadCollectionQuery orderByDateModified($order = Criteria::ASC) Order by the date_modified column
 * @method     ChildRevenueHeadCollectionQuery orderByModifiedBy($order = Criteria::ASC) Order by the modified_by column
 *
 * @method     ChildRevenueHeadCollectionQuery groupByRevenueHeadId() Group by the revenue_head_id column
 * @method     ChildRevenueHeadCollectionQuery groupByMdaCode() Group by the mda_code column
 * @method     ChildRevenueHeadCollectionQuery groupByAmount() Group by the amount column
 * @method     ChildRevenueHeadCollectionQuery groupByPaymentPeriodMonth() Group by the payment_period_month column
 * @method     ChildRevenueHeadCollectionQuery groupByPaymentPeriodYear() Group by the payment_period_year column
 * @method     ChildRevenueHeadCollectionQuery groupByDateCreated() Group by the date_created column
 * @method     ChildRevenueHeadCollectionQuery groupByCreatedBy() Group by the created_by column
 * @method     ChildRevenueHeadCollectionQuery groupByDateModified() Group by the date_modified column
 * @method     ChildRevenueHeadCollectionQuery groupByModifiedBy() Group by the modified_by column
 *
 * @method     ChildRevenueHeadCollectionQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method     ChildRevenueHeadCollectionQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method     ChildRevenueHeadCollectionQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method     ChildRevenueHeadCollectionQuery leftJoinRevenueHead($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueHead relation
 * @method     ChildRevenueHeadCollectionQuery rightJoinRevenueHead($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueHead relation
 * @method     ChildRevenueHeadCollectionQuery innerJoinRevenueHead($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueHead relation
 *
 * @method     ChildRevenueHeadCollectionQuery leftJoinRevenueCollectionEntity($relationAlias = null) Adds a LEFT JOIN clause to the query using the RevenueCollectionEntity relation
 * @method     ChildRevenueHeadCollectionQuery rightJoinRevenueCollectionEntity($relationAlias = null) Adds a RIGHT JOIN clause to the query using the RevenueCollectionEntity relation
 * @method     ChildRevenueHeadCollectionQuery innerJoinRevenueCollectionEntity($relationAlias = null) Adds a INNER JOIN clause to the query using the RevenueCollectionEntity relation
 *
 * @method     \RevenueHeadQuery|\RevenueCollectionEntityQuery endUse() Finalizes a secondary criteria and merges it with its primary Criteria
 *
 * @method     ChildRevenueHeadCollection findOne(ConnectionInterface $con = null) Return the first ChildRevenueHeadCollection matching the query
 * @method     ChildRevenueHeadCollection findOneOrCreate(ConnectionInterface $con = null) Return the first ChildRevenueHeadCollection matching the query, or a new ChildRevenueHeadCollection object populated from the query conditions when no match is found
 *
 * @method     ChildRevenueHeadCollection findOneByRevenueHeadId(string $revenue_head_id) Return the first ChildRevenueHeadCollection filtered by the revenue_head_id column
 * @method     ChildRevenueHeadCollection findOneByMdaCode(string $mda_code) Return the first ChildRevenueHeadCollection filtered by the mda_code column
 * @method     ChildRevenueHeadCollection findOneByAmount(double $amount) Return the first ChildRevenueHeadCollection filtered by the amount column
 * @method     ChildRevenueHeadCollection findOneByPaymentPeriodMonth(int $payment_period_month) Return the first ChildRevenueHeadCollection filtered by the payment_period_month column
 * @method     ChildRevenueHeadCollection findOneByPaymentPeriodYear(int $payment_period_year) Return the first ChildRevenueHeadCollection filtered by the payment_period_year column
 * @method     ChildRevenueHeadCollection findOneByDateCreated(string $date_created) Return the first ChildRevenueHeadCollection filtered by the date_created column
 * @method     ChildRevenueHeadCollection findOneByCreatedBy(string $created_by) Return the first ChildRevenueHeadCollection filtered by the created_by column
 * @method     ChildRevenueHeadCollection findOneByDateModified(string $date_modified) Return the first ChildRevenueHeadCollection filtered by the date_modified column
 * @method     ChildRevenueHeadCollection findOneByModifiedBy(string $modified_by) Return the first ChildRevenueHeadCollection filtered by the modified_by column *

 * @method     ChildRevenueHeadCollection requirePk($key, ConnectionInterface $con = null) Return the ChildRevenueHeadCollection by primary key and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHeadCollection requireOne(ConnectionInterface $con = null) Return the first ChildRevenueHeadCollection matching the query and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildRevenueHeadCollection requireOneByRevenueHeadId(string $revenue_head_id) Return the first ChildRevenueHeadCollection filtered by the revenue_head_id column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHeadCollection requireOneByMdaCode(string $mda_code) Return the first ChildRevenueHeadCollection filtered by the mda_code column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHeadCollection requireOneByAmount(double $amount) Return the first ChildRevenueHeadCollection filtered by the amount column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHeadCollection requireOneByPaymentPeriodMonth(int $payment_period_month) Return the first ChildRevenueHeadCollection filtered by the payment_period_month column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHeadCollection requireOneByPaymentPeriodYear(int $payment_period_year) Return the first ChildRevenueHeadCollection filtered by the payment_period_year column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHeadCollection requireOneByDateCreated(string $date_created) Return the first ChildRevenueHeadCollection filtered by the date_created column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHeadCollection requireOneByCreatedBy(string $created_by) Return the first ChildRevenueHeadCollection filtered by the created_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHeadCollection requireOneByDateModified(string $date_modified) Return the first ChildRevenueHeadCollection filtered by the date_modified column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 * @method     ChildRevenueHeadCollection requireOneByModifiedBy(string $modified_by) Return the first ChildRevenueHeadCollection filtered by the modified_by column and throws \Propel\Runtime\Exception\EntityNotFoundException when not found
 *
 * @method     ChildRevenueHeadCollection[]|ObjectCollection find(ConnectionInterface $con = null) Return ChildRevenueHeadCollection objects based on current ModelCriteria
 * @method     ChildRevenueHeadCollection[]|ObjectCollection findByRevenueHeadId(string $revenue_head_id) Return ChildRevenueHeadCollection objects filtered by the revenue_head_id column
 * @method     ChildRevenueHeadCollection[]|ObjectCollection findByMdaCode(string $mda_code) Return ChildRevenueHeadCollection objects filtered by the mda_code column
 * @method     ChildRevenueHeadCollection[]|ObjectCollection findByAmount(double $amount) Return ChildRevenueHeadCollection objects filtered by the amount column
 * @method     ChildRevenueHeadCollection[]|ObjectCollection findByPaymentPeriodMonth(int $payment_period_month) Return ChildRevenueHeadCollection objects filtered by the payment_period_month column
 * @method     ChildRevenueHeadCollection[]|ObjectCollection findByPaymentPeriodYear(int $payment_period_year) Return ChildRevenueHeadCollection objects filtered by the payment_period_year column
 * @method     ChildRevenueHeadCollection[]|ObjectCollection findByDateCreated(string $date_created) Return ChildRevenueHeadCollection objects filtered by the date_created column
 * @method     ChildRevenueHeadCollection[]|ObjectCollection findByCreatedBy(string $created_by) Return ChildRevenueHeadCollection objects filtered by the created_by column
 * @method     ChildRevenueHeadCollection[]|ObjectCollection findByDateModified(string $date_modified) Return ChildRevenueHeadCollection objects filtered by the date_modified column
 * @method     ChildRevenueHeadCollection[]|ObjectCollection findByModifiedBy(string $modified_by) Return ChildRevenueHeadCollection objects filtered by the modified_by column
 * @method     ChildRevenueHeadCollection[]|\Propel\Runtime\Util\PropelModelPager paginate($page = 1, $maxPerPage = 10, ConnectionInterface $con = null) Issue a SELECT query based on the current ModelCriteria and uses a page and a maximum number of results per page to compute an offset and a limit
 *
 */
abstract class RevenueHeadCollectionQuery extends ModelCriteria
{
    protected $entityNotFoundExceptionClass = '\\Propel\\Runtime\\Exception\\EntityNotFoundException';

    /**
     * Initializes internal state of \Base\RevenueHeadCollectionQuery object.
     *
     * @param     string $dbName The database name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'rafmis', $modelName = '\\RevenueHeadCollection', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new ChildRevenueHeadCollectionQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param     Criteria $criteria Optional Criteria to build the query from
     *
     * @return ChildRevenueHeadCollectionQuery
     */
    public static function create($modelAlias = null, Criteria $criteria = null)
    {
        if ($criteria instanceof ChildRevenueHeadCollectionQuery) {
            return $criteria;
        }
        $query = new ChildRevenueHeadCollectionQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj = $c->findPk(array(12, 34, 56, 78), $con);
     * </code>
     *
     * @param array[$revenue_head_id, $mda_code, $payment_period_month, $payment_period_year] $key Primary key to use for the query
     * @param ConnectionInterface $con an optional connection object
     *
     * @return ChildRevenueHeadCollection|array|mixed the result, formatted by the current formatter
     */
    public function findPk($key, ConnectionInterface $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = RevenueHeadCollectionTableMap::getInstanceFromPool(serialize(array((string) $key[0], (string) $key[1], (string) $key[2], (string) $key[3]))))) && !$this->formatter) {
            // the object is already in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getServiceContainer()->getReadConnection(RevenueHeadCollectionTableMap::DATABASE_NAME);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenueHeadCollection A model object, or null if the key is not found
     */
    protected function findPkSimple($key, ConnectionInterface $con)
    {
        $sql = 'SELECT revenue_head_id, mda_code, amount, payment_period_month, payment_period_year, date_created, created_by, date_modified, modified_by FROM revenue_head_collection WHERE revenue_head_id = :p0 AND mda_code = :p1 AND payment_period_month = :p2 AND payment_period_year = :p3';
        try {
            $stmt = $con->prepare($sql);            
            $stmt->bindValue(':p0', $key[0], PDO::PARAM_STR);            
            $stmt->bindValue(':p1', $key[1], PDO::PARAM_STR);            
            $stmt->bindValue(':p2', $key[2], PDO::PARAM_INT);            
            $stmt->bindValue(':p3', $key[3], PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), 0, $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(\PDO::FETCH_NUM)) {
            /** @var ChildRevenueHeadCollection $obj */
            $obj = new ChildRevenueHeadCollection();
            $obj->hydrate($row);
            RevenueHeadCollectionTableMap::addInstanceToPool($obj, serialize(array((string) $key[0], (string) $key[1], (string) $key[2], (string) $key[3])));
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     ConnectionInterface $con A connection object
     *
     * @return ChildRevenueHeadCollection|array|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, ConnectionInterface $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($dataFetcher);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(array(12, 56), array(832, 123), array(123, 456)), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     ConnectionInterface $con an optional connection object
     *
     * @return ObjectCollection|array|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getReadConnection($this->getDbName());
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $dataFetcher = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($dataFetcher);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {
        $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_REVENUE_HEAD_ID, $key[0], Criteria::EQUAL);
        $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_MDA_CODE, $key[1], Criteria::EQUAL);
        $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_PAYMENT_PERIOD_MONTH, $key[2], Criteria::EQUAL);
        $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_PAYMENT_PERIOD_YEAR, $key[3], Criteria::EQUAL);

        return $this;
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {
        if (empty($keys)) {
            return $this->add(null, '1<>1', Criteria::CUSTOM);
        }
        foreach ($keys as $key) {
            $cton0 = $this->getNewCriterion(RevenueHeadCollectionTableMap::COL_REVENUE_HEAD_ID, $key[0], Criteria::EQUAL);
            $cton1 = $this->getNewCriterion(RevenueHeadCollectionTableMap::COL_MDA_CODE, $key[1], Criteria::EQUAL);
            $cton0->addAnd($cton1);
            $cton2 = $this->getNewCriterion(RevenueHeadCollectionTableMap::COL_PAYMENT_PERIOD_MONTH, $key[2], Criteria::EQUAL);
            $cton0->addAnd($cton2);
            $cton3 = $this->getNewCriterion(RevenueHeadCollectionTableMap::COL_PAYMENT_PERIOD_YEAR, $key[3], Criteria::EQUAL);
            $cton0->addAnd($cton3);
            $this->addOr($cton0);
        }

        return $this;
    }

    /**
     * Filter the query on the revenue_head_id column
     *
     * Example usage:
     * <code>
     * $query->filterByRevenueHeadId('fooValue');   // WHERE revenue_head_id = 'fooValue'
     * $query->filterByRevenueHeadId('%fooValue%'); // WHERE revenue_head_id LIKE '%fooValue%'
     * </code>
     *
     * @param     string $revenueHeadId The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function filterByRevenueHeadId($revenueHeadId = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($revenueHeadId)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $revenueHeadId)) {
                $revenueHeadId = str_replace('*', '%', $revenueHeadId);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_REVENUE_HEAD_ID, $revenueHeadId, $comparison);
    }

    /**
     * Filter the query on the mda_code column
     *
     * Example usage:
     * <code>
     * $query->filterByMdaCode('fooValue');   // WHERE mda_code = 'fooValue'
     * $query->filterByMdaCode('%fooValue%'); // WHERE mda_code LIKE '%fooValue%'
     * </code>
     *
     * @param     string $mdaCode The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function filterByMdaCode($mdaCode = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($mdaCode)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $mdaCode)) {
                $mdaCode = str_replace('*', '%', $mdaCode);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_MDA_CODE, $mdaCode, $comparison);
    }

    /**
     * Filter the query on the amount column
     *
     * Example usage:
     * <code>
     * $query->filterByAmount(1234); // WHERE amount = 1234
     * $query->filterByAmount(array(12, 34)); // WHERE amount IN (12, 34)
     * $query->filterByAmount(array('min' => 12)); // WHERE amount > 12
     * </code>
     *
     * @param     mixed $amount The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function filterByAmount($amount = null, $comparison = null)
    {
        if (is_array($amount)) {
            $useMinMax = false;
            if (isset($amount['min'])) {
                $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_AMOUNT, $amount['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($amount['max'])) {
                $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_AMOUNT, $amount['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_AMOUNT, $amount, $comparison);
    }

    /**
     * Filter the query on the payment_period_month column
     *
     * Example usage:
     * <code>
     * $query->filterByPaymentPeriodMonth(1234); // WHERE payment_period_month = 1234
     * $query->filterByPaymentPeriodMonth(array(12, 34)); // WHERE payment_period_month IN (12, 34)
     * $query->filterByPaymentPeriodMonth(array('min' => 12)); // WHERE payment_period_month > 12
     * </code>
     *
     * @param     mixed $paymentPeriodMonth The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function filterByPaymentPeriodMonth($paymentPeriodMonth = null, $comparison = null)
    {
        if (is_array($paymentPeriodMonth)) {
            $useMinMax = false;
            if (isset($paymentPeriodMonth['min'])) {
                $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_PAYMENT_PERIOD_MONTH, $paymentPeriodMonth['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($paymentPeriodMonth['max'])) {
                $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_PAYMENT_PERIOD_MONTH, $paymentPeriodMonth['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_PAYMENT_PERIOD_MONTH, $paymentPeriodMonth, $comparison);
    }

    /**
     * Filter the query on the payment_period_year column
     *
     * Example usage:
     * <code>
     * $query->filterByPaymentPeriodYear(1234); // WHERE payment_period_year = 1234
     * $query->filterByPaymentPeriodYear(array(12, 34)); // WHERE payment_period_year IN (12, 34)
     * $query->filterByPaymentPeriodYear(array('min' => 12)); // WHERE payment_period_year > 12
     * </code>
     *
     * @param     mixed $paymentPeriodYear The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function filterByPaymentPeriodYear($paymentPeriodYear = null, $comparison = null)
    {
        if (is_array($paymentPeriodYear)) {
            $useMinMax = false;
            if (isset($paymentPeriodYear['min'])) {
                $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_PAYMENT_PERIOD_YEAR, $paymentPeriodYear['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($paymentPeriodYear['max'])) {
                $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_PAYMENT_PERIOD_YEAR, $paymentPeriodYear['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_PAYMENT_PERIOD_YEAR, $paymentPeriodYear, $comparison);
    }

    /**
     * Filter the query on the date_created column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreated('2011-03-14'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated('now'); // WHERE date_created = '2011-03-14'
     * $query->filterByDateCreated(array('max' => 'yesterday')); // WHERE date_created > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreated The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function filterByDateCreated($dateCreated = null, $comparison = null)
    {
        if (is_array($dateCreated)) {
            $useMinMax = false;
            if (isset($dateCreated['min'])) {
                $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_DATE_CREATED, $dateCreated['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreated['max'])) {
                $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_DATE_CREATED, $dateCreated['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_DATE_CREATED, $dateCreated, $comparison);
    }

    /**
     * Filter the query on the created_by column
     *
     * Example usage:
     * <code>
     * $query->filterByCreatedBy('fooValue');   // WHERE created_by = 'fooValue'
     * $query->filterByCreatedBy('%fooValue%'); // WHERE created_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $createdBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function filterByCreatedBy($createdBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($createdBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $createdBy)) {
                $createdBy = str_replace('*', '%', $createdBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_CREATED_BY, $createdBy, $comparison);
    }

    /**
     * Filter the query on the date_modified column
     *
     * Example usage:
     * <code>
     * $query->filterByDateModified('2011-03-14'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified('now'); // WHERE date_modified = '2011-03-14'
     * $query->filterByDateModified(array('max' => 'yesterday')); // WHERE date_modified > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateModified The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function filterByDateModified($dateModified = null, $comparison = null)
    {
        if (is_array($dateModified)) {
            $useMinMax = false;
            if (isset($dateModified['min'])) {
                $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_DATE_MODIFIED, $dateModified['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateModified['max'])) {
                $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_DATE_MODIFIED, $dateModified['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_DATE_MODIFIED, $dateModified, $comparison);
    }

    /**
     * Filter the query on the modified_by column
     *
     * Example usage:
     * <code>
     * $query->filterByModifiedBy('fooValue');   // WHERE modified_by = 'fooValue'
     * $query->filterByModifiedBy('%fooValue%'); // WHERE modified_by LIKE '%fooValue%'
     * </code>
     *
     * @param     string $modifiedBy The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function filterByModifiedBy($modifiedBy = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($modifiedBy)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $modifiedBy)) {
                $modifiedBy = str_replace('*', '%', $modifiedBy);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(RevenueHeadCollectionTableMap::COL_MODIFIED_BY, $modifiedBy, $comparison);
    }

    /**
     * Filter the query by a related \RevenueHead object
     *
     * @param \RevenueHead|ObjectCollection $revenueHead The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function filterByRevenueHead($revenueHead, $comparison = null)
    {
        if ($revenueHead instanceof \RevenueHead) {
            return $this
                ->addUsingAlias(RevenueHeadCollectionTableMap::COL_REVENUE_HEAD_ID, $revenueHead->getRevenueHeadId(), $comparison);
        } elseif ($revenueHead instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(RevenueHeadCollectionTableMap::COL_REVENUE_HEAD_ID, $revenueHead->toKeyValue('PrimaryKey', 'RevenueHeadId'), $comparison);
        } else {
            throw new PropelException('filterByRevenueHead() only accepts arguments of type \RevenueHead or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueHead relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function joinRevenueHead($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueHead');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueHead');
        }

        return $this;
    }

    /**
     * Use the RevenueHead relation RevenueHead object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueHeadQuery A secondary query class using the current class as primary query
     */
    public function useRevenueHeadQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueHead($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueHead', '\RevenueHeadQuery');
    }

    /**
     * Filter the query by a related \RevenueCollectionEntity object
     *
     * @param \RevenueCollectionEntity|ObjectCollection $revenueCollectionEntity The related object(s) to use as filter
     * @param string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @throws \Propel\Runtime\Exception\PropelException
     *
     * @return ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function filterByRevenueCollectionEntity($revenueCollectionEntity, $comparison = null)
    {
        if ($revenueCollectionEntity instanceof \RevenueCollectionEntity) {
            return $this
                ->addUsingAlias(RevenueHeadCollectionTableMap::COL_MDA_CODE, $revenueCollectionEntity->getMdaCode(), $comparison);
        } elseif ($revenueCollectionEntity instanceof ObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(RevenueHeadCollectionTableMap::COL_MDA_CODE, $revenueCollectionEntity->toKeyValue('PrimaryKey', 'MdaCode'), $comparison);
        } else {
            throw new PropelException('filterByRevenueCollectionEntity() only accepts arguments of type \RevenueCollectionEntity or Collection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the RevenueCollectionEntity relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function joinRevenueCollectionEntity($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('RevenueCollectionEntity');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'RevenueCollectionEntity');
        }

        return $this;
    }

    /**
     * Use the RevenueCollectionEntity relation RevenueCollectionEntity object
     *
     * @see useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return \RevenueCollectionEntityQuery A secondary query class using the current class as primary query
     */
    public function useRevenueCollectionEntityQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinRevenueCollectionEntity($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'RevenueCollectionEntity', '\RevenueCollectionEntityQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   ChildRevenueHeadCollection $revenueHeadCollection Object to remove from the list of results
     *
     * @return $this|ChildRevenueHeadCollectionQuery The current query, for fluid interface
     */
    public function prune($revenueHeadCollection = null)
    {
        if ($revenueHeadCollection) {
            $this->addCond('pruneCond0', $this->getAliasedColName(RevenueHeadCollectionTableMap::COL_REVENUE_HEAD_ID), $revenueHeadCollection->getRevenueHeadId(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond1', $this->getAliasedColName(RevenueHeadCollectionTableMap::COL_MDA_CODE), $revenueHeadCollection->getMdaCode(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond2', $this->getAliasedColName(RevenueHeadCollectionTableMap::COL_PAYMENT_PERIOD_MONTH), $revenueHeadCollection->getPaymentPeriodMonth(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond3', $this->getAliasedColName(RevenueHeadCollectionTableMap::COL_PAYMENT_PERIOD_YEAR), $revenueHeadCollection->getPaymentPeriodYear(), Criteria::NOT_EQUAL);
            $this->combine(array('pruneCond0', 'pruneCond1', 'pruneCond2', 'pruneCond3'), Criteria::LOGICAL_OR);
        }

        return $this;
    }

    /**
     * Deletes all rows from the revenue_head_collection table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public function doDeleteAll(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RevenueHeadCollectionTableMap::DATABASE_NAME);
        }

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            $affectedRows += parent::doDeleteAll($con);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            RevenueHeadCollectionTableMap::clearInstancePool();
            RevenueHeadCollectionTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

    /**
     * Performs a DELETE on the database based on the current ModelCriteria
     *
     * @param ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public function delete(ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(RevenueHeadCollectionTableMap::DATABASE_NAME);
        }

        $criteria = $this;

        // Set the correct dbName
        $criteria->setDbName(RevenueHeadCollectionTableMap::DATABASE_NAME);

        // use transaction because $criteria could contain info
        // for more than one table or we could emulating ON DELETE CASCADE, etc.
        return $con->transaction(function () use ($con, $criteria) {
            $affectedRows = 0; // initialize var to track total num of affected rows
            
            RevenueHeadCollectionTableMap::removeInstanceFromPool($criteria);
        
            $affectedRows += ModelCriteria::delete($con);
            RevenueHeadCollectionTableMap::clearRelatedInstancePool();

            return $affectedRows;
        });
    }

} // RevenueHeadCollectionQuery
