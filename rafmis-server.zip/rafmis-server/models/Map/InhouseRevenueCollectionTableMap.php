<?php

namespace Map;

use \InhouseRevenueCollection;
use \InhouseRevenueCollectionQuery;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\InstancePoolTrait;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\DataFetcher\DataFetcherInterface;
use Propel\Runtime\Exception\PropelException;
use Propel\Runtime\Map\RelationMap;
use Propel\Runtime\Map\TableMap;
use Propel\Runtime\Map\TableMapTrait;


/**
 * This class defines the structure of the 'inhouse_revenue_collection' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 */
class InhouseRevenueCollectionTableMap extends TableMap
{
    use InstancePoolTrait;
    use TableMapTrait;

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = '.Map.InhouseRevenueCollectionTableMap';

    /**
     * The default database name for this class
     */
    const DATABASE_NAME = 'rafmis';

    /**
     * The table name for this class
     */
    const TABLE_NAME = 'inhouse_revenue_collection';

    /**
     * The related Propel class for this table
     */
    const OM_CLASS = '\\InhouseRevenueCollection';

    /**
     * A class that can be returned by this tableMap
     */
    const CLASS_DEFAULT = 'InhouseRevenueCollection';

    /**
     * The total number of columns
     */
    const NUM_COLUMNS = 16;

    /**
     * The number of lazy-loaded columns
     */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /**
     * The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS)
     */
    const NUM_HYDRATE_COLUMNS = 16;

    /**
     * the column name for the inhouse_revenue_collection_id field
     */
    const COL_INHOUSE_REVENUE_COLLECTION_ID = 'inhouse_revenue_collection.inhouse_revenue_collection_id';

    /**
     * the column name for the revenue_head_id field
     */
    const COL_REVENUE_HEAD_ID = 'inhouse_revenue_collection.revenue_head_id';

    /**
     * the column name for the mda_code field
     */
    const COL_MDA_CODE = 'inhouse_revenue_collection.mda_code';

    /**
     * the column name for the expected_payment_month field
     */
    const COL_EXPECTED_PAYMENT_MONTH = 'inhouse_revenue_collection.expected_payment_month';

    /**
     * the column name for the expected_payment_year field
     */
    const COL_EXPECTED_PAYMENT_YEAR = 'inhouse_revenue_collection.expected_payment_year';

    /**
     * the column name for the amount field
     */
    const COL_AMOUNT = 'inhouse_revenue_collection.amount';

    /**
     * the column name for the state field
     */
    const COL_STATE = 'inhouse_revenue_collection.state';

    /**
     * the column name for the payer_name field
     */
    const COL_PAYER_NAME = 'inhouse_revenue_collection.payer_name';

    /**
     * the column name for the rc_number field
     */
    const COL_RC_NUMBER = 'inhouse_revenue_collection.rc_number';

    /**
     * the column name for the source_id field
     */
    const COL_SOURCE_ID = 'inhouse_revenue_collection.source_id';

    /**
     * the column name for the tin_number field
     */
    const COL_TIN_NUMBER = 'inhouse_revenue_collection.tin_number';

    /**
     * the column name for the payment_date field
     */
    const COL_PAYMENT_DATE = 'inhouse_revenue_collection.payment_date';

    /**
     * the column name for the date_created field
     */
    const COL_DATE_CREATED = 'inhouse_revenue_collection.date_created';

    /**
     * the column name for the created_by field
     */
    const COL_CREATED_BY = 'inhouse_revenue_collection.created_by';

    /**
     * the column name for the date_modified field
     */
    const COL_DATE_MODIFIED = 'inhouse_revenue_collection.date_modified';

    /**
     * the column name for the modified_by field
     */
    const COL_MODIFIED_BY = 'inhouse_revenue_collection.modified_by';

    /**
     * The default string format for model objects of the related table
     */
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldNames[self::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        self::TYPE_PHPNAME       => array('InhouseRevenueCollectionId', 'RevenueHeadId', 'MdaCode', 'ExpectedPaymentMonth', 'ExpectedPaymentYear', 'Amount', 'State', 'PayerName', 'RcNumber', 'SourceId', 'TinNumber', 'PaymentDate', 'DateCreated', 'CreatedBy', 'DateModified', 'ModifiedBy', ),
        self::TYPE_CAMELNAME     => array('inhouseRevenueCollectionId', 'revenueHeadId', 'mdaCode', 'expectedPaymentMonth', 'expectedPaymentYear', 'amount', 'state', 'payerName', 'rcNumber', 'sourceId', 'tinNumber', 'paymentDate', 'dateCreated', 'createdBy', 'dateModified', 'modifiedBy', ),
        self::TYPE_COLNAME       => array(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID, InhouseRevenueCollectionTableMap::COL_REVENUE_HEAD_ID, InhouseRevenueCollectionTableMap::COL_MDA_CODE, InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_MONTH, InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_YEAR, InhouseRevenueCollectionTableMap::COL_AMOUNT, InhouseRevenueCollectionTableMap::COL_STATE, InhouseRevenueCollectionTableMap::COL_PAYER_NAME, InhouseRevenueCollectionTableMap::COL_RC_NUMBER, InhouseRevenueCollectionTableMap::COL_SOURCE_ID, InhouseRevenueCollectionTableMap::COL_TIN_NUMBER, InhouseRevenueCollectionTableMap::COL_PAYMENT_DATE, InhouseRevenueCollectionTableMap::COL_DATE_CREATED, InhouseRevenueCollectionTableMap::COL_CREATED_BY, InhouseRevenueCollectionTableMap::COL_DATE_MODIFIED, InhouseRevenueCollectionTableMap::COL_MODIFIED_BY, ),
        self::TYPE_FIELDNAME     => array('inhouse_revenue_collection_id', 'revenue_head_id', 'mda_code', 'expected_payment_month', 'expected_payment_year', 'amount', 'state', 'payer_name', 'rc_number', 'source_id', 'tin_number', 'payment_date', 'date_created', 'created_by', 'date_modified', 'modified_by', ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldKeys[self::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        self::TYPE_PHPNAME       => array('InhouseRevenueCollectionId' => 0, 'RevenueHeadId' => 1, 'MdaCode' => 2, 'ExpectedPaymentMonth' => 3, 'ExpectedPaymentYear' => 4, 'Amount' => 5, 'State' => 6, 'PayerName' => 7, 'RcNumber' => 8, 'SourceId' => 9, 'TinNumber' => 10, 'PaymentDate' => 11, 'DateCreated' => 12, 'CreatedBy' => 13, 'DateModified' => 14, 'ModifiedBy' => 15, ),
        self::TYPE_CAMELNAME     => array('inhouseRevenueCollectionId' => 0, 'revenueHeadId' => 1, 'mdaCode' => 2, 'expectedPaymentMonth' => 3, 'expectedPaymentYear' => 4, 'amount' => 5, 'state' => 6, 'payerName' => 7, 'rcNumber' => 8, 'sourceId' => 9, 'tinNumber' => 10, 'paymentDate' => 11, 'dateCreated' => 12, 'createdBy' => 13, 'dateModified' => 14, 'modifiedBy' => 15, ),
        self::TYPE_COLNAME       => array(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID => 0, InhouseRevenueCollectionTableMap::COL_REVENUE_HEAD_ID => 1, InhouseRevenueCollectionTableMap::COL_MDA_CODE => 2, InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_MONTH => 3, InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_YEAR => 4, InhouseRevenueCollectionTableMap::COL_AMOUNT => 5, InhouseRevenueCollectionTableMap::COL_STATE => 6, InhouseRevenueCollectionTableMap::COL_PAYER_NAME => 7, InhouseRevenueCollectionTableMap::COL_RC_NUMBER => 8, InhouseRevenueCollectionTableMap::COL_SOURCE_ID => 9, InhouseRevenueCollectionTableMap::COL_TIN_NUMBER => 10, InhouseRevenueCollectionTableMap::COL_PAYMENT_DATE => 11, InhouseRevenueCollectionTableMap::COL_DATE_CREATED => 12, InhouseRevenueCollectionTableMap::COL_CREATED_BY => 13, InhouseRevenueCollectionTableMap::COL_DATE_MODIFIED => 14, InhouseRevenueCollectionTableMap::COL_MODIFIED_BY => 15, ),
        self::TYPE_FIELDNAME     => array('inhouse_revenue_collection_id' => 0, 'revenue_head_id' => 1, 'mda_code' => 2, 'expected_payment_month' => 3, 'expected_payment_year' => 4, 'amount' => 5, 'state' => 6, 'payer_name' => 7, 'rc_number' => 8, 'source_id' => 9, 'tin_number' => 10, 'payment_date' => 11, 'date_created' => 12, 'created_by' => 13, 'date_modified' => 14, 'modified_by' => 15, ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, )
    );

    /**
     * Initialize the table attributes and columns
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('inhouse_revenue_collection');
        $this->setPhpName('InhouseRevenueCollection');
        $this->setIdentifierQuoting(false);
        $this->setClassName('\\InhouseRevenueCollection');
        $this->setPackage('');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('inhouse_revenue_collection_id', 'InhouseRevenueCollectionId', 'INTEGER', true, null, null);
        $this->addForeignKey('revenue_head_id', 'RevenueHeadId', 'VARCHAR', 'revenue_head', 'revenue_head_id', true, 64, null);
        $this->addForeignKey('mda_code', 'MdaCode', 'VARCHAR', 'revenue_collection_entity', 'mda_code', true, 64, null);
        $this->addColumn('expected_payment_month', 'ExpectedPaymentMonth', 'INTEGER', true, 2, null);
        $this->addColumn('expected_payment_year', 'ExpectedPaymentYear', 'INTEGER', true, 4, null);
        $this->addColumn('amount', 'Amount', 'FLOAT', false, null, null);
        $this->addColumn('state', 'State', 'VARCHAR', false, 45, null);
        $this->addColumn('payer_name', 'PayerName', 'VARCHAR', false, 64, null);
        $this->addColumn('rc_number', 'RcNumber', 'VARCHAR', false, 32, null);
        $this->addColumn('source_id', 'SourceId', 'VARCHAR', false, 128, null);
        $this->addColumn('tin_number', 'TinNumber', 'VARCHAR', false, 32, null);
        $this->addColumn('payment_date', 'PaymentDate', 'DATE', false, null, null);
        $this->addColumn('date_created', 'DateCreated', 'TIMESTAMP', true, null, null);
        $this->addColumn('created_by', 'CreatedBy', 'VARCHAR', true, 64, null);
        $this->addColumn('date_modified', 'DateModified', 'TIMESTAMP', false, null, null);
        $this->addColumn('modified_by', 'ModifiedBy', 'VARCHAR', false, 64, null);
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('RevenueHead', '\\RevenueHead', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':revenue_head_id',
    1 => ':revenue_head_id',
  ),
), null, 'CASCADE', null, false);
        $this->addRelation('RevenueCollectionEntity', '\\RevenueCollectionEntity', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':mda_code',
    1 => ':mda_code',
  ),
), null, 'CASCADE', null, false);
    } // buildRelations()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return string The primary key hash of the row
     */
    public static function getPrimaryKeyHashFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        // If the PK cannot be derived from the row, return NULL.
        if ($row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('InhouseRevenueCollectionId', TableMap::TYPE_PHPNAME, $indexType)] === null) {
            return null;
        }

        return (string) $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('InhouseRevenueCollectionId', TableMap::TYPE_PHPNAME, $indexType)];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        return (int) $row[
            $indexType == TableMap::TYPE_NUM
                ? 0 + $offset
                : self::translateFieldName('InhouseRevenueCollectionId', TableMap::TYPE_PHPNAME, $indexType)
        ];
    }
    
    /**
     * The class that the tableMap will make instances of.
     *
     * If $withPrefix is true, the returned path
     * uses a dot-path notation which is translated into a path
     * relative to a location on the PHP include_path.
     * (e.g. path.to.MyClass -> 'path/to/MyClass.php')
     *
     * @param boolean $withPrefix Whether or not to return the path with the class name
     * @return string path.to.ClassName
     */
    public static function getOMClass($withPrefix = true)
    {
        return $withPrefix ? InhouseRevenueCollectionTableMap::CLASS_DEFAULT : InhouseRevenueCollectionTableMap::OM_CLASS;
    }

    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param array  $row       row returned by DataFetcher->fetch().
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType The index type of $row. Mostly DataFetcher->getIndexType().
                                 One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     * @return array           (InhouseRevenueCollection object, last column rank)
     */
    public static function populateObject($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        $key = InhouseRevenueCollectionTableMap::getPrimaryKeyHashFromRow($row, $offset, $indexType);
        if (null !== ($obj = InhouseRevenueCollectionTableMap::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $offset, true); // rehydrate
            $col = $offset + InhouseRevenueCollectionTableMap::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = InhouseRevenueCollectionTableMap::OM_CLASS;
            /** @var InhouseRevenueCollection $obj */
            $obj = new $cls();
            $col = $obj->hydrate($row, $offset, false, $indexType);
            InhouseRevenueCollectionTableMap::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @param DataFetcherInterface $dataFetcher
     * @return array
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function populateObjects(DataFetcherInterface $dataFetcher)
    {
        $results = array();
    
        // set the class once to avoid overhead in the loop
        $cls = static::getOMClass(false);
        // populate the object(s)
        while ($row = $dataFetcher->fetch()) {
            $key = InhouseRevenueCollectionTableMap::getPrimaryKeyHashFromRow($row, 0, $dataFetcher->getIndexType());
            if (null !== ($obj = InhouseRevenueCollectionTableMap::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                /** @var InhouseRevenueCollection $obj */
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                InhouseRevenueCollectionTableMap::addInstanceToPool($obj, $key);
            } // if key exists
        }

        return $results;
    }
    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param Criteria $criteria object containing the columns to add.
     * @param string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_REVENUE_HEAD_ID);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_MDA_CODE);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_MONTH);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_EXPECTED_PAYMENT_YEAR);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_AMOUNT);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_STATE);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_PAYER_NAME);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_RC_NUMBER);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_SOURCE_ID);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_TIN_NUMBER);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_PAYMENT_DATE);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_DATE_CREATED);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_CREATED_BY);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_DATE_MODIFIED);
            $criteria->addSelectColumn(InhouseRevenueCollectionTableMap::COL_MODIFIED_BY);
        } else {
            $criteria->addSelectColumn($alias . '.inhouse_revenue_collection_id');
            $criteria->addSelectColumn($alias . '.revenue_head_id');
            $criteria->addSelectColumn($alias . '.mda_code');
            $criteria->addSelectColumn($alias . '.expected_payment_month');
            $criteria->addSelectColumn($alias . '.expected_payment_year');
            $criteria->addSelectColumn($alias . '.amount');
            $criteria->addSelectColumn($alias . '.state');
            $criteria->addSelectColumn($alias . '.payer_name');
            $criteria->addSelectColumn($alias . '.rc_number');
            $criteria->addSelectColumn($alias . '.source_id');
            $criteria->addSelectColumn($alias . '.tin_number');
            $criteria->addSelectColumn($alias . '.payment_date');
            $criteria->addSelectColumn($alias . '.date_created');
            $criteria->addSelectColumn($alias . '.created_by');
            $criteria->addSelectColumn($alias . '.date_modified');
            $criteria->addSelectColumn($alias . '.modified_by');
        }
    }

    /**
     * Returns the TableMap related to this object.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getServiceContainer()->getDatabaseMap(InhouseRevenueCollectionTableMap::DATABASE_NAME)->getTable(InhouseRevenueCollectionTableMap::TABLE_NAME);
    }

    /**
     * Add a TableMap instance to the database for this tableMap class.
     */
    public static function buildTableMap()
    {
        $dbMap = Propel::getServiceContainer()->getDatabaseMap(InhouseRevenueCollectionTableMap::DATABASE_NAME);
        if (!$dbMap->hasTable(InhouseRevenueCollectionTableMap::TABLE_NAME)) {
            $dbMap->addTableObject(new InhouseRevenueCollectionTableMap());
        }
    }

    /**
     * Performs a DELETE on the database, given a InhouseRevenueCollection or Criteria object OR a primary key value.
     *
     * @param mixed               $values Criteria or InhouseRevenueCollection object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param  ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, ConnectionInterface $con = null)
     {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(InhouseRevenueCollectionTableMap::DATABASE_NAME);
        }

        if ($values instanceof Criteria) {
            // rename for clarity
            $criteria = $values;
        } elseif ($values instanceof \InhouseRevenueCollection) { // it's a model object
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(InhouseRevenueCollectionTableMap::DATABASE_NAME);
            $criteria->add(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID, (array) $values, Criteria::IN);
        }

        $query = InhouseRevenueCollectionQuery::create()->mergeWith($criteria);

        if ($values instanceof Criteria) {
            InhouseRevenueCollectionTableMap::clearInstancePool();
        } elseif (!is_object($values)) { // it's a primary key, or an array of pks
            foreach ((array) $values as $singleval) {
                InhouseRevenueCollectionTableMap::removeInstanceFromPool($singleval);
            }
        }

        return $query->delete($con);
    }

    /**
     * Deletes all rows from the inhouse_revenue_collection table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public static function doDeleteAll(ConnectionInterface $con = null)
    {
        return InhouseRevenueCollectionQuery::create()->doDeleteAll($con);
    }

    /**
     * Performs an INSERT on the database, given a InhouseRevenueCollection or Criteria object.
     *
     * @param mixed               $criteria Criteria or InhouseRevenueCollection object containing data that is used to create the INSERT statement.
     * @param ConnectionInterface $con the ConnectionInterface connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function doInsert($criteria, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(InhouseRevenueCollectionTableMap::DATABASE_NAME);
        }

        if ($criteria instanceof Criteria) {
            $criteria = clone $criteria; // rename for clarity
        } else {
            $criteria = $criteria->buildCriteria(); // build Criteria from InhouseRevenueCollection object
        }

        if ($criteria->containsKey(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID) && $criteria->keyContainsValue(InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.InhouseRevenueCollectionTableMap::COL_INHOUSE_REVENUE_COLLECTION_ID.')');
        }


        // Set the correct dbName
        $query = InhouseRevenueCollectionQuery::create()->mergeWith($criteria);

        // use transaction because $criteria could contain info
        // for more than one table (I guess, conceivably)
        return $con->transaction(function () use ($con, $query) {
            return $query->doInsert($con);
        });
    }

} // InhouseRevenueCollectionTableMap
// This is the static code needed to register the TableMap for this table with the main Propel class.
//
InhouseRevenueCollectionTableMap::buildTableMap();
