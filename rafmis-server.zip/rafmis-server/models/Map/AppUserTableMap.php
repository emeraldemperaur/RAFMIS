<?php

namespace Map;

use \AppUser;
use \AppUserQuery;
use Propel\Runtime\Propel;
use Propel\Runtime\ActiveQuery\Criteria;
use Propel\Runtime\ActiveQuery\InstancePoolTrait;
use Propel\Runtime\Connection\ConnectionInterface;
use Propel\Runtime\DataFetcher\DataFetcherInterface;
use Propel\Runtime\Exception\PropelException;
use Propel\Runtime\Map\RelationMap;
use Propel\Runtime\Map\TableMap;
use Propel\Runtime\Map\TableMapTrait;


/**
 * This class defines the structure of the 'app_user' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 */
class AppUserTableMap extends TableMap
{
    use InstancePoolTrait;
    use TableMapTrait;

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = '.Map.AppUserTableMap';

    /**
     * The default database name for this class
     */
    const DATABASE_NAME = 'rafmis';

    /**
     * The table name for this class
     */
    const TABLE_NAME = 'app_user';

    /**
     * The related Propel class for this table
     */
    const OM_CLASS = '\\AppUser';

    /**
     * A class that can be returned by this tableMap
     */
    const CLASS_DEFAULT = 'AppUser';

    /**
     * The total number of columns
     */
    const NUM_COLUMNS = 13;

    /**
     * The number of lazy-loaded columns
     */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /**
     * The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS)
     */
    const NUM_HYDRATE_COLUMNS = 13;

    /**
     * the column name for the username field
     */
    const COL_USERNAME = 'app_user.username';

    /**
     * the column name for the email field
     */
    const COL_EMAIL = 'app_user.email';

    /**
     * the column name for the role_id field
     */
    const COL_ROLE_ID = 'app_user.role_id';

    /**
     * the column name for the password field
     */
    const COL_PASSWORD = 'app_user.password';

    /**
     * the column name for the first_name field
     */
    const COL_FIRST_NAME = 'app_user.first_name';

    /**
     * the column name for the last_name field
     */
    const COL_LAST_NAME = 'app_user.last_name';

    /**
     * the column name for the active field
     */
    const COL_ACTIVE = 'app_user.active';

    /**
     * the column name for the last_login_date field
     */
    const COL_LAST_LOGIN_DATE = 'app_user.last_login_date';

    /**
     * the column name for the login_attempt field
     */
    const COL_LOGIN_ATTEMPT = 'app_user.login_attempt';

    /**
     * the column name for the date_created field
     */
    const COL_DATE_CREATED = 'app_user.date_created';

    /**
     * the column name for the created_by field
     */
    const COL_CREATED_BY = 'app_user.created_by';

    /**
     * the column name for the date_modified field
     */
    const COL_DATE_MODIFIED = 'app_user.date_modified';

    /**
     * the column name for the modified_by field
     */
    const COL_MODIFIED_BY = 'app_user.modified_by';

    /**
     * The default string format for model objects of the related table
     */
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldNames[self::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        self::TYPE_PHPNAME       => array('Username', 'Email', 'RoleId', 'Password', 'FirstName', 'LastName', 'Active', 'LastLoginDate', 'LoginAttempt', 'DateCreated', 'CreatedBy', 'DateModified', 'ModifiedBy', ),
        self::TYPE_CAMELNAME     => array('username', 'email', 'roleId', 'password', 'firstName', 'lastName', 'active', 'lastLoginDate', 'loginAttempt', 'dateCreated', 'createdBy', 'dateModified', 'modifiedBy', ),
        self::TYPE_COLNAME       => array(AppUserTableMap::COL_USERNAME, AppUserTableMap::COL_EMAIL, AppUserTableMap::COL_ROLE_ID, AppUserTableMap::COL_PASSWORD, AppUserTableMap::COL_FIRST_NAME, AppUserTableMap::COL_LAST_NAME, AppUserTableMap::COL_ACTIVE, AppUserTableMap::COL_LAST_LOGIN_DATE, AppUserTableMap::COL_LOGIN_ATTEMPT, AppUserTableMap::COL_DATE_CREATED, AppUserTableMap::COL_CREATED_BY, AppUserTableMap::COL_DATE_MODIFIED, AppUserTableMap::COL_MODIFIED_BY, ),
        self::TYPE_FIELDNAME     => array('username', 'email', 'role_id', 'password', 'first_name', 'last_name', 'active', 'last_login_date', 'login_attempt', 'date_created', 'created_by', 'date_modified', 'modified_by', ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. self::$fieldKeys[self::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        self::TYPE_PHPNAME       => array('Username' => 0, 'Email' => 1, 'RoleId' => 2, 'Password' => 3, 'FirstName' => 4, 'LastName' => 5, 'Active' => 6, 'LastLoginDate' => 7, 'LoginAttempt' => 8, 'DateCreated' => 9, 'CreatedBy' => 10, 'DateModified' => 11, 'ModifiedBy' => 12, ),
        self::TYPE_CAMELNAME     => array('username' => 0, 'email' => 1, 'roleId' => 2, 'password' => 3, 'firstName' => 4, 'lastName' => 5, 'active' => 6, 'lastLoginDate' => 7, 'loginAttempt' => 8, 'dateCreated' => 9, 'createdBy' => 10, 'dateModified' => 11, 'modifiedBy' => 12, ),
        self::TYPE_COLNAME       => array(AppUserTableMap::COL_USERNAME => 0, AppUserTableMap::COL_EMAIL => 1, AppUserTableMap::COL_ROLE_ID => 2, AppUserTableMap::COL_PASSWORD => 3, AppUserTableMap::COL_FIRST_NAME => 4, AppUserTableMap::COL_LAST_NAME => 5, AppUserTableMap::COL_ACTIVE => 6, AppUserTableMap::COL_LAST_LOGIN_DATE => 7, AppUserTableMap::COL_LOGIN_ATTEMPT => 8, AppUserTableMap::COL_DATE_CREATED => 9, AppUserTableMap::COL_CREATED_BY => 10, AppUserTableMap::COL_DATE_MODIFIED => 11, AppUserTableMap::COL_MODIFIED_BY => 12, ),
        self::TYPE_FIELDNAME     => array('username' => 0, 'email' => 1, 'role_id' => 2, 'password' => 3, 'first_name' => 4, 'last_name' => 5, 'active' => 6, 'last_login_date' => 7, 'login_attempt' => 8, 'date_created' => 9, 'created_by' => 10, 'date_modified' => 11, 'modified_by' => 12, ),
        self::TYPE_NUM           => array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, )
    );

    /**
     * Initialize the table attributes and columns
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('app_user');
        $this->setPhpName('AppUser');
        $this->setIdentifierQuoting(false);
        $this->setClassName('\\AppUser');
        $this->setPackage('');
        $this->setUseIdGenerator(false);
        // columns
        $this->addPrimaryKey('username', 'Username', 'VARCHAR', true, 64, null);
        $this->addColumn('email', 'Email', 'VARCHAR', true, 128, null);
        $this->addForeignKey('role_id', 'RoleId', 'VARCHAR', 'role', 'role_id', true, 64, null);
        $this->addColumn('password', 'Password', 'VARCHAR', false, 64, null);
        $this->addColumn('first_name', 'FirstName', 'VARCHAR', false, 64, null);
        $this->addColumn('last_name', 'LastName', 'VARCHAR', false, 64, null);
        $this->addColumn('active', 'Active', 'INTEGER', false, 1, null);
        $this->addColumn('last_login_date', 'LastLoginDate', 'TIMESTAMP', false, null, null);
        $this->addColumn('login_attempt', 'LoginAttempt', 'INTEGER', false, 1, null);
        $this->addColumn('date_created', 'DateCreated', 'TIMESTAMP', true, null, null);
        $this->addColumn('created_by', 'CreatedBy', 'VARCHAR', true, 64, null);
        $this->addColumn('date_modified', 'DateModified', 'TIMESTAMP', false, null, null);
        $this->addColumn('modified_by', 'ModifiedBy', 'VARCHAR', false, 64, null);
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('Role', '\\Role', RelationMap::MANY_TO_ONE, array (
  0 =>
  array (
    0 => ':role_id',
    1 => ':role_id',
  ),
), null, 'CASCADE', null, false);
    } // buildRelations()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return string The primary key hash of the row
     */
    public static function getPrimaryKeyHashFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        // If the PK cannot be derived from the row, return NULL.
        if ($row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Username', TableMap::TYPE_PHPNAME, $indexType)] === null) {
            return null;
        }

        return (string) $row[TableMap::TYPE_NUM == $indexType ? 0 + $offset : static::translateFieldName('Username', TableMap::TYPE_PHPNAME, $indexType)];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param array  $row       resultset row.
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM
     *
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        return (string) $row[
            $indexType == TableMap::TYPE_NUM
                ? 0 + $offset
                : self::translateFieldName('Username', TableMap::TYPE_PHPNAME, $indexType)
        ];
    }
    
    /**
     * The class that the tableMap will make instances of.
     *
     * If $withPrefix is true, the returned path
     * uses a dot-path notation which is translated into a path
     * relative to a location on the PHP include_path.
     * (e.g. path.to.MyClass -> 'path/to/MyClass.php')
     *
     * @param boolean $withPrefix Whether or not to return the path with the class name
     * @return string path.to.ClassName
     */
    public static function getOMClass($withPrefix = true)
    {
        return $withPrefix ? AppUserTableMap::CLASS_DEFAULT : AppUserTableMap::OM_CLASS;
    }

    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param array  $row       row returned by DataFetcher->fetch().
     * @param int    $offset    The 0-based offset for reading from the resultset row.
     * @param string $indexType The index type of $row. Mostly DataFetcher->getIndexType().
                                 One of the class type constants TableMap::TYPE_PHPNAME, TableMap::TYPE_CAMELNAME
     *                           TableMap::TYPE_COLNAME, TableMap::TYPE_FIELDNAME, TableMap::TYPE_NUM.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     * @return array           (AppUser object, last column rank)
     */
    public static function populateObject($row, $offset = 0, $indexType = TableMap::TYPE_NUM)
    {
        $key = AppUserTableMap::getPrimaryKeyHashFromRow($row, $offset, $indexType);
        if (null !== ($obj = AppUserTableMap::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $offset, true); // rehydrate
            $col = $offset + AppUserTableMap::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = AppUserTableMap::OM_CLASS;
            /** @var AppUser $obj */
            $obj = new $cls();
            $col = $obj->hydrate($row, $offset, false, $indexType);
            AppUserTableMap::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @param DataFetcherInterface $dataFetcher
     * @return array
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function populateObjects(DataFetcherInterface $dataFetcher)
    {
        $results = array();
    
        // set the class once to avoid overhead in the loop
        $cls = static::getOMClass(false);
        // populate the object(s)
        while ($row = $dataFetcher->fetch()) {
            $key = AppUserTableMap::getPrimaryKeyHashFromRow($row, 0, $dataFetcher->getIndexType());
            if (null !== ($obj = AppUserTableMap::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                /** @var AppUser $obj */
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                AppUserTableMap::addInstanceToPool($obj, $key);
            } // if key exists
        }

        return $results;
    }
    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param Criteria $criteria object containing the columns to add.
     * @param string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(AppUserTableMap::COL_USERNAME);
            $criteria->addSelectColumn(AppUserTableMap::COL_EMAIL);
            $criteria->addSelectColumn(AppUserTableMap::COL_ROLE_ID);
            $criteria->addSelectColumn(AppUserTableMap::COL_PASSWORD);
            $criteria->addSelectColumn(AppUserTableMap::COL_FIRST_NAME);
            $criteria->addSelectColumn(AppUserTableMap::COL_LAST_NAME);
            $criteria->addSelectColumn(AppUserTableMap::COL_ACTIVE);
            $criteria->addSelectColumn(AppUserTableMap::COL_LAST_LOGIN_DATE);
            $criteria->addSelectColumn(AppUserTableMap::COL_LOGIN_ATTEMPT);
            $criteria->addSelectColumn(AppUserTableMap::COL_DATE_CREATED);
            $criteria->addSelectColumn(AppUserTableMap::COL_CREATED_BY);
            $criteria->addSelectColumn(AppUserTableMap::COL_DATE_MODIFIED);
            $criteria->addSelectColumn(AppUserTableMap::COL_MODIFIED_BY);
        } else {
            $criteria->addSelectColumn($alias . '.username');
            $criteria->addSelectColumn($alias . '.email');
            $criteria->addSelectColumn($alias . '.role_id');
            $criteria->addSelectColumn($alias . '.password');
            $criteria->addSelectColumn($alias . '.first_name');
            $criteria->addSelectColumn($alias . '.last_name');
            $criteria->addSelectColumn($alias . '.active');
            $criteria->addSelectColumn($alias . '.last_login_date');
            $criteria->addSelectColumn($alias . '.login_attempt');
            $criteria->addSelectColumn($alias . '.date_created');
            $criteria->addSelectColumn($alias . '.created_by');
            $criteria->addSelectColumn($alias . '.date_modified');
            $criteria->addSelectColumn($alias . '.modified_by');
        }
    }

    /**
     * Returns the TableMap related to this object.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getServiceContainer()->getDatabaseMap(AppUserTableMap::DATABASE_NAME)->getTable(AppUserTableMap::TABLE_NAME);
    }

    /**
     * Add a TableMap instance to the database for this tableMap class.
     */
    public static function buildTableMap()
    {
        $dbMap = Propel::getServiceContainer()->getDatabaseMap(AppUserTableMap::DATABASE_NAME);
        if (!$dbMap->hasTable(AppUserTableMap::TABLE_NAME)) {
            $dbMap->addTableObject(new AppUserTableMap());
        }
    }

    /**
     * Performs a DELETE on the database, given a AppUser or Criteria object OR a primary key value.
     *
     * @param mixed               $values Criteria or AppUser object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param  ConnectionInterface $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *                         if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, ConnectionInterface $con = null)
     {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(AppUserTableMap::DATABASE_NAME);
        }

        if ($values instanceof Criteria) {
            // rename for clarity
            $criteria = $values;
        } elseif ($values instanceof \AppUser) { // it's a model object
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(AppUserTableMap::DATABASE_NAME);
            $criteria->add(AppUserTableMap::COL_USERNAME, (array) $values, Criteria::IN);
        }

        $query = AppUserQuery::create()->mergeWith($criteria);

        if ($values instanceof Criteria) {
            AppUserTableMap::clearInstancePool();
        } elseif (!is_object($values)) { // it's a primary key, or an array of pks
            foreach ((array) $values as $singleval) {
                AppUserTableMap::removeInstanceFromPool($singleval);
            }
        }

        return $query->delete($con);
    }

    /**
     * Deletes all rows from the app_user table.
     *
     * @param ConnectionInterface $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).
     */
    public static function doDeleteAll(ConnectionInterface $con = null)
    {
        return AppUserQuery::create()->doDeleteAll($con);
    }

    /**
     * Performs an INSERT on the database, given a AppUser or Criteria object.
     *
     * @param mixed               $criteria Criteria or AppUser object containing data that is used to create the INSERT statement.
     * @param ConnectionInterface $con the ConnectionInterface connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *                         rethrown wrapped into a PropelException.
     */
    public static function doInsert($criteria, ConnectionInterface $con = null)
    {
        if (null === $con) {
            $con = Propel::getServiceContainer()->getWriteConnection(AppUserTableMap::DATABASE_NAME);
        }

        if ($criteria instanceof Criteria) {
            $criteria = clone $criteria; // rename for clarity
        } else {
            $criteria = $criteria->buildCriteria(); // build Criteria from AppUser object
        }


        // Set the correct dbName
        $query = AppUserQuery::create()->mergeWith($criteria);

        // use transaction because $criteria could contain info
        // for more than one table (I guess, conceivably)
        return $con->transaction(function () use ($con, $query) {
            return $query->doInsert($con);
        });
    }

} // AppUserTableMap
// This is the static code needed to register the TableMap for this table with the main Propel class.
//
AppUserTableMap::buildTableMap();
