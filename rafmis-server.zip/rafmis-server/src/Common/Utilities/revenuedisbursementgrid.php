<?php

/*
 * DataTables example server-side processing script.
 *
 * Please note that this script is intentionally extremely simply to show how
 * server-side processing can be implemented, and probably shouldn't be used as
 * the basis for a large complex system. It is suitable for simple use cases as
 * for learning.
 *
 * See http://datatables.net/usage/server-side for full details on the server-
 * side processing requirements of DataTables.
 *
 * @license MIT - http://datatables.net/license_mit
 */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Easy set variables
 */
require(dirname(dirname(dirname(dirname(__FILE__)))) . DIRECTORY_SEPARATOR . "generated-conf/db.properties.php");

error_reporting(E_ERROR);
// DB table to use
$table = 'schedule_disbursement';

// Table's primary key
$primaryKey = 'beneficiary_id';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes

$columns = array(
//    array('db' => 'revenue_type_category_id', 'dt' => 'revenue_type_category_id'),
    array('db' => 'beneficiary_id', 'dt' => 'beneficiary_id')
    , array('db' => 'beneficiary_category_id', 'dt' => 'beneficiary_category_id', 'joined_table' => 'beneficiary')
//    , array('db' => 'principle_item_id', 'dt' => 'principle_item_id')
//    , array('db' => 'principle_item_name', 'dt' => 'principle_item_name')
    , array('db' => 'beneficiary_cat_allocation_group_id', 'dt' => 'beneficiary_cat_allocation_group_id')
    , array('db' => 'revenue_type_category_id', 'dt' => 'revenue_type_category_id')
    , array('db' => 'parent_id', 'dt' => 'parent_id', 'joined_table' => 'beneficiary')
    , array('db' => 'total_allocated_value', 'dt' => 'total_allocated_value')
    , array('db' => 'total_disbursed_value', 'dt' => 'total_disbursed_value')
    , array('db' => 'month', 'dt' => 'month')
    , array('db' => 'year', 'dt' => 'year')
    , array('db' => 'date_created', 'dt' => 'date_created')
    , array('db' => 'created_by', 'dt' => 'created_by')
    , array('db' => 'date_modified', 'dt' => 'date_modified')
    , array('db' => 'modified_by', 'dt' => 'modified_by')
);

// SQL server connection information
$sql_details = array(
    'user' => DB_USERNAME,
    'pass' => DB_PASSWORD,
    'db' => DATABASE_NAME,
    'host' => DATABASE_HOST
);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
//$query = 'SELECT SQL_CACHE SQL_CALC_FOUND_ROWS
// *
//FROM schedule ';

$beneficiary_cat_allocation_group_id = isset($_REQUEST['beneficiary_cat_allocation_group_id']) ? $_REQUEST['beneficiary_cat_allocation_group_id'] : '';
$beneficiary_category_id = isset($_REQUEST['beneficiary_category_id']) ? $_REQUEST['beneficiary_category_id'] : '';
$revenue_type_category_id = isset($_REQUEST['revenue_type_category_id']) ? $_REQUEST['revenue_type_category_id'] : '';
$month = isset($_REQUEST['month']) ? $_REQUEST['month'] : '';
$year = isset($_REQUEST['year']) ? $_REQUEST['year'] : '';

$query = "SELECT SQL_CACHE SQL_CALC_FOUND_ROWS
  schedule_disbursement.beneficiary_id,
  beneficiary.beneficiary_category_id,
  schedule_disbursement.beneficiary_cat_allocation_group_id,
  schedule_disbursement.revenue_type_category_id,
  beneficiary.parent_id,
  schedule_disbursement.total_allocated_value,
  schedule_disbursement.total_disbursed_value,
  schedule_disbursement.month,
  schedule_disbursement.year,
  schedule_disbursement.date_created,
  schedule_disbursement.created_by,
  schedule_disbursement.date_modified,
  schedule_disbursement.modified_by
FROM schedule_disbursement
  JOIN beneficiary
    ON beneficiary.beneficiary_id = schedule_disbursement.beneficiary_id ";


// Parent hack
$db = new PDO('mysql:host=' . DATABASE_HOST . ';dbname=' . DATABASE_NAME, DB_USERNAME, DB_PASSWORD);
$stmt = $db->prepare("SELECT SQL_CACHE SQL_CALC_FOUND_ROWS
  DISTINCT beneficiary.parent_id
FROM schedule_disbursement
  JOIN beneficiary
    ON beneficiary.beneficiary_id = schedule_disbursement.beneficiary_id
WHERE schedule_disbursement.beneficiary_cat_allocation_group_id = '$beneficiary_cat_allocation_group_id'
    AND beneficiary.beneficiary_category_id = '$beneficiary_category_id'
    AND `schedule_disbursement`.revenue_type_category_id = '$revenue_type_category_id'
    AND `schedule_disbursement`.`month` = '$month'
    AND `schedule_disbursement`.`year` = '$year' ");
$stmt->execute();
$result = $stmt->fetchAll(PDO::FETCH_COLUMN);

$value = "schedule_disbursement.beneficiary_cat_allocation_group_id = '$beneficiary_cat_allocation_group_id'
    AND beneficiary.beneficiary_category_id = '$beneficiary_category_id'
    AND `schedule_disbursement`.revenue_type_category_id = '$revenue_type_category_id'
    AND `schedule_disbursement`.`month` = '$month'
    AND `schedule_disbursement`.`year` = '$year'";
require( 'ssp.class.php' );
$output = SSP::complex2($_POST, $sql_details, $table, $primaryKey, $columns, $query, $value);
$output['parents'] = $result;
echo json_encode(
        $output
);

