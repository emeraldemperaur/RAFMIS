<?php

/*
 * DataTables example server-side processing script.
 *
 * Please note that this script is intentionally extremely simply to show how
 * server-side processing can be implemented, and probably shouldn't be used as
 * the basis for a large complex system. It is suitable for simple use cases as
 * for learning.
 *
 * See http://datatables.net/usage/server-side for full details on the server-
 * side processing requirements of DataTables.
 *
 * @license MIT - http://datatables.net/license_mit
 */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Easy set variables
 */
require(dirname(dirname(dirname(dirname(__FILE__)))) . DIRECTORY_SEPARATOR . "generated-conf/db.properties.php");

error_reporting(E_ERROR);
// DB table to use
$table = 'inhouse_revenue_collection';

// Table's primary key
$primaryKey = 'revenue_head_id';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes
$columns = array(
//    array('db' => 'revenue_type_category_id', 'dt' => 'revenue_type_category_id'),
    array('db' => 'inhouse_revenue_collection_id', 'dt' => 'inhouse_revenue_collection_id')
    , array('db' => 'revenue_head_id', 'dt' => 'revenue_head_id')
    , array('db' => 'mda_code', 'dt' => 'mda_code')
    , array('db' => 'expected_payment_month', 'dt' => 'expected_payment_month')
    , array('db' => 'expected_payment_year', 'dt' => 'expected_payment_year')
    , array('db' => 'amount', 'dt' => 'amount')
    , array('db' => 'state', 'dt' => 'state')
    , array('db' => 'payer_name', 'dt' => 'payer_name')
    , array('db' => 'rc_number', 'dt' => 'rc_number')
    , array('db' => 'source_id', 'dt' => 'source_id')
    , array('db' => 'tin_number', 'dt' => 'tin_number')
    , array('db' => 'payment_date', 'dt' => 'payment_date')
    , array('db' => 'date_created', 'dt' => 'date_created')
    , array('db' => 'created_by', 'dt' => 'created_by')
    , array('db' => 'date_modified', 'dt' => 'date_modified')
    , array('db' => 'modified_by', 'dt' => 'modified_by')
);


// SQL server connection information
$sql_details = array(
    'user' => DB_USERNAME,
    'pass' => DB_PASSWORD,
    'db' => DATABASE_NAME,
    'host' => DATABASE_HOST
);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
$query = 'SELECT SQL_CACHE SQL_CALC_FOUND_ROWS * FROM inhouse_revenue_collection ';

require( 'ssp.class.php' );
echo json_encode(
        SSP::complex2($_POST, $sql_details, $table, $primaryKey, $columns, $query)
);

