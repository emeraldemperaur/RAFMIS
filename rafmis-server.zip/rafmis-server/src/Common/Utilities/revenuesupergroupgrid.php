<?php

/*
 * DataTables example server-side processing script.
 *
 * Please note that this script is intentionally extremely simply to show how
 * server-side processing can be implemented, and probably shouldn't be used as
 * the basis for a large complex system. It is suitable for simple use cases as
 * for learning.
 *
 * See http://datatables.net/usage/server-side for full details on the server-
 * side processing requirements of DataTables.
 *
 * @license MIT - http://datatables.net/license_mit
 */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Easy set variables
 */
require(dirname(dirname(dirname(dirname(__FILE__)))) . DIRECTORY_SEPARATOR . "generated-conf/db.properties.php");

error_reporting(E_ERROR);
// DB table to use
$table = 'supergroup';

// Table's primary key
$primaryKey = 'supergroup_id';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes
$columns = array(
    array('db' => 'supergroup_id', 'dt' => 'supergroup_id'),
    array('db' => 'description', 'dt' => 'description')
    , array('db' => 'is_active', 'dt' => 'is_active')
    , array('db' => 'is_default', 'dt' => 'is_default')
    , array('db' => 'date_created', 'dt' => 'date_created')
    , array('db' => 'created_by', 'dt' => 'created_by')
    , array('db' => 'date_modified', 'dt' => 'date_modified')
    , array('db' => 'modified_by', 'dt' => 'modified_by')
);

// SQL server connection information
$sql_details = array(
    'user' => DB_USERNAME,
    'pass' => DB_PASSWORD,
    'db' => DATABASE_NAME,
    'host' => DATABASE_HOST
);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */

//require( dirname(dirname(dirname(dirname(__FILE__)))) . DIRECTORY_SEPARATOR . 'Common/ssp.class.php' );
require( 'ssp.class.php' );

echo json_encode(
        SSP::complex2($_POST, $sql_details, $table, $primaryKey, $columns, $query)
);

