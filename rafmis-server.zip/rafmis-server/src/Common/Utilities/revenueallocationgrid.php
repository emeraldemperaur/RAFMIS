<?php

/*
 * DataTables example server-side processing script.
 *
 * Please note that this script is intentionally extremely simply to show how
 * server-side processing can be implemented, and probably shouldn't be used as
 * the basis for a large complex system. It is suitable for simple use cases as
 * for learning.
 *
 * See http://datatables.net/usage/server-side for full details on the server-
 * side processing requirements of DataTables.
 *
 * @license MIT - http://datatables.net/license_mit
 */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Easy set variables
 */
require(dirname(dirname(dirname(dirname(__FILE__)))) . DIRECTORY_SEPARATOR . "generated-conf/db.properties.php");

error_reporting(E_ERROR);
// DB table to use
$table = 'beneficiary_category_allocation_group';

// Table's primary key
$primaryKey = 'beneficiary_cat_allocation_group_id';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes
$columns = array(
//    array('db' => 'revenue_type_category_id', 'dt' => 'revenue_type_category_id'),
    array('db' => 'beneficiary_cat_allocation_group_id', 'dt' => 'beneficiary_cat_allocation_group_id')
    , array('db' => 'description', 'dt' => 'description')
    , array('db' => 'date_created', 'dt' => 'date_created')
    , array('db' => 'created_by', 'dt' => 'created_by')
    , array('db' => 'date_modified', 'dt' => 'date_modified')
    , array('db' => 'modified_by', 'dt' => 'modified_by')
);

// SQL server connection information
$sql_details = array(
    'user' => DB_USERNAME,
    'pass' => DB_PASSWORD,
    'db' => DATABASE_NAME,
    'host' => DATABASE_HOST
);


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * If you just want to use the basic configuration for DataTables with PHP
 * server-side, there is no need to edit below this line.
 */
$query = 'SELECT SQL_CACHE SQL_CALC_FOUND_ROWS
  beneficiary_category_allocation_group.beneficiary_cat_allocation_group_id,
  beneficiary_category_allocation_group.description,
  beneficiary_category_allocation_group.date_created,
  beneficiary_category_allocation_group.created_by,
  beneficiary_category_allocation_group.date_modified,
  beneficiary_category_allocation_group.modified_by
FROM beneficiary_category_allocation_group ';

//$query = 'SELECT SQL_CACHE SQL_CALC_FOUND_ROWS
//  revenue_type_category.revenue_type_category_id,
//  beneficiary_category_allocation_group.beneficiary_cat_allocation_group_id,
//  beneficiary_category_allocation_group.description,
//  beneficiary_category_allocation_group.date_created,
//  beneficiary_category_allocation_group.created_by,
//  beneficiary_category_allocation_group.date_modified,
//  beneficiary_category_allocation_group.modified_by
//FROM beneficiary_category_allocation_group
//  JOIN revenue_allocation
//    ON revenue_allocation.beneficiary_cat_allocation_group_id = beneficiary_category_allocation_group.beneficiary_cat_allocation_group_id
//  JOIN revenue_type_category
//    ON revenue_type_category.revenue_type_category_id = revenue_allocation.revenue_type_category_id ';
//require( dirname(dirname(dirname(dirname(__FILE__)))) . DIRECTORY_SEPARATOR . 'Common/ssp.class.php' );
require( 'ssp.class.php' );
//var_dump($_GET);
$value = isset($_REQUEST['parent_id']) && $_REQUEST['parent_id'] !== '' ? 'revenue_type_category.revenue_type_category_id= \'' . $_REQUEST['parent_id'] . '\'' : null;
//var_dump($value);
echo json_encode(
        SSP::complex2($_POST, $sql_details, $table, $primaryKey, $columns, $query, $value)
//        SSP::complex ( $_POST, $sql_details, $table, $primaryKey, $columns )
);

