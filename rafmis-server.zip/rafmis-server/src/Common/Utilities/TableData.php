<?php

/*
 * Script:    DataTables server-side script for PHP and MySQL
 * Copyright: 2012 - John Becker, Beckersoft, Inc.
 * Copyright: 2010 - Allan Jardine
 * License:   GPL v2 or BSD (3-point)
 */

namespace Common\Utilities;

require_once __DIR__.'/../../../generated-conf/db.properties.php';
  
class TableData {
 
 	private $_db;

	public function __construct() {

		try {
			$host		= ''.DATABASE_HOST;
			$database	= ''.DATABASE_NAME;
			$user		= ''.DB_USERNAME;
			$passwd		= ''.DB_PASSWORD;

		    $this->_db = new \PDO('mysql:host='.$host.';dbname='.$database, $user, $passwd, array(\PDO::ATTR_PERSISTENT => true));
		} catch (\PDOException $e) {
		    error_log("Failed to connect to database: ".$e->getMessage());
		}		
		
	}

	public function get($table, $index_column, $columns) {
		// Paging
		$sLimit = "";
		if ( isset( $_GET['start'] ) && $_GET['length'] != '-1' ) {
			$sLimit = "LIMIT ".intval( $_GET['start'] ).", ".intval( $_GET['length'] );
		}
		
		// Ordering
		$sOrder = "";
		if ( isset( $_GET['iSortCol_0'] ) ) {
			$sOrder = "ORDER BY  ";
			for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ ) {
				if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" ) {
					$sortDir = (strcasecmp($_GET['sSortDir_'.$i], 'ASC') == 0) ? 'ASC' : 'DESC';
					$sOrder .= "`".$columns[ intval( $_GET['iSortCol_'.$i] ) ]."` ". $sortDir .", ";
				}
			}
			
			$sOrder = substr_replace( $sOrder, "", -2 );
			if ( $sOrder == "ORDER BY" ) {
				$sOrder = "";
			}
		}
		
		/* 
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables, and MySQL's regex functionality is very limited
		 */
		$sWhere = "";
		if ( isset($_GET['search']) && $_GET['search']['value'] != "" ) {
			$sWhere = "WHERE (";
			for ( $i=0 ; $i<count($columns) ; $i++ ) {
				if ( isset($_GET['search']['value']) && strlen($_GET['search']['value'])) {
					$sWhere .= "`".$columns[$i]."` LIKE :search OR ";
				}
			}
			$sWhere = substr_replace( $sWhere, "", -3 );
			$sWhere .= ')';
		};
		
		// Individual column filtering
		for ( $i=0 ; $i<count($columns) ; $i++ ) {
			if ( isset($_GET['columns'][$i]) && $_GET['columns'][$i]['searchable'] == "true" && $_GET['columns'][$i]['search']['value'] != '' ) {
				if ( $sWhere == "" ) {
					$sWhere = "WHERE ";
				}
				else {
					$sWhere .= " AND ";
				}
				$sWhere .= "`".$columns[$i]."` LIKE :search".$i." ";
			}
		}

		if (isset($_GET['field']) && isset($_GET['value'])) {
			if ($sWhere == "") {
				$sWhere = "WHERE ";
			} else {
				if (preg_match('/\d/', $sWhere)) {
					$sWhere .= " AND ";
				} else {
					$sWhere .= " OR ";
				}
			}
			$sWhere .= "`".$_GET['field']."` = '".$_GET['value']."'";
		}
		
		// SQL queries get data to display
		$sQuery = "SELECT SQL_CALC_FOUND_ROWS `".str_replace(" , ", " ", implode("`, `", $columns))."` FROM `".$table."` ".$sWhere." ".$sOrder." ".$sLimit;
		$statement = $this->_db->prepare($sQuery);
		
		// Bind parameters
		if ( isset($_GET['search']) && $_GET['search']['value'] != "" ) {
			$statement->bindValue(':search', '%'.$_GET['search']['value'].'%', \PDO::PARAM_STR);
		}

		for ( $i=0 ; $i<count($columns) ; $i++ ) {
			if ( isset($_GET['columns'][$i]) && $_GET['columns'][$i]['searchable'] == "true" && $_GET['columns'][$i]['search']['value'] != '' ) {
				$statement->bindValue(':search'.$i, '%'.$_GET['columns'][$i]['search']['value'].'%', \PDO::PARAM_STR);
			}
		}

//		if (isset($_GET['field']) && isset($_GET['value'])) {
//			$statement->bindValue(':value', $_GET['value'], \PDO::PARAM_STR);
//		}
//var_dump($statement->queryString);exit;
        $statement->execute();
		$rResult = $statement->fetchAll(\PDO::FETCH_ASSOC);
		
		$iFilteredTotal = current($this->_db->query('SELECT FOUND_ROWS()')->fetch());
		
		// Get total number of rows in table
		$sQuery = "SELECT COUNT(`".$index_column."`) FROM `".$table."`";
		$iTotal = current($this->_db->query($sQuery)->fetch());

		// Output
		$output = array(
			"draw" => intval($_GET['draw']),
			"recordsTotal" => $iTotal,
			"recordsFiltered" => $iFilteredTotal,
			"data" => array()
		);
		
		// Return array of values
		foreach($rResult as $aRow) {
			$row = array();			
			for ( $i = 0; $i < count($columns); $i++ ) {
				if ( $columns[$i] == "version" ) {
					// Special output formatting for 'version' column
					$row[] = ($aRow[ $columns[$i] ]=="0") ? '-' : $aRow[ $columns[$i] ];
				}
				else if ( $columns[$i] != ' ' ) {
					$row[$columns[$i]] = $aRow[ $columns[$i] ];
				}
			}
			$output['data'][] = $row;
		}
//		var_dump($_GET['search']);exit;
		
		return $output;
	}

}