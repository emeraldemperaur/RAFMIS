<?php

/**
 * Created by PhpStorm.
 * User: SNAQuaye
 * Date: 9/3/2015
 * Time: 10:13 AM
 */

namespace Common\Utilities;

class Mailer
{

    public static function sendEmail($subject, $from, $to, $body)
    {
        // Create Transport
        $transport = \Swift_MailTransport::newInstance();

        // Create Mailer with our Transport.
        $mailer = \Swift_Mailer::newInstance($transport);

        $message = \Swift_Message::newInstance($subject)
            ->setFrom($from)
            ->setTo($to)
            ->setBody($body)
            ->setContentType('text/html');

        return $mailer->send($message);
    }
}