<?php

/**
* Exception thrown on failed authorisation
*/

namespace Common\Exception;

class UnauthorizedHttpException extends \RuntimeException
{

    public function __construct($message = null, \Exception $previous = null, $code = 0)
    {
        parent::__construct($message, 401, $previous);
    }
}
