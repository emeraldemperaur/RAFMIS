<?php
/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/9/2015
 * Time: 10:21 AM
 */

namespace Common\Exception;


class BadCredentials extends \RuntimeException
{

	public function __construct($message = null, \Exception $previous = null, $code = 0)
	{
		parent::__construct($message, 401);
	}
}
