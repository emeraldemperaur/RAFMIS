<?php

namespace Common\Exception;

class AccessDeniedException extends \RuntimeException
{
    public function __construct($message = null, \Exception $previous = null, $code = 0)
    {
        parent::__construct($message, 403, $previous);
    }
}
