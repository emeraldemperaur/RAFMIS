<?php
/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/9/2015
 * Time: 12:35 PM
 */

namespace Common\Exception;


class SessionTimeoutException extends \RuntimeException
{
	public function __construct($message = null, \Exception $previous = null, $code = 0)
	{
		parent::__construct('Session Timeout', 401);
	}
}
