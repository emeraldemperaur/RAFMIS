<?php
/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 5/28/2015
 * Time: 4:37 PM
 */

namespace Common\Exception;


use RuntimeException;

class HttpNotFoundException extends RuntimeException {

    public function __construct($message = null, \Exception $previous = null, $code = 0)
    {
		http_response_code(404);
		parent::__construct($message, 404, $previous);
    }
}
