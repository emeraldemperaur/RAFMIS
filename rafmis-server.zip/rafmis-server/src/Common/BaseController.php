<?php

/*

 */

namespace Common;

use Common\Exception\HttpNotFoundException;
use Common\Exception\AccessDeniedException;
use Common\Exception\UnauthorizedHttpException;
use Common\Utilities\TableData;

class BaseController {

    protected $app;
    protected $execptionList = array(
        '/users/login'
    );
    protected $denyAll = FALSE;
    protected $tableData;

    public function __construct() {
        $this->app = \Slim\Slim::getInstance();
        $this->tableData = new TableData();
    }

    /**
     * @return \Slim\Helper\Set Slim inbuilt dependency injection container
     *
     * return an instance of Slim's dependency injection container
     */
    public function getContainer() {
        return $this->app->container;
    }

    /**
     * @param string $message exception message to display
     *
     * @throws HttpNotFoundException
     */
    public function createNotFoundException($message = 'Not Found') {
		$this->app->response->setStatus(404);
		echo $message;
    }

    /**
     * @param $repository string Name of repository service to return
     *
     * @return mixed returns a repository
     *
     * returns return a repository
     */
    public function getRepository($repository) {
        return $this->getContainer()->get($repository);
    }

    /**
     * @param string $message exception message to display
     *
     * @throws AccessDeniedException
     */
    public function createAccessDeniedException($message = 'Access Denied')
    {
		$this->app->response->setStatus(401);
		echo $message;
    }

    /**
     * @param string $message exception message to display
     *
     * @throws UnauthorizedHttpException
     */
    public function createUnauthorisedException($message = 'You don\'t have sufficient privileges to perform this action')
    {
		$this->app->response->setStatus(403);
        echo $message;
    }

    public function getCurrentUser()
    {
        return $this->getContainer()->get('security_manager')->getCurrentUsername();
    }
}

?>
