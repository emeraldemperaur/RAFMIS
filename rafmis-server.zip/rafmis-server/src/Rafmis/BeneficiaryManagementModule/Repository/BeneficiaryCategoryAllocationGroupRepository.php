<?php

/**
 *
 */

namespace Rafmis\BeneficiaryManagementModule\Repository;

use Propel\Runtime\Propel;
use Propel\Runtime\Exception\EntityNotFoundException;
use BeneficiaryCategoryAllocationGroup;
use BeneficiaryCategoryAllocationGroupQuery;
use Slim\Slim;

class BeneficiaryCategoryAllocationGroupRepository {

    /**
     * @var Slim
     */
    private $app;

    /**
     * @var BeneficiaryCategoryAllocationGroup
     */
    private $beneficiaryCategoryAllocationGroup;

    /**
     * @var BeneficiaryCategoryAllocationGroup
     */
    private $beneficiaryCategoryAllocationGroupQuery;

    /**
     * @param Slim $app
     */
    public function __construct(Slim $app) {
        $this->con = Propel::getConnection();
        $this->app = $app;
        $this->beneficiaryCategoryAllocationGroup = new BeneficiaryCategoryAllocationGroup();
        $this->beneficiaryCategoryAllocationGroupQuery = BeneficiaryCategoryAllocationGroupQuery::create();

        return $this;
    }

    /**
     * @param array $data
     * @return int The number of affected rows
     */
    public function save(array $data, $mode) {
//        var_dump($data);
//        =========================================================
        $BeneficiaryCategoryAllocationGroup = null;
        if (isset($data['beneficiary_cat_allocation_group_id']) && $mode == 'update') {
//            $BeneficiaryCategoryAllocationGroup = $this->findBy('beneficiary_cat_allocation_group_id', $data['beneficiary_cat_allocation_group_id']);
            $BeneficiaryCategoryAllocationGroup = BeneficiaryCategoryAllocationGroupQuery::create()->findOneByBeneficiaryCatAllocationGroupId($data['beneficiary_cat_allocation_group_id']);
        } else {
            $BeneficiaryCategoryAllocationGroup = $this->beneficiaryCategoryAllocationGroup;
        }
//        var_dump($BeneficiaryCategoryAllocationGroup);
        $BeneficiaryCategoryAllocationGroup->setBeneficiaryCatAllocationGroupId($data['beneficiary_cat_allocation_group_id']);
        $BeneficiaryCategoryAllocationGroup->setDescription($data['description']);
        $BeneficiaryCategoryAllocationGroup->setDateCreated($mode === 'create' ? date('Y-m-d H:i:s') : $BeneficiaryCategoryAllocationGroup->getDateCreated());
        $BeneficiaryCategoryAllocationGroup->setCreatedBy($mode === 'create' ? $data['created_by'] : $BeneficiaryCategoryAllocationGroup->getCreatedBy());
        $BeneficiaryCategoryAllocationGroup->setDateModified($mode === 'update' ? date('Y-m-d H:i:s') : $BeneficiaryCategoryAllocationGroup->getDateModified());
        $BeneficiaryCategoryAllocationGroup->setModifiedBy($mode === 'update' ? $data['modified_by'] : null);


        return $BeneficiaryCategoryAllocationGroup->save();
    }

    /**
     * @param $beneficiary_category_group_id
     *
     * @return array|mixed|BeneficiaryCategoryAllocationGroup finds a beneficiary category allocation by its pk
     *
     * finds a beneficiary category allocation by its pk
     */
    public function findByPK($beneficiary_category_group_id) {
        $beneficiaryCategoryAllocationGroupQuery = $this->findBy('BeneficiaryCatAllocationGroupId', $beneficiary_category_group_id);

        return $beneficiaryCategoryAllocationGroupQuery;
    }

    /**
     * @param $beneficiary_category_allocation_group_id
     *
     * @return mixed
     */
    public function delete($id) {
        /** @var BeneficiaryCategoryAllocationGroup $BeneficiaryCategoryAllocationGroup */
        $BeneficiaryCategoryAllocationGroup = $this->findBy('BeneficiaryCatAllocationGroupId', $id);

        $BeneficiaryCategoryAllocationGroup->delete();
    }

    private function findBy($columnName, $pk) {
        $BeneficiaryCategoryAllocationGroup = BeneficiaryCategoryAllocationGroupQuery::create()->findBy($columnName, $pk);

        return $BeneficiaryCategoryAllocationGroup;
    }

    public function findAll($page = 1, $count = 10) {
        $BeneficiaryCategoryAllocationGroups = BeneficiaryCategoryAllocationGroupQuery::create()->paginate($page, $count);

        return $BeneficiaryCategoryAllocationGroups;
    }

    public function filterCsv($request) {
        $query = "SELECT SQL_CACHE * FROM beneficiary_category_allocation_group";

        $q = $this->con->prepare("DESCRIBE beneficiary_category_allocation_group");
        $q->execute();
        $table_fields = $q->fetchAll(\PDO::FETCH_COLUMN);

        $columRefined = array_map(function($e) {
            return implode(' ', array_map(function($n) {
                        return ucwords($n);
                    }, explode('_', $e)));
        }, $table_fields);

        $stmt = $this->con->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        array_unshift($result, $columRefined);
        return $result;
    }

}
