<?php

/**

 */

namespace Rafmis\BeneficiaryManagementModule\Repository;

use Propel\Runtime\Propel;
use Propel\Runtime\Exception\EntityNotFoundException;
use BeneficiaryCategoryAllocation;
use BeneficiaryCategoryAllocationQuery;
use Slim\Slim;

class BeneficiaryCategoryAllocationRepository {

    /**
     * @var Slim
     */
    private $app;

    /**
     * @var beneficiaryCategoryAllocation
     */
    private $beneficiaryCategoryAllocation;

    /**
     * @var beneficiaryCategoryAllocation
     */
    private $beneficiaryCategoryAllocationQuery;

    /**
     * * @var Connectiom	 
     */
    private $con;

    /**
     * @param Slim $app
     */
    public function __construct(Slim $app) {
        $this->con = Propel::getConnection();
        $this->app = $app;
        $this->beneficiaryCategoryAllocation = new BeneficiaryCategoryAllocation();
        $this->beneficiaryCategoryAllocationQuery = BeneficiaryCategoryAllocationQuery::create();

        return $this;
    }

    /**
     * @param array $data
     * @return int The number of affected rows
     */
    public function save(array $data) {
        var_dump($data);
        $beneficiaryCategoryAllocation = $this->beneficiaryCategoryAllocation;

        //verifies if the data passed in is a managed by propel
//        if (isset($data['pk'])) {
//            $beneficiaryCategoryAllocation = $this->findBeneficiaryCategoryAllocationBy('BeneficiaryCategoryAllocationId', $data['pk']);
//        }
        //sets all required properties of the beneficiary category allocation
        $beneficiaryCategoryAllocation->setBeneficiaryCatAllocationGroupId($data['beneficiaryCatAllocationGroupId']);
        $beneficiaryCategoryAllocation->setBeneficiaryCategoryId($data['beneficiaryCategoryId']);
        $beneficiaryCategoryAllocation->setPercentageAllocation(floatval($data['percentageAllocation']));
        $beneficiaryCategoryAllocation->setPrincipleId($data['principleId']);

        return $this->beneficiaryCategoryAllocation->save();
    }

    /**
     * @param array $data
     * @return int The number of affected rows
     */
    public function saveMultiple(array $incomingdata, $currentUser) {
        try {

            $this->con->beginTransaction();

            $testSum = array_sum(array_map(function($n) {
                        $x = (array) $n;
                        $y = floatval($x['percentageAllocation']);
                        return ($y);
                    }, $incomingdata));
            if ($testSum > 100 || $testSum < 100) {
                $this->con->rollBack();
                throw new EntityNotFoundException('Percentage Allocations must add up to 100');
            }
            $sql1 = 'DELETE FROM beneficiary_category_allocation WHERE beneficiary_cat_allocation_group_id = ?';
            $stmt1 = $this->con->prepare($sql1);
            $x = ($incomingdata[0]);
            $y = (array) $x;
            $stmt1->bindValue(1, $y['beneficiaryCatAllocationGroupId']);
            $stmt1->execute();

            $sql2 = "INSERT INTO beneficiary_category_allocation VALUES(?,?,?,?,?,?,?,?)";
            $stmt2 = $this->con->prepare($sql2);



            foreach ($incomingdata as $data) {
//            $beneficiaryCategoryAllocation = $this->beneficiaryCategoryAllocation;
                $data = (array) $data;

                $stmt2->bindValue(1, $data['beneficiaryCatAllocationGroupId']);
                $stmt2->bindValue(2, $data['beneficiaryCategoryId']);
                $stmt2->bindValue(3, $data['percentageAllocation']);
                $stmt2->bindValue(4, $data['principleId']);
                $stmt2->bindValue(5, date('Y-m-d H:i:s'));
                $stmt2->bindValue(6, $currentUser);
                $stmt2->bindValue(7, null);
                $stmt2->bindValue(8, null);
                $stmt2->execute();
            }
            $this->con->commit();
        } catch (Exception $e) {
            $this->con->rollBack();
        }
    }

    /**
     * @param $beneficiary_category_group_id
     *
     * @return array|mixed|beneficiaryCategoryAllocation finds a beneficiary category allocation by its pk
     *
     * finds a beneficiary category allocation by its pk
     */
    public function findByGroupId($beneficiary_category_group_id) {

        $beneficiaryCategoryAllocationQuery = BeneficiaryCategoryAllocationQuery::create()->findByBeneficiaryCatAllocationGroupId($beneficiary_category_group_id);
        return $beneficiaryCategoryAllocationQuery;
    }

    /**
     * @param $beneficiary_category_id
     *
     * @return array|mixed|beneficiaryCategoryAllocation finds a beneficiary category allocation by its pk
     *
     * finds a beneficiary category allocation by its pk
     */
    public function findByBeneficiaryCategory($beneficiary_category_id) {
        $beneficiaryCategoryAllocationQuery = $this->findBy('BeneficiaryCategoryId', $beneficiary_category_id);

        return $beneficiaryCategoryAllocationQuery;
    }

    /**
     * @param $beneficiary_category_allocation_group_id
     *
     * @return mixed
     */
    public function delete($id) {
        /** @var beneficiaryCategoryAllocation $beneficiaryCategoryAllocation */
        $beneficiaryCategoryAllocation = $this->findBeneficiaryCategoryAllocationBy('BeneficiaryCatAllocationGroupId', $id);

        $beneficiaryCategoryAllocation->delete();
    }

    /**
     * @param $beneficiary_category_allocation_group_id
     *
     * @return mixed
     */
    public function deleteAll($id) {
        /** @var beneficiaryCategoryAllocation $beneficiaryCategoryAllocation */
        $sql1 = 'DELETE FROM beneficiary_category_allocation WHERE beneficiary_cat_allocation_group_id = ?';
        $stmt1 = $this->con->prepare($sql1);
        $stmt1->bindValue(1, $id);
        return $stmt1->execute();
    }

    private function findBy($columnName, $pk) {
        $beneficiaryCategoryAllocation = BeneficiaryCategoryAllocationQuery::create()->findBy($columnName, $pk);

        return $beneficiaryCategoryAllocation;
    }

    public function findAll($page = 1, $count = 10) {
        $beneficiaryCategoryAllocations = BeneficiaryCategoryAllocationQuery::create()->paginate($page, $count);

        return $beneficiaryCategoryAllocations;
    }

    public function filterCsv($request) {
        $beneficiary_category_allocation_group_id=$request['beneficiary_cat_allocation_group_id'];
        $query = "SELECT SQL_CACHE * FROM beneficiary_category_allocation WHERE beneficiary_cat_allocation_group_id='$beneficiary_category_allocation_group_id'";

        $q = $this->con->prepare("DESCRIBE beneficiary_category_allocation");
        $q->execute();
        $table_fields = $q->fetchAll(\PDO::FETCH_COLUMN);

        $columRefined = array_map(function($e) {
            return implode(' ', array_map(function($n) {
                        return ucwords($n);
                    }, explode('_', $e)));
        }, $table_fields);

        $stmt = $this->con->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        array_unshift($result, $columRefined);
        return $result;
    }

}
