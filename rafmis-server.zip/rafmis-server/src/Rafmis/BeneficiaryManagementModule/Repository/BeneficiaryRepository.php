<?php
/**

 */

namespace Rafmis\BeneficiaryManagementModule\Repository;


use Propel\Runtime\Exception\EntityNotFoundException;
use Beneficiary;
use BeneficiaryQuery;
use Slim\Slim;

class BeneficiaryRepository {

	/**
	 * @var Slim
	 */
	private $app;

	/**
	 * @var beneficiary
	 */
	private $beneficiary;

	/**
	 * @param Slim $app
	 */
	public function __construct(Slim $app)
	{
		$this->app = $app;
		$this->beneficiary= new Beneficiary();
        $this->beneficiaryQuery = BeneficiaryQuery::create();

		return $this;
	}

	/**
	 * @param array $data
	 * @return int The number of affected rows
	 */
	public function save(array $data)
	{
		$beneficiary = $this->beneficiaryQuery->findOneByBeneficiaryId($data['BeneficiaryId']);

		if (!$beneficiary) {
			$beneficiary = $this->beneficiary;
			$beneficiary->setDateCreated(new \DateTime());
			$beneficiary->setCreatedBy($data['CreatedBy']);
		} else {
			$beneficiary->setDateModified(new \DateTime());
			$beneficiary->setModifiedBy($data['ModifiedBy']);
		}

		//sets all required properties of the Beneficiary
		$beneficiary->setBeneficiaryId($data['BeneficiaryId']);
		$beneficiary->setBeneficiaryCategoryId($data['BeneficiaryCategoryId']);
		$beneficiary->setBeneficiaryName($data['BeneficiaryName']);
        if (isset($data['ParentId'])) {
            $beneficiary->setParentId($data['ParentId']);
        }

        return $beneficiary->save();
	}

	/**
	 * @param $id
	 *
	 * @return array|mixed|beneficiary finds a Beneficiary by its Primary Key
	 *
	 * finds a Beneficiary entity by its Primary Key
	 */
	public function findByPK($pk)
	{
		$beneficiaryQuery = $this->beneficiaryQuery->findOneByBeneficiaryId($pk);
		return $beneficiaryQuery;
	}

	/**
	 * @param $id
	 *
	 * @return array|mixed|beneficiary finds a Beneficiary using BeneficiaryCategoryId
	 *
	 * finds a Beneficiary using BeneficiaryCategoryId
	 */
	public function findByBeneficiaryCategory($beneficiary_category_id)
	{
		$beneficiaries = $this->beneficiaryQuery->findBy('BeneficiaryCategoryId',$beneficiary_category_id);
		return $beneficiaries;
	}

	/**
	 * @param $id
	 *
	 * @return mixed
	 */
	public function delete($id)
	{
		/** @var beneficiary$beneficiary*/
		$beneficiary= $this->findByPk($id);
		$beneficiary->delete();
	}

	public function findAll($page = 1, $count = 10)
	{
		$beneficiaries = BeneficiaryQuery::create()->find();

		return $beneficiaries;
	}

    public function getBeneficiaryChildren($beneficiaryId)
    {
        return $this->beneficiaryQuery->findByParentId($beneficiaryId);
    }

	public function getPaginatedData($startIndex, $itemsPerPage, $orderBy='BeneficiaryId', $sort="ASC", $search='')
	{
        $page = ceil($startIndex / $itemsPerPage);

        if (!strlen($search)) {
            $records = $this->beneficiaryQuery->orderBy($orderBy, $sort)->paginate($page, $itemsPerPage)->getResults()->toJSON();
        } else {
            $records = $this->beneficiaryQuery->filterByBeneficiaryId($search)->_or()
                ->filterByBeneficiaryCategoryId($search)->_or()->filterByBeneficiaryName()
                ->_or()->filterByParentId($search)->orderBy($orderBy, $sort)->paginate($page, $itemsPerPage)->getResults()->toJSON();
        }

        return array(
			'numberOfRecords' => $this->beneficiaryQuery->count(),
			'data' => $records
		);
	}

    /**
     * @param $criteria
     * @return array|\Beneficiary[]|mixed|\Propel\Runtime\ActiveRecord\ActiveRecordInterface[]|\Propel\Runtime\Collection\ObjectCollection
     */
	public function filterData($criteria)
	{
        return $this->beneficiaryQuery->filterByArray($criteria)->find();
	}
}
