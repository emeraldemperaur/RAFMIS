<?php
/**

 */

namespace Rafmis\BeneficiaryManagementModule\Repository;


use Propel\Runtime\Exception\EntityNotFoundException;
use BeneficiaryCategory;
use BeneficiaryCategoryQuery;
use Slim\Slim;

class BeneficiaryCategoryRepository {

	/**
	 * @var Slim
	 */
	private $app;

	/**
	 * @var beneficiaryCategory
	 */
	private $beneficiaryCategory;

	/**
	 * @param Slim $app
	 */
	public function __construct(Slim $app)
	{
		$this->app = $app;
		$this->beneficiaryCategory= new BeneficiaryCategory();
        $this->beneficiaryCategoryQuery = BeneficiaryCategoryQuery::create();

		return $this;
	}

	/**
	 * @param array $data
	 * @return int The number of affected rows
	 */
	public function save(array $data)
	{
		$beneficiaryCategory= $this->beneficiaryCategoryQuery->findOneByBeneficiaryCategoryId($data['BeneficiaryCategoryId']);

		//verifies if the data passed in is a managed by propel
		if (!$beneficiaryCategory) {
			$beneficiaryCategory= $this->beneficiaryCategory;
        	$beneficiaryCategory->setBeneficiaryCategoryId($data['BeneficiaryCategoryId']);
			$beneficiaryCategory->setDateCreated(new \DateTime());
			$beneficiaryCategory->setCreatedBy($data['username']);
		} else {
			$beneficiaryCategory->setDateModified(new \DateTime());
			$beneficiaryCategory->setModifiedBy($data['username']);
		}

		//sets all required properties of the Beneficiary Category entity
        $beneficiaryCategory->setDescription($data['Description']);
        if (isset($data['ParentCategoryId'])) {
            $beneficiaryCategory->setParentCategoryId($data['ParentCategoryId']);
        }

        return $beneficiaryCategory->save();
	}

	/**
	 * @param $id
	 *
	 * @return array|mixed|beneficiaryCategory finds a Beneficiary Category by its Primary Key
	 *
	 * finds a Beneficiary Category entity by its Primary Key
	 */
	public function findByPK($pk)
	{
		$beneficiaryCategoryQuery = $this->beneficiaryCategoryQuery->findOneByBeneficiaryCategoryId($pk);
		return $beneficiaryCategoryQuery;
	}

	/**
	 * @param $id
	 *
	 * @return mixed
	 */
	public function delete($id)
	{
		/** @var beneficiaryCategory$beneficiaryCategory*/
		$beneficiaryCategory= $this->findBy('BeneficiaryCategoryId',  $id);
		$beneficiaryCategory->delete();
	}

	private function findBy($columnName, $id)
	{
		$beneficiaryCategory= BeneficiaryCategoryQuery::create()->findBy($columnName, $id);

		if (!$beneficiaryCategory) {
			throw new EntityNotFoundException('Beneficiary Category Entity Not Found!');
		}

		return $beneficiaryCategory;
	}

	public function findAll($page = 1, $count = 10)
	{
		$beneficiaryCategories = beneficiaryCategoryQuery::create()->find();

		return $beneficiaryCategories;
	}

	public function findBeneficiaryByBeneficiaryCategoryId($beneficiaryCategoryId)
	{
		$parentCategoryId = $this->findByPK($beneficiaryCategoryId)->getParentCategoryId();

		$beneficiaries = $this->beneficiaryCategoryQuery->rightJoinBeneficiary()
			->filterByBeneficiaryCategoryId($parentCategoryId);

		return $beneficiaries;
	}

	public function filterData()
	{
		return $this->beneficiaryCategoryQuery->find();
	}
}
