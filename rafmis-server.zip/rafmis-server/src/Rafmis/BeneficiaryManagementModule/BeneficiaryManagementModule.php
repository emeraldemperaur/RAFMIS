<?php
/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 5/28/2015
 * Time: 10:46 PM
 */

namespace Rafmis\BeneficiaryManagementModule;

use Common\ServiceProviderInterface;
use Rafmis\BeneficiaryManagementModule\Repository\BeneficiaryRepository;
use Rafmis\BeneficiaryManagementModule\Repository\BeneficiaryCategoryRepository;
use Rafmis\BeneficiaryManagementModule\Repository\BeneficiaryCategoryAllocationRepository;
use Rafmis\BeneficiaryManagementModule\Repository\BeneficiaryCategoryAllocationGroupRepository;
use Slim\Slim;

class BeneficiaryManagementModule
{
	public function register($app)
	{
        //adds BeneficiaryRepository to Slim container
		$app->container->singleton('beneficiary_repository', function () use ($app) {
			return new BeneficiaryRepository($app);
		});

		//adds BeneficiaryCategoryRepository to Slim container
		$app->container->singleton('beneficiary_category_repository', function () use ($app) {
			return new BeneficiaryCategoryRepository($app);
		});

        //adds BeneficiaryCategoryAllocationRepository to Slim container
		$app->container->singleton('beneficiary_category_allocation_repository', function () use ($app) {
			return new BeneficiaryCategoryAllocationRepository($app);
		});

        //adds BeneficiaryCategoryAllocationGroupRepository to Slim container
		$app->container->singleton('beneficiary_category_allocation_group_repository', function () use ($app) {
			return new BeneficiaryCategoryAllocationGroupRepository($app);
		});
	}
}
