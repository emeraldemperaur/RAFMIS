<?php

/**

 */

namespace Rafmis\BeneficiaryManagementModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\BeneficiaryManagementModule\Repository\BeneficiaryCategoryAllocationRepository;

class BeneficiaryCategoryAllocationController extends BaseController {

    const REPOSITORY_NAME = 'beneficiary_category_allocation_repository';

    public function all($page = 1, $count = 10) {
        /** @var BeneficiaryCategoryAllocationRepository $BeneficiaryCategoryAllocationRepository */
        $beneficiaryCategoryAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);
        $beneficiaryCategoryAllocations = $beneficiaryCategoryAllocationRepository->findAll($page, $count);

        if (!$beneficiaryCategoryAllocations->count()) {
            echo 'No Beneficiary category allocation has been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
            echo $beneficiaryCategoryAllocations->toJSON();
        }
    }

    public function create() {
        $request = $this->app->request->getBody();

        /** @var BeneficiaryCategoryAllocationRepository $BeneficiaryCategoryAllocationRepository */
        $beneficiaryCategoryAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);
        $beneficiaryCategoryAllocationRepository->save($request);

        echo 'Beneficiary category allocation has successfully been created';
    }

    public function addBreakdown() {
        $beneficiaryCategoryAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);

        $currentUser=$this->getCurrentUser();
        $request = $this->app->request->getBody();
        $breakDowns = json_decode($request);
        $beneficiaryCategoryAllocationRepository->saveMultiple($breakDowns,$currentUser);

        /** @var BeneficiaryCategoryAllocationRepository $BeneficiaryCategoryAllocationRepository */
//        $beneficiaryCategoryAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);
//        $beneficiaryCategoryAllocationRepository->save($request);
        echo 'Beneficiary category allocation has successfully been created';
    }

    public function show($id) {
        /** @var BeneficiaryCategoryAllocationRepository $BeneficiaryCategoryAllocationRepository */
        $beneficiaryCategoryAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $beneficiaryCategoryAllocation = $beneficiaryCategoryAllocationRepository->findByBeneficiaryCategory($id);
            echo json_encode($beneficiaryCategoryAllocation);
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function showGroup($id) {
        /** @var BeneficiaryCategoryAllocationRepository $BeneficiaryCategoryAllocationRepository */
        $beneficiaryCategoryAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $beneficiaryCategoryAllocation = $beneficiaryCategoryAllocationRepository->findByGroupId($id);

            echo ($beneficiaryCategoryAllocation->toJSON());
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function update() {
        $request = $this->app->request->put();

        /** @var BeneficiaryCategoryAllocationRepository $BeneficiaryCategoryAllocationRepository */
        $BeneficiaryCategoryAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $BeneficiaryCategoryAllocationRepository->save($request);
            echo 'Beneficiary category allocation was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($id) {
        $BeneficiaryCategoryAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $BeneficiaryCategoryAllocationRepository->delete($id);
            echo 'Beneficiary category allocation was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }
    public function deleteAll($id) {
        $BeneficiaryCategoryAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $BeneficiaryCategoryAllocationRepository->deleteAll($id);
            echo 'Beneficiary category allocations were successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }
     public function filterCsv() {
        $request = json_decode($this->app->request->getBody(), true);
        $revenueCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);
        $input_array = $revenueCollectionRepository->filterCsv($request);
        $this->create_csv($input_array, 'a.csv', ',');
    }

    function create_csv($input_array, $output_file_name, $delimiter) {
        /** open raw memory as file, no need for temp files, be careful not to run out of memory thought */
        $f = fopen('php://memory', 'w');
        /** loop through array  */
        foreach ($input_array as $line) {
            /** default php csv handler * */
            fputcsv($f, $line, $delimiter);
        }
        /** rewrind the "file" with the csv lines * */
        fseek($f, 0);
        /** modify header to be downloadable csv file * */
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
//        header("Content-Type: $type");
        header("Content-Transfer-Encoding: binary");
        header('Content-Type: application/csv');
        header('Content-Disposition: attachement; filename="' . $output_file_name . '";');
        /** Send file to browser for download */
        fpassthru($f);
    }

}
