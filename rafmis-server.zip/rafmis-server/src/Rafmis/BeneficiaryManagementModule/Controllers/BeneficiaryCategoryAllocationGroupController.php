<?php

/**
 *
 */

namespace Rafmis\BeneficiaryManagementModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\BeneficiaryManagementModule\Repository\BeneficiaryCategoryAllocationGroupRepository;

class BeneficiaryCategoryAllocationGroupController extends BaseController {

    const REPOSITORY_NAME = 'beneficiary_category_allocation_group_repository';

    public function all($page = 1, $count = 10) {
        /** @var BeneficiaryCategoryAllocationGroupRepository $BeneficiaryCategoryAllocationGroupRepository */
        $beneficiaryCategoryAllocationGroupRepository = $this->getRepository(self::REPOSITORY_NAME);
        $beneficiaryCategoryAllocationGroups = $beneficiaryCategoryAllocationGroupRepository->findAll($page, $count);

        if (!$beneficiaryCategoryAllocationGroups->count()) {
            echo 'No Beneficiary category allocation group has been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
            echo ($beneficiaryCategoryAllocationGroups->toJSON());
        }
    }

    public function create() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['date_created'] = date('Y-m-d H:i:s');
        $request['created_by'] = $this->getCurrentUser();

        /** @var BeneficiaryCategoryAllocationGroupRepository $BeneficiaryCategoryAllocationGroupRepository */
        $beneficiaryCategoryAllocationGroupRepository = $this->getRepository(self::REPOSITORY_NAME);
        $beneficiaryCategoryAllocationGroupRepository->save($request, 'create');

        echo 'Beneficiary category allocation group has successfully been created';
    }

    public function addToRevCat($revenueTypeCategoryId) {
        try {
            $request = json_decode($this->app->request->getBody(), true);

            $beneficiaryCategoryAllocationGroup = new \BeneficiaryCategoryAllocationGroup();
            $beneficiaryCategoryAllocationGroup->setBeneficiaryCatAllocationGroupId($request['beneficiary_cat_allocation_group_id']);
            $beneficiaryCategoryAllocationGroup->setDescription($request['description']);
            $beneficiaryCategoryAllocationGroup->setDateCreated(date('Y-m-d H:i:s'));
            $beneficiaryCategoryAllocationGroup->setCreatedBy($this->getCurrentUser());
            $beneficiaryCategoryAllocationGroup->save();


            $revenueAllocation = new \RevenueAllocation();
            $revenueAllocation->setBeneficiaryCatAllocationGroupId($request['beneficiary_cat_allocation_group_id']);
            $revenueAllocation->setRevenueTypeCategoryId($revenueTypeCategoryId);
            $revenueAllocation->setDateCreated(date('Y-m-d H:i:s'));
            $revenueAllocation->setCreatedBy($this->getCurrentUser());

            $revenueAllocation->save();
        } catch (Exception $e) {
            throw $e;
        }
    }

    public function show($id) {
        /** @var BeneficiaryCategoryAllocationGroupRepository $BeneficiaryCategoryAllocationGroupRepository */
        $BeneficiaryCategoryAllocationGroupRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $beneficiaryCategoryAllocationGroup = $BeneficiaryCategoryAllocationGroupRepository->findByPK($id);
            echo json_encode($beneficiaryCategoryAllocationGroup);
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function update() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['date_modified'] = date('Y-m-d H:i:s');
        $request['modified_by'] = $this->getCurrentUser();
//        var_dump($request);

        /** @var BeneficiaryCategoryAllocationGroupRepository $BeneficiaryCategoryAllocationGroupRepository */
        $beneficiaryCategoryAllocationGroupRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $beneficiaryCategoryAllocationGroupRepository->save($request, "update");
            echo 'Beneficiary category allocation group was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($id) {
        $beneficiaryCategoryAllocationGroupRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $beneficiaryCategoryAllocationGroupRepository->delete($id);
            echo 'Beneficiary category allocation group was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function filterCsv() {
        $request = json_decode($this->app->request->getBody(), true);
        $revenueCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);
        $input_array = $revenueCollectionRepository->filterCsv($request);
        $this->create_csv($input_array, 'a.csv', ',');
    }

    function create_csv($input_array, $output_file_name, $delimiter) {
        /** open raw memory as file, no need for temp files, be careful not to run out of memory thought */
        $f = fopen('php://memory', 'w');
        /** loop through array  */
        foreach ($input_array as $line) {
            /** default php csv handler * */
            fputcsv($f, $line, $delimiter);
        }
        /** rewrind the "file" with the csv lines * */
        fseek($f, 0);
        /** modify header to be downloadable csv file * */
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
//        header("Content-Type: $type");
        header("Content-Transfer-Encoding: binary");
        header('Content-Type: application/csv');
        header('Content-Disposition: attachement; filename="' . $output_file_name . '";');
        /** Send file to browser for download */
        fpassthru($f);
    }

}
