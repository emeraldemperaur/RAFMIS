<?php
/**

 */

namespace Rafmis\BeneficiaryManagementModule\Controllers;


use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\BeneficiaryManagementModule\Repository\BeneficiaryRepository;

class BeneficiaryController extends BaseController {

	const REPOSITORY_NAME = 'beneficiary_repository';

	public function all()
	{
		$request = $this->app->request->get();
		/** @var beneficiaryRepository $beneficiaryRepository */
		$beneficiaryRepository = $this->getRepository(self::REPOSITORY_NAME);
		if (count($request)) {
			$columns = array(
				'beneficiary_id',
				'beneficiary_category_id',
				'beneficiary_name',
				'parent_id',
			);
			$beneficiaries = $this->tableData->get('beneficiary', 'beneficiary_id', $columns);
		} else {
			$beneficiaries = $beneficiaryRepository->findAll();
		}

		if (!count($beneficiaries)) {
			echo 'No beneficiary has been added';
		} else if (count($request)) {
			echo json_encode($beneficiaries);
		} else {
			$this->app->response->header('content-type', 'application/json');
			echo $beneficiaries->toJSON();
		}
	}

	public function show($id)
	{
		/** @var beneficiaryRepository $beneficiaryRepository */
		$beneficiaryRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {
			$beneficiary = $beneficiaryRepository->findByPK($id);

			echo $beneficiary->exportTo('json');
		} catch (EntityNotFoundException $e) {
			$this->app->response->setStatus(404);
			$this->createNotFoundException($e->getMessage());
		}
	}

    public function showBeneficiaryCategory($beneficiary_category_id)
	{
		/** @var BeneficiaryCategoryAllocationRepository $BeneficiaryCategoryAllocationRepository */
		$beneficiaryRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {

			$beneficiary = $beneficiaryRepository->findByBeneficiaryCategory($beneficiary_category_id);
			echo $beneficiary->toJSON();

		} catch (EntityNotFoundException $e) {
			$this->app->response->setStatus(404);
			$this->createNotFoundException($e->getMessage());
		}
	}

    public function create()
	{
		$request = json_decode($this->app->request->getBody(), true);
		$request['CreatedBy'] = $this->getCurrentUser();

		/** @var beneficiaryRepository $beneficiaryRepository */
		$beneficiaryRepository = $this->getRepository(self::REPOSITORY_NAME);
		$beneficiaryRepository->save($request);

		echo 'beneficiary has successfully been created';
	}

	public function update()
	{
		$request = json_decode($this->app->request->getBody(), true);
		$request['ModifiedBy'] = $this->getCurrentUser();

		/** @var beneficiaryRepository $beneficiaryRepository */
		$beneficiaryRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {
			$beneficiaryRepository->save($request);
			echo 'beneficiary was successfully updated';
		} catch (EntityNotFoundException $e) {
			$this->createNotFoundException();
		}
	}

	public function delete($id)
	{
		$beneficiaryRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {
			$beneficiaryRepository->delete($id);
			echo 'beneficiary was successfully deleted';
		} catch (EntityNotFoundException $e) {
			$this->app->response->setStatus(404);
			$this->createNotFoundException($e->getMessage());
		}
	}

    public function getBeneficiaryChildren($beneficiaryId)
    {
        /** @var BeneficiaryRepository $beneficiaryRepository */
        $beneficiaryRepository = $this->getRepository(self::REPOSITORY_NAME);
        $beneficiaries = $beneficiaryRepository->getBeneficiaryChildren($beneficiaryId);

        echo $beneficiaries->toJSON();
    }

	public function exportData()
	{
		$request = $this->app->request->get();

		/** @var BeneficiaryRepository $beneficiaryRepository */
		$beneficiaryRepository = $this->getRepository(self::REPOSITORY_NAME);
		$beneficiaries = $beneficiaryRepository->filterData($request);

        echo $beneficiaries->toJSON();
	}
}
