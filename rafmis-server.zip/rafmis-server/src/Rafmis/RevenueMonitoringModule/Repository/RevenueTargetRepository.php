<?php

namespace Rafmis\RevenueMonitoringModule\Repository;

use Map\RevenueTargetTableMap;
use Propel\Runtime\Formatter\ObjectFormatter;
use Propel\Runtime\Propel;
use Propel\Runtime\Exception\EntityNotFoundException;
use Propel\Runtime\Exception\PropelException;
use RevenueTarget;
use RevenueTargetQuery;
use Slim\Slim;


class RevenueTargetRepository {

    /**
     * @var Slim
     */
    private $app;

    /**
     * @var RevenueTarget
     */
    private $revenueTarget;

    /**
     * * @var Connectiom	 
     */
    private $con;

    /**
     * @param Slim $app
     */
    public function __construct(Slim $app) {
        $this->con = Propel::getConnection();
        $this->app = $app;
//        $this->revenueTarget = new RevenueTarget();
//        $this->revenueTargetQuery = RevenueTargetQuery::create();

        return $this;
    }

    /**
     * @param array $data
     * @return int The number of affected rows
     */
    public function saveRevenueTarget(array $data, $mode) {
//        var_dump($data);
//        die();
        try {
            $mda_code = $data['mda_code'];
            $payment_period_month = $data['payment_period_month'];
            $payment_period_year = $data['payment_period_year'];
            $target_amount = $data['target_amount'];
            $date_created = $data['date_created'];
            $created_by = $data['created_by'];
            $sql = "INSERT INTO revenue_target(`mda_code`,`payment_period_month`,`payment_period_year`,`target_amount`,`date_created`,`created_by`,`date_modified`,`modified_by`) VALUES('$mda_code','$payment_period_month','$payment_period_year','$target_amount','$date_created','$created_by',NULL, NULL)";

            $stmt = $this->con->prepare($sql);
            $stmt->execute();
        } catch (PropelException $ex) {
            throw $ex;
        }
    }

    public function updateRevenueTarget(array $data, $mode) {
//        var_dump($data);
//        die();
        try {
            $mda_code = $data['mda_code'];
            $payment_period_month = $data['payment_period_month'];
            $payment_period_year = $data['payment_period_year'];
            $target_amount = $data['target_amount'];
            $date_modified = $data['date_modified'];
            $modified_by = $data['modified_by'];
//            $sql = "INSERT INTO revenue_target(`mda_code`,`payment_period_month`,`payment_period_year`,`target_amount`,`date_created`,`created_by`,`date_modified`,`modified_by`) VALUES('$mda_code','$payment_period_month','$payment_period_year','$target_amount','$date_created','$created_by','$date_modified','$modified_by')";
            $sql = "UPDATE revenue_target SET `mda_code`='$mda_code',`payment_period_month`='$payment_period_month',`payment_period_year` = '$payment_period_year',`target_amount` = '$target_amount',`date_modified` = '$date_modified',`modified_by` = '$modified_by' WHERE `mda_code`='$mda_code' AND `payment_period_month`='$payment_period_month' AND `payment_period_year` = '$payment_period_year'";

            $stmt = $this->con->prepare($sql);
            $stmt->execute();
        } catch (PropelException $ex) {
            throw $ex;
        }
    }

    private function placeholders($text, $count = 0, $separator = ",") {
        $result = array();
        if ($count > 0) {
            for ($x = 0; $x < $count; $x++) {
                $result[] = $text;
            }
        }

        return implode($separator, $result);
    }

    public function import($csvArray, $mdaCode, $month, $year, $amount, $dateCreated, $createdBy) {
        $db = $this->con;
        $count = 0;
        $start = 0;
        $limit = 1000;
        $stop = false;
        //there representation in the csv array
        $columns = array($mdaCode, $month, $year, $amount, "rafmis_column_1_date_created" => $dateCreated,
            "rafmis_column_1_created_by" => $createdBy);
        do {
            $result = array_splice($csvArray, $start, $limit);
            if (count($result) < $limit) {
                $stop = true;
            }
            if (count($result) == 0) {
                break;
            }
            $question_marks = array();
            $mergeArray = array();
            $errorStore = array();

            $sql = "INSERT INTO revenue_target (mda_code,payment_period_month,payment_period_year,target_amount,date_created,created_by) VALUES (" . $this->placeholders('?', sizeof($columns)) . ")";
            foreach ($result as $value) {
                $mergeArray = array();
                // $value is row

                foreach ($columns as $key => $value2) {
                    $value[""] = NULL;
                    if (preg_match("/rafmis_column_1_/", $key)) {
                        $mergeArray[] = $this->replaceStr(trim($value2));
                    } else {
                        $mergeArray[] = $this->replaceStr(trim($value[$value2]));
                    }
                }
                try {
                    $db->beginTransaction();
                    $stmt = $db->prepare($sql);
                    $stmt->execute($mergeArray);
                    $db->commit();
                    $count += intval($stmt->rowCount());
                } catch (PDOException $e) {
                    $db->rollback();
//                    throw $e;
//                    $this->app->halt();
                    $errorStore[] = $value;
                    continue;
                }

//          =========================================================
            }
        } while (!$stop);
        return array("valid" => $count, "invalid" => $errorStore);
    }

    public function importb($csvArray, $mdaCode, $month, $year, $amount, $dateCreated, $createdBy) {
        $db = $this->con;
        $count = 0;
        $start = 0;
        $limit = 1000;
        $stop = false;
        //there representation in the csv array
        $columns = array($mdaCode, $month, $year, $amount, "rafmis_column_1_date_created" => $dateCreated, "rafmis_column_1_created_by" => $createdBy, "rafmis_column_1_date_modified" => null, "rafmis_column_1_modified_by" => null);
        do {
            $result = array_splice($csvArray, $start, $limit);
            if (count($result) < $limit) {
                $stop = true;
            }
            if (count($result) == 0) {
                break;
            }
//            var_dump($result);
//            die();
            $errorStore = array();
            $sql = implode(';', array_map(function($n)use($dateCreated, $createdBy) {
                        $mda = $n["Mda Code"] == '' ? null : $n["Mda Code"];
                        $mth = $n["Payment Period Month"] == '' ? null : $n["Payment Period Month"];
                        $yr = $n["Payment Period Year"] == '' ? null : $n["Payment Period Year"];
                        $am = $n["Target Amount"] == '' ? null : $n["Target Amount"];

                        return "INSERT INTO revenue_target(mda_code,payment_period_month,payment_period_year,target_amount,date_created,created_by,date_modified,modified_by) VALUES ('$mda',$mth,$yr,$am,'$dateCreated', '$createdBy',null,null)";
                    }, $result));
            try {
                $db->beginTransaction();
                $rs = $stmt = $db->exec($sql);
                $db->commit();
                return $rs;
//                $count += intval($stmt->rowCount());
            } catch (PDOException $e) {
                $db->rollback();
//                    throw $e;
//                    $this->app->halt();
                $errorStore[] = $value;
                continue;
            }
        } while (!$stop);
        return array("valid" => $count, "invalid" => $errorStore);
    }

    private function replaceStr($str) {
        return preg_replace("/'+/", "\'", preg_replace('/"+/', '\"', $str));
    }

    /**
     * @param $mdaCode
     *
     * @return array|mixed|RevenueTarget finds a revenue target by its MdaCode
     *
     * finds a revenue target by its MdaCode
     */
    public function findRevenueTargetByMdaCode($mdaCode) {
        $revenueTarget = RevenueTargetQuery::create()->findOneByMdaCode($mdaCode);

        if (!$revenueTarget) {
            throw new EntityNotFoundException('Entity not found.');
        }

        return $revenueTarget;
    }

    /**
     * @param $mdaCode
     *
     * @return mixed
     */
    public function filterCsv($request) {

        $mapped = array_map(function($n) {
            return array($n['name'] => $n['value']);
        }, $request);
        $query = 'SELECT SQL_CACHE SQL_CALC_FOUND_ROWS * FROM revenue_target ';
        $i = 0;
        $criteria = '';
        $columns = array();
        foreach ($mapped as $single) {
            $colName = str_replace('_2', '', array_keys($single)[0]);
            $colName = $colName == 'month' ? 'expected_payment_month' : $colName;
            $colName = $colName == 'year' ? 'expected_payment_year' : $colName;
            if ($i == 0) {
                //prepend WHERE
                if (array_values($single)[0] !== '') {
                    $value = array_values($single)[0];
                    $criteria.=" WHERE $colName='$value'";
                }
            } else {
                // prepend AND
                if (array_values($single)[0] !== '') {
                    $value = array_values($single)[0];
                    $criteria.=" AND $colName='$value'";
                }
            }
            $i++;
        }
        $q = $this->con->prepare("DESCRIBE revenue_target");
        $q->execute();
        $table_fields = $q->fetchAll(\PDO::FETCH_COLUMN);

        $columRefined = array_map(function($e) {
            return implode(' ', array_map(function($n) {
                        return ucwords($n);
                    }, explode('_', $e)));
        }, $table_fields);

        $stmt = $this->con->prepare($query . $criteria);
        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        array_unshift($result, $columRefined);
        return $result;
    }

    public function deleteRevenueTarget($mda_code, $payment_period_month, $payment_period_year) {
        $sql = "DELETE FROM revenue_target WHERE `mda_code`='$mda_code' AND `payment_period_month`='$payment_period_month' AND `payment_period_year` = '$payment_period_year'";
        $stmt = $this->con->prepare($sql);
        $stmt->execute();
    }

    public function findAll($page = 1, $count = 10) {
        $revenueTargetEntities = RevenueTargetQuery::create()->find();

        return $revenueTargetEntities;
    }

    public function renderChart(array $request) {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $where = array();
        if (sizeof($request) > 0) {
            foreach ($request as $k => $v) {
                if ($v !== '') {
                    $k = str_replace('_2', '', $k);
                    $k = $k === 'month' ? 'payment_period_month' : $k;
                    $k = $k === 'year' ? 'payment_period_year' : $k;
                    if (sizeof($where) === 0) {
                        $where[] = " WHERE revenue_target.$k = '$v'";
                    } else {
                        $where[] = " AND revenue_target.$k = '$v'";
                    }
                }
            }
        }
        $whereStr = implode('', $where);
        $statement = "SELECT
  revenue_collection_entity.mda_code,
  SUM(revenue_target.target_amount) AS `total`
FROM revenue_target
JOIN revenue_collection_entity
    ON revenue_collection_entity.mda_code = revenue_target.mda_code
$whereStr
GROUP BY revenue_target.mda_code";
//        var_dump($statement);
//        die();
        $stmt = $this->con->prepare($statement);
        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        return $result;
    }

    /**
     * @param $criteria
     * @return array|mixed|\Propel\Runtime\ActiveRecord\ActiveRecordInterface[]|\Propel\Runtime\Collection\ObjectCollection|\RevenueTarget[]
     */
    public function filter($criteria) {
//        var_dump(RevenueTargetQuery::create()->filterByArray($criteria)->find()->toArray());exit;
        return RevenueTargetQuery::create()->filterByArray($criteria)->find();
    }

    public function monthlyTarget($criteria) {
        $con = Propel::getWriteConnection(RevenueTargetTableMap::DATABASE_NAME);
        $sql = 'SELECT MdaCode, Description, Target, SUM(AmountCollected) AS AmountCollected, SUM(AmountRemitted) AS AmountRemitted, `Month`, `Year`
                FROM (SELECT revenue_collection_entity.mda_code AS MdaCode, revenue_collection_entity.description AS Description, revenue_target.target_amount AS Target, 0 AS AmountCollected, 0 AS AmountRemitted, revenue_target.payment_period_month AS Month, revenue_target.payment_period_year AS Year
                    FROM revenue_collection_entity
                    LEFT JOIN revenue_target ON revenue_collection_entity.mda_code = revenue_target.mda_code
                UNION ALL
                SELECT revenue_head_collection.mda_code AS MdaCode, revenue_collection_entity.description AS Description, 0 AS Target, revenue_head_collection.amount AS AmountCollected, 0 AS AmountRemitted, revenue_head_collection.payment_period_month AS Month, revenue_head_collection.payment_period_year AS Year
                    FROM revenue_collection_entity
                    LEFT JOIN revenue_head_collection ON revenue_collection_entity.mda_code = revenue_head_collection.mda_code
                UNION ALL
                SELECT revenue_head_remittance.mda_code AS MdaCode, revenue_collection_entity.description AS Description, 0 AS Target, 0 AS AmountCollected, revenue_head_remittance.amount AS AmountRemitted, revenue_head_remittance.month AS Month, revenue_head_remittance.year AS Year
                    FROM revenue_collection_entity
                    LEFT JOIN revenue_head_remittance ON revenue_collection_entity.mda_code = revenue_head_remittance.mda_code)
                    performance WHERE year = :year GROUP BY MdaCode, Month ORDER BY Month';
        $stmt = $con->prepare($sql);
        $stmt->execute($criteria);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public function annualTarget($criteria)
    {
        $con = Propel::getWriteConnection(RevenueTargetTableMap::DATABASE_NAME);
        $sql = 'SELECT MdaCode, Description, Target, SUM(AmountCollected) AS AmountCollected, SUM(AmountRemitted) AS AmountRemitted, `Year`
                FROM (SELECT revenue_collection_entity.mda_code AS MdaCode, revenue_collection_entity.description AS Description, revenue_target.target_amount AS Target, 0 AS AmountCollected, 0 AS AmountRemitted, revenue_target.payment_period_year AS Year
                    FROM revenue_collection_entity
                    LEFT JOIN revenue_target ON revenue_collection_entity.mda_code = revenue_target.mda_code
                UNION ALL
                SELECT revenue_head_collection.mda_code AS MdaCode, revenue_collection_entity.description AS Description, 0 AS Target, revenue_head_collection.amount AS AmountCollected, 0 AS AmountRemitted, revenue_head_collection.payment_period_year AS Year
                    FROM revenue_collection_entity
                    LEFT JOIN revenue_head_collection ON revenue_collection_entity.mda_code = revenue_head_collection.mda_code
                UNION ALL
                SELECT revenue_head_remittance.mda_code AS MdaCode, revenue_collection_entity.description AS Description, 0 AS Target, 0 AS AmountCollected, revenue_head_remittance.amount AS AmountRemitted, revenue_head_remittance.year AS Year
                    FROM revenue_collection_entity
                    LEFT JOIN revenue_head_remittance ON revenue_collection_entity.mda_code = revenue_head_remittance.mda_code)
                    performance WHERE year BETWEEN 2014 AND 2015 GROUP BY MdaCode, Year ORDER BY Year';
        $stmt = $con->prepare($sql);
        $stmt->execute($criteria);
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
}
