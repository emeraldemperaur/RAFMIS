<?php
/**

 */

namespace Rafmis\RevenueMonitoringModule\Repository;


use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Exception\EntityNotFoundException;
use RevenueHeadRemittance;
use RevenueHeadRemittanceQuery;
use Slim\Slim;

class RevenueHeadRemittanceRepository {

	/**
	 * @var Slim
	 */
	private $app;

	/**
	 * @var RevenueHeadRemittance
	 */
	private $revenueHeadRemittance;

	/**
	 * @param Slim $app
	 */
	public function __construct(Slim $app)
	{
		$this->app = $app;
		$this->revenueHeadRemittance = new RevenueHeadRemittance();
        $this->revenueHeadRemittanceQuery = RevenueHeadRemittanceQuery::create();

		return $this;
	}

    /**
     * @param array $data
     * @return int The number of affected rows
     */
    public function save(array $data)
    {
		$collection = new ObjectCollection();
		$collection->setModel('RevenueHeadRemittance');
		$collection->fromArray($data);
		$collection->save();
    }

	/**
	 * @param array $data
	 * @return int The number of affected rows
	 */
	public function update(array $data)
	{
        $revenueHeadRemittance = $this->revenueHeadRemittanceQuery->findOneByPrimaryKeys(
			$data['MdaCode'], $data['RevenueHeadId'], $data['Month'], $data['Year']
		)->findOne();

        if ($revenueHeadRemittance) {
            //sets all required properties of the revenue head
            $revenueHeadRemittance->setAmount($data['Amount']);
            $revenueHeadRemittance->setRemittanceDate(new \DateTime($data['RemittanceDate']));

			$revenueHeadRemittance->setDateModified(new \DateTime());
			$revenueHeadRemittance->setModifiedBy($data['username']);
		}

		return $revenueHeadRemittance->save();
	}

    /**
     * @param $revenueHeadId
     * @param $mdaCode
     * @param $month
     * @param $year
     * @return array|mixed|RevenueHeadRemittance finds a revenue head by its revenue_head_id
     *
     * finds a revenue head by its mda_code
     */
	public function findRevenueHeadRemittance($revenueHeadId, $mdaCode, $month, $year)
	{

        $revenueHeadRemittance = $this->revenueHeadRemittanceQuery
            ->findOneByPrimaryKeys($mdaCode, $revenueHeadId, $month, $year)->findOne();

		if (!$revenueHeadRemittance) {
			throw new EntityNotFoundException('Entity Not Mound.');
		}

		return $revenueHeadRemittance;
	}

	/**
	 * @param $mdaCode
	 *
	 * @return array|mixed|RevenueHeadRemittance finds a revenue head by its mda_code
	 *
	 * finds a revenue head by its mda_code
	 */
	public function findByMdaCode($mdaCode)
	{
		$revenueHeadRemittance = RevenueHeadRemittanceQuery::create()->findByMdaCode($mdaCode);

		if (!$revenueHeadRemittance) {
			throw new EntityNotFoundException('No revenue head remittance available for the selected MDA.');
		}

		$revenueHeadRemittanceQuery = $this->findBy('MdaCode', $mdaCode);
		$revenueHeadRemittance = RevenueHeadRemittanceQuery::create()->findOneByMdaCode($mdaCode);

		if (!$revenueHeadRemittance) {
			throw new EntityNotFoundException('No revenue head remittance available for the selected MDA.');
		}

		return $revenueHeadRemittanceQuery;
	}

    /**
     * @param $revenueHeadId
     * @param $mdaCode
     * @param $month
     * @param $year
     * @return mixed
     * @throws \Propel\Runtime\Exception\PropelException
     */
	public function delete($revenueHeadId, $mdaCode, $month, $year)
	{
		/** @var RevenueHeadRemittance $RevenueHeadRemittance */

		$revenueHeadRemittance = $this->findRevenueHeadRemittance($revenueHeadId, $mdaCode, $month, $year);
		$revenueHeadRemittance->delete();
	}

    private function findBy($columnName, $pk)
	{
		$revenueHeadRemittance = RevenueHeadRemittanceQuery::create()->findBy($columnName, $pk);
		return $revenueHeadRemittance;
	}

	public function findAll($page = 1, $count = 10)
	{
		$revenueHeadRemittances = RevenueHeadRemittanceQuery::create()->find();
		return $revenueHeadRemittances;
	}

	public function filter($criteria)
	{
		$statement = $this->revenueHeadRemittanceQuery;
		if (isset($criteria['revenueHead']) && $criteria['revenueHead'] !== 'undefined') {
			$statement->filterBy('RevenueHeadId', $criteria['revenueHead']);
		}

		if (isset($criteria['year']) && $criteria['year'] !== 'undefined') {
			$statement->filterBy('Year', $criteria['year']);
		}

		if (isset($criteria['month']) && $criteria['month'] !== 'undefined') {
			$statement->filterBy('Month', $criteria['month']);
		}

		if (isset($criteria['mdaCode'])) {
			$statement->filterBy('MdaCode', $criteria['mdaCode']);
		}

		return $statement->find();
	}
}
