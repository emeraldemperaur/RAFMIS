<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 5/28/2015
 * Time: 2:33 PM
 */

namespace Rafmis\RevenueMonitoringModule\Repository;

use Propel\Runtime\Propel;
use Propel\Runtime\Exception\EntityNotFoundException;
use Propel\Runtime\Exception\PropelException;
use InhouseRevenueCollection;
use InhouseRevenueCollectionQuery;
use Slim\Slim;

class InhouseRevenueCollectionRepository {

    /**
     * @var Slim
     */
    private $app;

    /**
     * @var InhouseRevenueCollection
     */
    private $inhouseRevenueCollection;

    /**
     * * @var Connectiom	 
     */
    private $con;

    /**
     * @param Slim $app
     */
    public function __construct(Slim $app) {
        $this->con = Propel::getConnection();
        $this->app = $app;
        $this->inhouseRevenueCollection = new InhouseRevenueCollection();
        $this->inhouseRevenueCollectionQuery = InhouseRevenueCollectionQuery::create();

        return $this;
    }

    /**
     * @param array $data
     * @return int The number of affected rows
     */
    public function saveInhouseRevenueCollection(array $data, $mode) {
//        var_dump($data);die();
//        var_dump($inhouseRevenueCollection);
//        die();
        $inhouseRevenueCollection = null;
        //verifies if the data passed in is a managed by propel
        if ($mode == 'create') {
            $inhouseRevenueCollection = $this->inhouseRevenueCollection;
        } else {
            $inhouseRevenueCollection = InhouseRevenueCollectionQuery::create()->filterByInhouseRevenueCollectionId($data['inhouse_revenue_collection_id'])->findOne();
//            $revenueHead = $data['revenue_head_id'];
//            $mdaCode = $data['mda_code'];
//            $month = $data['expected_payment_month'];
//            $year = $data['expected_payment_year'];
//
//            $pks = array(array($revenueHead, $mdaCode, $month, $year));
//            $inhouseRevenueCollection = InhouseRevenueCollectionQuery::create()->filterByPrimaryKeys($pks)->findOne();
        }


        //sets all required properties of the inhouse revenue collection
        $inhouseRevenueCollection->setRevenueHeadId($data['revenue_head_id']);
        $inhouseRevenueCollection->setMdaCode($data['mda_code']);
        $inhouseRevenueCollection->setExpectedPaymentMonth($data['expected_payment_month']);
        $inhouseRevenueCollection->setExpectedPaymentYear($data['expected_payment_year']);
        $inhouseRevenueCollection->setAmount($data['amount']);
        $inhouseRevenueCollection->setState($data['state']);
        $inhouseRevenueCollection->setPayerName($data['payer_name']);
        $inhouseRevenueCollection->setRcNumber($data['rc_number']);
        $inhouseRevenueCollection->setSourceId($mode === 'create' ? 'FORM' : $inhouseRevenueCollection->getSourceId());
        $inhouseRevenueCollection->setTinNumber($data['tin_number']);
        $inhouseRevenueCollection->setPaymentDate($data['payment_date']);
        $inhouseRevenueCollection->setDateCreated(isset($data['date_created']) ? $data['date_created'] : $inhouseRevenueCollection->getDateCreated());
        $inhouseRevenueCollection->setCreatedBy(isset($data['created_by']) ? $data['created_by'] : $inhouseRevenueCollection->getCreatedBy());
        $inhouseRevenueCollection->setDateModified(isset($data['date_modified']) ? $data['date_modified'] : $inhouseRevenueCollection->getDateModified());
        $inhouseRevenueCollection->setModifiedBy(isset($data['modified_by']) ? $data['modified_by'] : $inhouseRevenueCollection->getModifiedBy());

        return $inhouseRevenueCollection->save();
    }

    private function placeholders($text, $count = 0, $separator = ",") {
        $result = array();
        if ($count > 0) {
            for ($x = 0; $x < $count; $x++) {
                $result[] = $text;
            }
        }

        return implode($separator, $result);
    }

    public function import($csvArray, $revneueHeadId, $mdaCode, $month, $year, $amount, $state, $payerName, $rcNumber, $sourceId, $tinNumber, $paymentDate, $dateCreated, $createdBy) {
        $db = $this->con;
        $count = 0;
        $start = 0;
        $limit = 1000;
        $stop = false;
        //there representation in the csv array
        $columns = array($revneueHeadId, $mdaCode, $month, $year, $amount, $state, $payerName, $rcNumber, 'rafmis_column_1_source_id' => $sourceId, $tinNumber, $paymentDate, "rafmis_column_1_date_created" => $dateCreated,
            "rafmis_column_1_created_by" => $createdBy);
        do {
            $result = array_splice($csvArray, $start, $limit);
            if (count($result) < $limit) {
                $stop = true;
            }
            if (count($result) == 0) {
                break;
            }
            $question_marks = array();
            $mergeArray = array();
            $errorStore = array();

            $sql = "INSERT INTO inhouse_revenue_collection (revenue_head_id,mda_code,expected_payment_month,expected_payment_year,amount,state,payer_name,rc_number,source_id,tin_number,payment_date,date_created,created_by) VALUES (" . $this->placeholders('?', sizeof($columns)) . ")";
            foreach ($result as $value) {
                $mergeArray = array();
                // $value is row

                foreach ($columns as $key => $value2) {
                    $value[""] = NULL;
                    if (preg_match("/rafmis_column_1_/", $key)) {
                        $mergeArray[] = $this->replaceStr(trim($value2));
                    } else {
                        $mergeArray[] = $this->replaceStr(trim($value[$value2]));
                    }
                }
                try {
                    $db->beginTransaction();
                    $stmt = $db->prepare($sql);
                    $stmt->execute($mergeArray);
                    $db->commit();
                    $count += intval($stmt->rowCount());
                } catch (PDOException $e) {
                    $db->rollback();
                    throw $e;
//                    $this->app->halt();
                    $errorStore[] = $value;
                    continue;
                }

//          =========================================================
            }
        } while (!$stop);
        return array("valid" => $count, "invalid" => $errorStore);
    }

//
//    public function import($csvArray, $revneueHeadId, $mdaCode, $month, $year, $amount, $state, $payerName, $rcNumber, $sourceId, $tinNumber, $paymentDate, $dateCreated, $createdBy) {
//        $db = $this->con;
//        $count = 0;
//        $start = 0;
//        $limit = 1000;
//        $stop = false;
//        //there representation in the csv array
//        $columns = array("rafmis_column_1_revenue_head_id" => $revneueHeadId, "rafmis_column_1_mda_code" => $mdaCode, $month, $year, $amount, $state, $payerName, $rcNumber, 'rafmis_column_1_source_id' => $sourceId, $tinNumber, $paymentDate, "rafmis_column_1_date_created" => $dateCreated,
//            "rafmis_column_1_created_by" => $createdBy);
//        do {
//            $result = array_splice($csvArray, $start, $limit);
//            if (count($result) < $limit) {
//                $stop = true;
//            }
//            if (count($result) == 0) {
//                break;
//            }
//            $question_marks = array();
//            $mergeArray = array();
//            foreach ($result as $value) {
//                $question_marks[] = '(' . $this->placeholders('?', sizeof($columns)) . ')';
//                foreach ($columns as $key => $value2) {
//                    $value[""] = NULL;
//                    if (preg_match("/rafmis_column_1_/", $key)) {
//                        $mergeArray[] = $this->replaceStr(trim($value2));
//                    } else {
//                        $mergeArray[] = $this->replaceStr(trim($value[$value2]));
//                    }
//                }
//            }
//            $sql = "INSERT INTO inhouse_revenue_collection (revenue_head_id,mda_code,expected_payment_month,expected_payment_year,amount,state,payer_name,rc_number,source_id,tin_number,payment_date,date_created,created_by) VALUES " . implode(',', $question_marks);
//            try {
//                $db->beginTransaction();
//                $stmt = $db->prepare($sql);
//                $stmt->execute($mergeArray);
//                $db->commit();
//                $count += intval($stmt->rowCount());
//            } catch (PDOException $e) {
//                $db->rollback();
//                throw $e;
//            }
//        } while (!$stop);
//        return $count;
//    }

    private function replaceStr($str) {
        return preg_replace("/'+/", "\'", preg_replace('/"+/', '\"', $str));
    }

    /**
     * @param $mdaCode
     *
     * @return array|mixed|InhouseRevenueCollection finds a inhouse revenue collection by its MdaCode
     *
     * finds a inhouse revenue collection by its MdaCode
     */
    public function findInhouseRevenueCollectionByMdaCode($mdaCode) {
        $inhouseRevenueCollection = InhouseRevenueCollectionQuery::create()->findOneByMdaCode($mdaCode);

        if (!$inhouseRevenueCollection) {
            throw new EntityNotFoundException('Entity not found.');
        }

        return $inhouseRevenueCollection;
    }

    public function filterCsv($request) {

        $mapped = array_map(function($n) {
            return array($n['name'] => $n['value']);
        }, $request);
        $query = 'SELECT SQL_CACHE SQL_CALC_FOUND_ROWS * FROM inhouse_revenue_collection ';
        $i = 0;
        $criteria = '';
        $columns = array();
        foreach ($mapped as $single) {
            $colName = str_replace('_2', '', array_keys($single)[0]);
            $colName = $colName == 'month' ? 'expected_payment_month' : $colName;
            $colName = $colName == 'year' ? 'expected_payment_year' : $colName;
            if ($i == 0) {
                //prepend WHERE
                if (array_values($single)[0] !== '') {
                    $value = array_values($single)[0];
                    $criteria.=" WHERE $colName='$value'";
                }
            } else {
                // prepend AND
                if (array_values($single)[0] !== '') {
                    $value = array_values($single)[0];
                    $criteria.=" AND $colName='$value'";
                }
            }
            $i++;
        }
        $q = $this->con->prepare("DESCRIBE inhouse_revenue_collection");
        $q->execute();
        $table_fields = $q->fetchAll(\PDO::FETCH_COLUMN);

        $columRefined = array_map(function($e) {
            return implode(' ', array_map(function($n) {
                        return ucwords($n);
                    }, explode('_', $e)));
        }, $table_fields);

        $stmt = $this->con->prepare($query . $criteria);
        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        array_unshift($result, $columRefined);
        return $result;
    }

    /**
     * @param $mdaCode
     *
     * @return mixed
     */
    public function deleteInhouseRevenueCollection($inhouseRevenueCollectionId) {
        /** @var InhouseRevenueCollection $inhouseRevenueCollection */
        $inhouseRevenueCollection = InhouseRevenueCollectionQuery::create()->filterByInhouseRevenueCollectionId($inhouseRevenueCollectionId)->findOne();

        $inhouseRevenueCollection->delete();
    }

    public function findAll($page = 1, $count = 10) {
        $inhouseRevenueCollectionEntities = InhouseRevenueCollectionQuery::create()->paginate($page, $count);

        return $inhouseRevenueCollectionEntities;
    }

    public function renderChart(array $request) {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $where = array();
        if (sizeof($request) > 0) {
            foreach ($request as $k => $v) {
                if ($v !== '') {
                    $k = str_replace('_2', '', $k);
                    $k = $k === 'month' ? 'expected_payment_month' : $k;
                    $k = $k === 'year' ? 'expected_payment_year' : $k;
                    if (sizeof($where) === 0) {
                        $where[] = " WHERE inhouse_revenue_collection.$k = '$v'";
                    } else {
                        $where[] = " AND inhouse_revenue_collection.$k = '$v'";
                    }
                }
            }
        }
        $whereStr = implode('', $where);
        $statement = "SELECT
  revenue_collection_entity.mda_code,
  SUM(inhouse_revenue_collection.amount) AS `total`
FROM inhouse_revenue_collection
JOIN revenue_collection_entity
    ON revenue_collection_entity.mda_code = inhouse_revenue_collection.mda_code
$whereStr
GROUP BY inhouse_revenue_collection.mda_code";
//        var_dump($statement);
//        die();
        $stmt = $this->con->prepare($statement);
        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        return $result;
    }

}
