<?php
/**

 */

namespace Rafmis\RevenueMonitoringModule\Repository;


use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Exception\EntityNotFoundException;
use Propel\Runtime\Formatter\ObjectFormatter;
use Propel\Runtime\Propel;
use RevenueHeadCollection;
use RevenueHeadCollectionQuery;
use Slim\Slim;

class RevenueHeadCollectionRepository {

	/**
	 * @var Slim
	 */
	private $app;

	/**
	 * @var RevenueHeadCollection
	 */
	private $revenueHeadCollection;

	/**
	 * @param Slim $app
	 */
	public function __construct(Slim $app)
	{
		$this->app = $app;
		$this->revenueHeadCollection = new RevenueHeadCollection();
        $this->revenueHeadCollectionQuery = RevenueHeadCollectionQuery::create();

		return $this;
	}

	/**
	 * @param array $data
	 * @return int The number of affected rows
	 */
	public function save(array $data)
	{
        $collection = new ObjectCollection();
        $collection->setModel('RevenueHeadCollection');
        $collection->fromArray($data);
        $collection->save();
	}

    public function update($data)
    {
        $revenueHeadCollection = $this->revenueHeadCollectionQuery->findOneRevenueHeadCollection(
            $data['RevenueHeadId'], $data['MdaCode'], $data['PaymentPeriodMonth'], $data['PaymentPeriodYear']
        );

        if ($revenueHeadCollection) {
            $revenueHeadCollection->setDateModified(new \DateTime());
            $revenueHeadCollection->setModifiedBy($data['username']);//sets all required properties of the revenue head
            $revenueHeadCollection->setAmount($data['Amount']);

            return $revenueHeadCollection->save();
        }
    }

    /**
     * @param $revenueHeadId
     * @param $mdaCode
     * @param $paymentPeriodMonth
     * @param $paymentPeriodYear
     * @return $this|RevenueHeadCollectionQuery
     */
	public function findOneByPrimaryKeys($revenueHeadId, $mdaCode, $paymentPeriodMonth, $paymentPeriodYear)
	{
		return $this->revenueHeadCollectionQuery->findOneRevenueHeadCollection(
			$revenueHeadId, $mdaCode, $paymentPeriodMonth, $paymentPeriodYear
		);
    }

	/**
	 * @param $mdaCode
	 *
	 * @return array|mixed|RevenueHeadCollection finds a revenue head by its mda_code
	 *
	 * finds a revenue head by its mda_code
	 */
	public function findByMdaCode($mdaCode)
	{

		$revenueHeadCollection = RevenueHeadCollectionQuery::create()->findOneByMdaCode($mdaCode);

		if (!$revenueHeadCollection) {
			throw new EntityNotFoundException('No revenue head collection available for the selected MDA.');
		}

		$revenueHeadCollectionQuery = $this->findBy('MdaCode', $mdaCode);
		$revenueHeadCollection = RevenueHeadCollectionQuery::create()->findOneByMdaCode($mdaCode);

		if (!$revenueHeadCollection) {
			throw new EntityNotFoundException('No revenue head collection available for the selected MDA.');
		}

		return $revenueHeadCollectionQuery;
	}

	public function delete($revenueHeadId, $mdaCode, $paymentPeriodMonth, $paymentPeriodYear)
	{
		/** @var RevenueHeadCollection $RevenueHeadCollection */

		$revenueHeadCollection = $this->revenueHeadCollectionQuery
			->findOneRevenueHeadCollection($revenueHeadId, $mdaCode, $paymentPeriodMonth, $paymentPeriodYear);
		$revenueHeadCollection->delete();
	}

    private function findBy($columnName, $pk)
	{
		$revenueHeadCollection = RevenueHeadCollectionQuery::create()->findBy($columnName, $pk);
		return $revenueHeadCollection;
	}

	public function findAll($page = 1, $count = 10)
	{
		$revenueHeadCollections = RevenueHeadCollectionQuery::create()->find();
		return $revenueHeadCollections;
	}

    public function monthlyRevenueHeadCollection($year)
    {
        return $this->revenueHeadCollectionQuery->withColumn('sum(amount)', 'TotalAmount')
            ->select(array('MdaCode', 'PaymentPeriodMonth'))
            ->filterByPaymentPeriodYear($year)
            ->groupByMdaCode()
            ->groupByPaymentPeriodMonth()
            ->find();
    }

	public function filter($criteria)
	{
		$statement = $this->revenueHeadCollectionQuery;
		if (isset($criteria['revenueHead']) && $criteria['revenueHead'] !== 'undefined') {
			$statement->filterBy('RevenueHead', $criteria['revenueHead']);
		}

		if (isset($criteria['year']) && $criteria['year'] !== 'undefined') {
			$statement->filterBy('PaymentPeriodYear', $criteria['year']);
		}

		if (isset($criteria['month']) && $criteria['month'] !== 'undefined') {
			$statement->filterBy('PaymentPeriodMonth', $criteria['month']);
		}

		if (isset($criteria['mdaCode'])) {
			$statement->filterBy('MdaCode', $criteria['mdaCode']);
		}

		return $statement->find();
	}

	public function sumMonthlyRevenueHeadCollection(array $data) {
		$con = Propel::getWriteConnection(\Map\RevenueHeadCollectionTableMap::DATABASE_NAME);
		$sql = "SELECT SUM('amount') FROM revenue_head_collection WHERE mda_code IN (:mdas) AND payment_period_year = :year GROUP BY payment_period_month";
		$stmt = $con->prepare($sql);
		$stmt->execute($data);
		$formatter = new ObjectFormatter();
		$formatter->setClass('\RevenueHeadCollection');

		return $formatter->format($con->getDataFetcher($stmt));
	}
}
