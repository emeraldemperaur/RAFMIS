<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 5/28/2015
 * Time: 2:33 PM
 */

namespace Rafmis\RevenueMonitoringModule\Repository;

use Propel\Runtime\Exception\EntityNotFoundException;
use Propel\Runtime\Exception\PropelException;
use RevenueCollectionEntity;
use RevenueCollectionEntityQuery;
use Slim\Slim;

class RevenueCollectionEntityRepository {

	/**
	 * @var Slim
	 */
	private $app;

	/**
	 * @var RevenueCollectionEntity
	 */
	private $revenueCollectionEntity;

	/**
	 * @param Slim $app
	 */
	public function __construct(Slim $app)
	{
		$this->app = $app;
		$this->revenueCollectionEntity = new RevenueCollectionEntity();
        $this->revenueCollectionEntityQuery = RevenueCollectionEntityQuery::create();

		return $this;
	}

	/**
	 * @param array $data
	 * @return int The number of affected rows
	 */
	public function saveRevenueCollectionEntity(array $data)
	{
		$revenueCollectionEntity = RevenueCollectionEntityQuery::create()->findOneByMdaCode($data['MdaCode']);

		//verifies if the data passed in is a managed by propel
		if (!$revenueCollectionEntity) {
			$revenueCollectionEntity = $this->revenueCollectionEntity;
			$revenueCollectionEntity->setDateCreated(new \DateTime());
			$revenueCollectionEntity->setCreatedBy($data['CreatedBy']);
		} else {
			$revenueCollectionEntity->setDateModified(new \DateTime());
			$revenueCollectionEntity->setModifiedBy($data['ModifiedBy']);
		}

		//sets all required properties of the revenue collection entity
		$revenueCollectionEntity->setMdaCode($data['MdaCode']);
		$revenueCollectionEntity->setDescription($data['Description']);

		return $revenueCollectionEntity->save();
	}

	/**
	 * @param $mdaCode
	 *
	 * @return array|mixed|RevenueCollectionEntity finds a revenue collection entity by its MdaCode
	 *
	 * finds a revenue collection entity by its MdaCode
	 */
	public function findRevenueCollectionEntityByMdaCode($mdaCode)
	{
		$revenueCollectionEntity = RevenueCollectionEntityQuery::create()->findOneByMdaCode($mdaCode);

		if (!$revenueCollectionEntity) {
			throw new EntityNotFoundException('Entity not found.');
		}

		return $revenueCollectionEntity;
	}

	/**
	 * @param $mdaCode
	 *
	 * @return mixed
	 */
	public function deleteRevenueCollectionEntity($mdaCode)
	{
		/** @var RevenueCollectionEntity $revenueCollectionEntity */
		$revenueCollectionEntity = $this->findRevenueCollectionEntityByMdaCode($mdaCode);

		$revenueCollectionEntity->delete();
	}

	public function findAll($page = 1, $count = 10)
	{
		$revenueCollectionEntities = RevenueCollectionEntityQuery::create()->find();

		return $revenueCollectionEntities;
	}

    public function findAllWithRevenueHead()
    {
        return $this->revenueCollectionEntityQuery->rightJoinRevenueHead()->setDistinct()->find();
    }

	public function filterData($criteria)
	{
		return RevenueCollectionEntityQuery::create()
			->filterByArray($criteria)
			->find();
	}
}
