<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 5/28/2015
 * Time: 2:33 PM
 */

namespace Rafmis\RevenueMonitoringModule\Repository;

use Propel\Runtime\Propel;
use Propel\Runtime\Exception\EntityNotFoundException;
use Propel\Runtime\Exception\PropelException;
use RevenueCollection;
use RevenueCollectionQuery;
use Slim\Slim;

class RevenueCollectionRepository {

    /**
     * @var Slim
     */
    private $app;

    /**
     * @var RevenueCollection
     */
    private $revenueCollection;

    /**
     * * @var Connectiom	 
     */
    private $con;

    /**
     * @param Slim $app
     */
    public function __construct(Slim $app) {
        $this->con = Propel::getConnection();
        $this->app = $app;
        $this->revenueCollection = new RevenueCollection();
        $this->revenueCollectionQuery = RevenueCollectionQuery::create();

        return $this;
    }

    /**
     * @param array $data
     * @return int The number of affected rows
     */
    public function saveRevenueCollection(array $data, $mode) {
//        var_dump($data);die();
//        var_dump($revenueCollection);
//        die();
        $revenueCollection = null;
        //verifies if the data passed in is a managed by propel
        if ($mode == 'create') {
            $revenueCollection = $this->revenueCollection;
        } else {

            $revenueCollection = RevenueCollectionQuery::create()->filterByRevenueCollectionId($data['revenue_collection_id'])->findOne();

//            $revenueHead = $data['revenue_head_id'];
//            $mdaCode = $data['mda_code'];
//            $month = $data['expected_payment_month'];
//            $year = $data['expected_payment_year'];
//
//            $pks = array(array($revenueHead, $mdaCode, $month, $year));
//            $revenueCollection = RevenueCollectionQuery::create()->filterByPrimaryKeys($pks)->findOne();
        }


        //sets all required properties of the revenue collection
        $revenueCollection->setRevenueHeadId($data['revenue_collection_id']);
        $revenueCollection->setRevenueHeadId($data['revenue_head_id']);
        $revenueCollection->setMdaCode($data['mda_code']);
        $revenueCollection->setExpectedPaymentMonth($data['expected_payment_month']);
        $revenueCollection->setExpectedPaymentYear($data['expected_payment_year']);
        $revenueCollection->setAmount($data['amount']);
        $revenueCollection->setState($data['state']);
        $revenueCollection->setPayerName($data['payer_name']);
        $revenueCollection->setRcNumber($data['rc_number']);
        $revenueCollection->setSourceId($mode === 'create' ? 'FORM' : $revenueCollection->getSourceId());
        $revenueCollection->setTinNumber($data['tin_number']);
        $revenueCollection->setPaymentDate($data['payment_date']);
        $revenueCollection->setDateCreated(isset($data['date_created']) ? $data['date_created'] : $revenueCollection->getDateCreated());
        $revenueCollection->setCreatedBy(isset($data['created_by']) ? $data['created_by'] : $revenueCollection->getCreatedBy());
        $revenueCollection->setDateModified(isset($data['date_modified']) ? $data['date_modified'] : $revenueCollection->getDateModified());
        $revenueCollection->setModifiedBy(isset($data['modified_by']) ? $data['modified_by'] : $revenueCollection->getModifiedBy());

        return $revenueCollection->save();
    }

    private function placeholders($text, $count = 0, $separator = ",") {
        $result = array();
        if ($count > 0) {
            for ($x = 0; $x < $count; $x++) {
                $result[] = $text;
            }
        }

        return implode($separator, $result);
    }

    public function import($csvArray, $revneueHeadId, $mdaCode, $month, $year, $amount, $state, $payerName, $rcNumber, $sourceId, $tinNumber, $paymentDate, $dateCreated, $createdBy) {
        $db = $this->con;
        $count = 0;
        $start = 0;
        $limit = 1000;
        $stop = false;
        //there representation in the csv array
        $columns = array($revneueHeadId, $mdaCode, $month, $year, $amount, $state, $payerName, $rcNumber, 'rafmis_column_1_source_id' => $sourceId, $tinNumber, $paymentDate, "rafmis_column_1_date_created" => $dateCreated,
            "rafmis_column_1_created_by" => $createdBy);
        do {
            $result = array_splice($csvArray, $start, $limit);
            if (count($result) < $limit) {
                $stop = true;
            }
            if (count($result) == 0) {
                break;
            }
            $question_marks = array();
            $mergeArray = array();
            $errorStore = array();

            $sql = "INSERT INTO revenue_collection (revenue_head_id,mda_code,expected_payment_month,expected_payment_year,amount,state,payer_name,rc_number,source_id,tin_number,payment_date,date_created,created_by) VALUES (" . $this->placeholders('?', sizeof($columns)) . ")";
            foreach ($result as $value) {
                $mergeArray = array();
                // $value is row

                foreach ($columns as $key => $value2) {
                    $value[""] = NULL;
                    if (preg_match("/rafmis_column_1_/", $key)) {
                        $mergeArray[] = $this->replaceStr(trim($value2));
                    } else {
                        $mergeArray[] = $this->replaceStr(trim($value[$value2]));
                    }
                }
                try {
                    $db->beginTransaction();
                    $stmt = $db->prepare($sql);
                    $stmt->execute($mergeArray);
                    $db->commit();
                    $count += intval($stmt->rowCount());
                } catch (PDOException $e) {
                    $db->rollback();
                    throw $e;
//                    $this->app->halt();
                    $errorStore[] = $value;
                    continue;
                }

//          =========================================================
            }
        } while (!$stop);
        return array("valid" => $count, "invalid" => $errorStore);
    }

    private function replaceStr($str) {
        return preg_replace("/'+/", "\'", preg_replace('/"+/', '\"', $str));
    }

    /**
     * @param $mdaCode
     *
     * @return array|mixed|RevenueCollection finds a revenue collection by its MdaCode
     *
     * finds a revenue collection by its MdaCode
     */
    public function findRevenueCollectionByMdaCode($mdaCode) {
        $revenueCollection = RevenueCollectionQuery::create()->findOneByMdaCode($mdaCode);

        if (!$revenueCollection) {
            throw new EntityNotFoundException('Entity not found.');
        }

        return $revenueCollection;
    }

    /**
     * @param $mdaCode
     *
     * @return mixed
     */
    public function filterCsv($request) {

        $mapped = array_map(function($n) {
            return array($n['name'] => $n['value']);
        }, $request);
        $query = 'SELECT SQL_CACHE SQL_CALC_FOUND_ROWS * FROM revenue_collection ';
        $i = 0;
        $criteria = '';
        $columns = array();
        foreach ($mapped as $single) {
            $colName = str_replace('_2', '', array_keys($single)[0]);
            $colName = $colName == 'month' ? 'expected_payment_month' : $colName;
            $colName = $colName == 'year' ? 'expected_payment_year' : $colName;
            if ($i == 0) {
                //prepend WHERE
                if (array_values($single)[0] !== '') {
                    $value = array_values($single)[0];
                    $criteria.=" WHERE $colName='$value'";
                }
            } else {
                // prepend AND
                if (array_values($single)[0] !== '') {
                    $value = array_values($single)[0];
                    $criteria.=" AND $colName='$value'";
                }
            }
            $i++;
        }
        $q = $this->con->prepare("DESCRIBE revenue_collection");
        $q->execute();
        $table_fields = $q->fetchAll(\PDO::FETCH_COLUMN);

        $columRefined = array_map(function($e) {
            return implode(' ', array_map(function($n) {
                        return ucwords($n);
                    }, explode('_', $e)));
        }, $table_fields);

        $stmt = $this->con->prepare($query . $criteria);
        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        array_unshift($result, $columRefined);
        return $result;
    }

    public function deleteRevenueCollection($revenueCollectionId) {
        /** @var RevenueCollection $revenueCollection */
//        $revenueHead = $revenueHeadId;
//        $mdaCode = $mdaCode;
//        $month = $month;
//        $year = $year;
//        $pks = array(array($revenueHead, $mdaCode, $month, $year));
        $revenueCollection = RevenueCollectionQuery::create()->filterByRevenueCollectionId($revenueCollectionId)->findOne();

        $revenueCollection->delete();
    }

    public function findAll($page = 1, $count = 10) {
        $revenueCollectionEntities = RevenueCollectionQuery::create()->find();

        return $revenueCollectionEntities;
    }

    public function renderChart(array $request) {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $where = array();
        if (sizeof($request) > 0) {
            foreach ($request as $k => $v) {
                if ($v !== '') {
                    $k = str_replace('_2', '', $k);
                    $k = $k === 'month' ? 'expected_payment_month' : $k;
                    $k = $k === 'year' ? 'expected_payment_year' : $k;
                    if (sizeof($where) === 0) {
                        $where[] = " WHERE revenue_collection.$k = '$v'";
                    } else {
                        $where[] = " AND revenue_collection.$k = '$v'";
                    }
                }
            }
        }
        $whereStr = implode('', $where);
        $statement = "SELECT
  revenue_collection_entity.mda_code,
  SUM(revenue_collection.amount) AS `total`
FROM revenue_collection
JOIN revenue_collection_entity
    ON revenue_collection_entity.mda_code = revenue_collection.mda_code
$whereStr
GROUP BY revenue_collection.mda_code";
//        var_dump($statement);
//        die();
        $stmt = $this->con->prepare($statement);
        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        return $result;
    }

}
