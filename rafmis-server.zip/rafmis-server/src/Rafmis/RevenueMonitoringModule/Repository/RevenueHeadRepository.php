<?php

/**

 */

namespace Rafmis\RevenueMonitoringModule\Repository;

use Propel\Runtime\Exception\EntityNotFoundException;
use Propel\Runtime\Propel;
use RevenueHead;
use RevenueHeadQuery;
use Slim\Slim;

class RevenueHeadRepository {

    /**
     * @var Slim
     */
    private $app;

    /**
     * @var RevenueHead
     */
    private $revenueHead;

    /**
     * * @var Connectiom	 
     */
    private $con;

    /**
     * @param Slim $app
     */
    public function __construct(Slim $app) {
        $this->con = Propel::getConnection();
        $this->app = $app;
        $this->revenueHead = new RevenueHead();

        return $this;
    }

    /**
     * @param array $data
     * @return int The number of affected rows
     */
    public function save($data, $mode) {
        $revenueHead = RevenueHeadQuery::create()->findOneByRevenueHeadId($data['RevenueHeadId']);

        //verifies if the data passed in is a managed by propel
        if (!$revenueHead) {
            $revenueHead = $this->revenueHead;
            $revenueHead->setDateCreated(new \DateTime());
            $revenueHead->setCreatedBy($data['CreatedBy']);
        } else {
            $revenueHead->setDateModified(new \DateTime());
            $revenueHead->setModifiedBy($data['modified_by']);
        }

        //sets all required properties of the revenue head
        $revenueHead->setRevenueHeadId($data['RevenueHeadId']);
        $revenueHead->setMdaCode($data['MdaCode']);
        $revenueHead->setDescription($data['Description']);

        return $revenueHead->save();
    }

    /**
     * @param $id
     *
     * @return array|mixed|RevenueHead finds a revenue head by its revenue_head_id
     *
     * finds a revenue head by its MdaCode
     */
    public function findRevenueHeadId($id) {

        $revenueHead = RevenueHeadQuery::create()->findOneByRevenueHeadId($id);

        if (!$revenueHead) {
            throw new EntityNotFoundException('Entity not found.');
        }

        return $revenueHead;
    }

    /**
     * @param $mdaCode
     *
     * @return array|mixed|RevenueHead finds a revenue head by its MdaCode
     *
     * finds a revenue head by its MdaCode
     */
    public function findByMdaCode($mdaCode) {

//        $stmt = $this->con->prepare('SELECT * FROM revenue_head WHERE mda_code = ?');
//        $stmt->bindValue(1, $mdaCode);
//        $stmt->execute();
//        $revenueHeads = $stmt->fetchAll(\PDO::FETCH_ASSOC);
//
//        return array("RevenueHeads" => $revenueHeads);

        $revenueHeads = RevenueHeadQuery::create()
            ->filterByMdaCode($mdaCode)
            ->setFormatter('\Propel\Runtime\Formatter\ArrayFormatter')
            ->find();

        return $revenueHeads;
    }

//
//    /**
//     * @param $mdaCode
//     *
//     * @return array|mixed|RevenueHead finds a revenue head by its MdaCode
//     *
//     * finds a revenue head by its MdaCode
//     */
//    public function findByMdaCode($mdaCode) {
//
//        $revenueHead = RevenueHeadQuery::create()->filterByMdaCode($mdaCode)->find();
//
//        if (!$revenueHead) {
//            throw new EntityNotFoundException('Entity not found.');
//        }
//
//        return $revenueHead;
//    }

    /**
     * @param $id
     *
     * @return mixed
     */
    public function delete($id) {
        /** @var RevenueHead $RevenueHead */
        $revenueHead = $this->findBy('RevenueHeadId', $id);
        $revenueHead->delete();
    }

    private function findBy($columnName, $pk) {
        $revenueHead = RevenueHeadQuery::create()
                ->setFormatter('\Propel\Runtime\Formatter\ArrayFormatter')
                ->findBy($columnName, $pk);
        return $revenueHead;
    }

    public function findAll($page = 1, $count = 10) {
        $revenueHeads = RevenueHeadQuery::create()
                ->setFormatter('\Propel\Runtime\Formatter\ArrayFormatter')
                ->find();

        return $revenueHeads;
    }

    public function filterData($criteria)
    {
        return RevenueHeadQuery::create()
            ->filterByArray($criteria)
            ->setFormatter('\Propel\Runtime\Formatter\ArrayFormatter')
            ->find();
    }

}
