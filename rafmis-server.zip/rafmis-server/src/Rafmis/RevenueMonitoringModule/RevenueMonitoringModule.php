<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 5/28/2015
 * Time: 10:46 PM
 */

namespace Rafmis\RevenueMonitoringModule;

use Common\ServiceProviderInterface;
use Rafmis\RevenueMonitoringModule\Repository\RevenueCollectionEntityRepository;
use Rafmis\RevenueMonitoringModule\Repository\RevenueCollectionRepository;
use Rafmis\RevenueMonitoringModule\Repository\RevenueTargetRepository;
use Rafmis\RevenueMonitoringModule\Repository\RevenueHeadRepository;
use Rafmis\RevenueMonitoringModule\Repository\RevenueHeadCollectionRepository;
use Rafmis\RevenueMonitoringModule\Repository\RevenueHeadRemittanceRepository;
use Rafmis\RevenueMonitoringModule\Repository\InhouseRevenueCollectionRepository;
use Slim\Slim;

class RevenueMonitoringModule {

    public function register($app) {
        //adds RevenueCollectionEntityRepository to Slim container
        $app->container->singleton('revenue_collection_entity_repository', function () use ($app) {
            return new RevenueCollectionEntityRepository($app);
        });

        //adds RevenueCollectionRepository to Slim container
        $app->container->singleton('revenue_collection_repository', function () use ($app) {
            return new RevenueCollectionRepository($app);
        });

        //adds RevenueHeadRepository to Slim container
        $app->container->singleton('revenue_head_repository', function () use ($app) {
            return new RevenueHeadRepository($app);
        });

        //adds RevenueHeadCollectionRepository to Slim container
        $app->container->singleton('revenue_head_collection_repository', function () use ($app) {
            return new RevenueHeadCollectionRepository($app);
        });

        //adds RevenueHeadRemittanceRepository to Slim container
        $app->container->singleton('revenue_head_remittance_repository', function () use ($app) {
            return new RevenueHeadRemittanceRepository($app);
        });

        //adds InhouseRevenueCollectionRepository to Slim container
        $app->container->singleton('inhouse_revenue_collection_repository', function () use ($app) {
            return new InhouseRevenueCollectionRepository($app);
        });

        //adds RevenueCollectionRepository to Slim container
        $app->container->singleton('revenue_collection_repository', function () use ($app) {
            return new RevenueCollectionRepository($app);
        });

        //adds RevenueTargetRepository to Slim container
        $app->container->singleton('revenue_target_repository', function () use ($app) {
            return new RevenueTargetRepository($app);
        });
    }

}
