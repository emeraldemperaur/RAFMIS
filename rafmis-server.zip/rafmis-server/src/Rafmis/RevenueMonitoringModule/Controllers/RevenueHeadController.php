<?php

/**

 */

namespace Rafmis\RevenueMonitoringModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\RevenueMonitoringModule\Repository\RevenueHeadRepository;

class RevenueHeadController extends BaseController {

    const REPOSITORY_NAME = 'revenue_head_repository';

    public function all() {
        $request = $this->app->request->get();

        if (count($request)) {
            $columns = array(
                'revenue_head_id',
                'description',
                'mda_code',
            );
            $revenueHeads = $this->tableData->get('revenue_head', 'revenue_head_id', $columns);
        } else {
            /** @var RevenueHeadRepository $RevenueHeadRepository */
            $revenueHeadRepository = $this->getRepository(self::REPOSITORY_NAME);
            $revenueHeads = $revenueHeadRepository->findAll();
        }

        if (!count($revenueHeads)) {
            echo 'No revenue head has been added';
        } else if (count($request)) {
            echo json_encode($revenueHeads);
        }else {
            $this->app->response->header('content-type', 'application/json');
            echo $revenueHeads->toJSON();
        }
    }

    public function create() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['CreatedBy'] = $this->getCurrentUser();

        /** @var RevenueHeadRepository $RevenueHeadRepository */
        $revenueHeadRepository = $this->getRepository(self::REPOSITORY_NAME);
        $revenueHeadRepository->save($request, 'create');

        echo 'Revenue head has successfully been created';
    }

    public function show($id) {
        /** @var RevenueHeadRepository $revenueHeadRepository */
        $revenueHeadRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueHead = $revenueHeadRepository->findRevenueHeadId($id);
            echo $revenueHead->toJSON();
        } catch (EntityNotFoundException $e) {

            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function showMda($mdaCode) {
        /** @var RevenueHeadRepository $revenueHeadRepository */
        $revenueHeadRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueHead = $revenueHeadRepository->findByMdaCode($mdaCode);
//            echo json_encode($revenueHead);
            echo $revenueHead->toJSON();
        } catch (EntityNotFoundException $e) {

            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function update() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['date_modified'] = date('Y-m-d H:i:s');
        $request['modified_by'] = $this->getCurrentUser();

        /** @var RevenueHeadRepository $RevenueHeadRepository */
        $revenueHeadRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueHeadRepository->save($request, 'update');
            echo 'Revenue head was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($id) {
        $revenueHeadRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueHeadRepository->delete($id);
            echo 'Revenue head was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function exportData()
    {
        $request = $this->app->request->get();

        /** @var RevenueHeadRepository $revenueHeadRepository */
        $revenueHeadRepository = $this->getRepository(self::REPOSITORY_NAME);
        $revenueHeads = $revenueHeadRepository->filterData($request);

        echo $revenueHeads->toJSON();
    }
}
