<?php
/**

 */

namespace Rafmis\RevenueMonitoringModule\Controllers;


use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\RevenueMonitoringModule\Repository\RevenueHeadCollectionRepository;

class RevenueHeadCollectionController extends BaseController {

	const REPOSITORY_NAME = 'revenue_head_collection_repository';

	public function all()
	{
		$request = $this->app->request->get();

		if (count($request)) {
			$columns = array(
				'mda_code',
				'revenue_head_id',
				'payment_period_month',
				'payment_period_year',
				'amount'
			);
			$revenueHeadCollections = $this->tableData->get('revenue_head_collection', 'revenue_head_id', $columns);
		} else {
			/** @var RevenueHeadCollectionRepository $RevenueHeadCollectionRepository */
			$revenueHeadCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);
			$revenueHeadCollections = $revenueHeadCollectionRepository->findAll();
		}

		if (!count($revenueHeadCollections)) {
			echo 'No Revenue head collection has been added';
		} else if (count($request)) {
			echo json_encode($revenueHeadCollections);
		} else {
			$this->app->response->header('content-type', 'application/json');
            echo $revenueHeadCollections->toJSON();
		}
	}

	public function create()
	{
		$request = json_decode($this->app->request->getBody(), true);
        array_map(function ($item) {
            $item['CreatedBy'] = $this->getCurrentUser();
        }, $request);

		/** @var RevenueHeadCollectionRepository $revenueHeadCollectionRepository */
		$revenueHeadCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);
		$revenueHeadCollectionRepository->save($request);

		echo 'Revenue head collection has successfully been created';
	}

	public function show($revenueHeadId, $mdaCode, $paymentPeriodMonth, $paymentPeriodYear)
	{
		/** @var RevenueHeadCollectionRepository $RevenueHeadCollectionRepository */
		$revenueHeadCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {
			$revenueHeadCollection = $revenueHeadCollectionRepository->findOneByPrimaryKeys(
				$revenueHeadId, $mdaCode, $paymentPeriodMonth, $paymentPeriodYear);
			echo $revenueHeadCollection->toJSON();

		} catch (EntityNotFoundException $e) {

			$this->app->response->setStatus(404);
			$this->createNotFoundException($e->getMessage());

		}
	}

    public function showMda($mdaCode)
	{
		/** @var RevenueHeadCollectionRepository $revenueHeadCollectionRepository */
		$revenueHeadCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {

			$revenueHeadCollection = $revenueHeadCollectionRepository->findByMdaCode($mdaCode);
			echo $revenueHeadCollection->toJSON();

		} catch (EntityNotFoundException $e) {

			$this->app->response->setStatus(404);
            $this->app->response->setBody($e->getMessage());
		}
	}

	public function update()
	{
		$request = json_decode($this->app->request->getBody(), true);

		/** @var RevenueHeadCollectionRepository $RevenueHeadCollectionRepository */
		$revenueHeadCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {
            $request['username'] = $this->getCurrentUser();
			$revenueHeadCollectionRepository->update($request);
			echo 'Revenue head collection was successfully updated';
		} catch (EntityNotFoundException $e) {
			$this->createNotFoundException();
		}
	}

	public function delete($revenueHeadId, $mdaCode, $paymentPeriodMonth, $paymentPeriodYear)
	{
		/** @var RevenueHeadCollectionRepository $revenueHeadCollectionRepository */
		$revenueHeadCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {
			$revenueHeadCollectionRepository->delete($revenueHeadId, $mdaCode, $paymentPeriodMonth, $paymentPeriodYear);
			echo 'Revenue head collection was successfully deleted';
		} catch (EntityNotFoundException $e) {
			$this->app->response->setStatus(404);
			$this->createNotFoundException($e->getMessage());
		}
	}

    public function monthlyRevenueHeadCollection($year)
    {
        /** @var RevenueHeadCollectionRepository $revenueHeadCollectionRepository */
        $revenueHeadCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);
        $revenueHeadCollection = $revenueHeadCollectionRepository->monthlyRevenueHeadCollection($year);

        echo $revenueHeadCollection->toJSON();
    }

	public function searchRevenueHeadCollection()
	{
		$criteria = $this->app->request->get();

		/** @var RevenueHeadCollectionRepository $revenueHeadCollectionRepository */
		$revenueHeadCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);
		$revenueHeadCollection = $revenueHeadCollectionRepository->filter($criteria);

		echo $revenueHeadCollection->toJSON();
	}

	public function getMonthlyRevenueCollected()
	{
		$criteria = $this->app->request->get();

		/** @var RevenueHeadCollectionRepository $revenueHeadCollectionRepository */
		$revenueHeadCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);
		$revenueHeadCollections = $revenueHeadCollectionRepository->sumMonthlyRevenueHeadCollection($criteria);

		echo $revenueHeadCollections->toJSON();
	}

	public function exportData()
	{
		$request = $this->app->request->get();

		/** @var RevenueHeadCollectionRepository $revenueHeadCollectionRepository */
		$revenueHeadCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);
		$revenueHeadCollections = $revenueHeadCollectionRepository->filter($request);

		echo $revenueHeadCollections->toJSON();
	}
}
