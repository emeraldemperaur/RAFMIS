<?php
/**

 */

namespace Rafmis\RevenueMonitoringModule\Controllers;


use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\RevenueMonitoringModule\Repository\RevenueCollectionEntityRepository;
use Rafmis\RevenueMonitoringModule\Repository\RevenueHeadRemittanceRepository;

class RevenueHeadRemittanceController extends BaseController {

	const REPOSITORY_NAME = 'revenue_head_remittance_repository';

	public function all()
	{
		$request = $this->app->request->get();

		if (count($request)) {
			$columns = array(
				'mda_code',
				'revenue_head_id',
				'month',
				'year',
				'remittance_date',
				'amount'
			);
			$revenueHeadRemittance = $this->tableData->get('revenue_head_remittance', 'revenue_head_id', $columns);
		} else {
			/** @var RevenueHeadRemittanceRepository $RevenueHeadRemittanceRepository */
			$revenueHeadRemittanceRepository = $this->getRepository(self::REPOSITORY_NAME);
			$revenueHeadRemittance = $revenueHeadRemittanceRepository->findAll();
		}

		if (!count($revenueHeadRemittance)) {
			echo 'No Revenue head Remittance has been added';
		} else if (count($request)) {
			echo json_encode($revenueHeadRemittance);
		} else {
			$this->app->response->header('content-type', 'application/json');
            echo $revenueHeadRemittance->toJSON();
		}
	}

	public function create()
	{
		$request = json_decode($this->app->request->getBody(), true);

		array_map(function ($item) {
            $item['created_by'] = $this->getCurrentUser();
        }, $request);

		/** @var RevenueHeadRemittanceRepository $revenueHeadRemittanceRepository */
		$revenueHeadRemittanceRepository = $this->getRepository(self::REPOSITORY_NAME);
		$revenueHeadRemittanceRepository->save($request);

		echo 'Revenue head Remittance has successfully been created';
	}

	public function show($revenueHeadId, $mdaCode, $month, $year)
	{
		/** @var RevenueHeadRemittanceRepository $revenueHeadRemittanceRepository */
		$revenueHeadRemittanceRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {
			$revenueHeadRemittance = $revenueHeadRemittanceRepository
                ->findRevenueHeadRemittance($revenueHeadId, $mdaCode, $month, $year);

			echo $revenueHeadRemittance->toJSON();
		} catch (EntityNotFoundException $e) {

			$this->app->response->setStatus(404);
			$this->createNotFoundException($e->getMessage());

		}
	}

    public function showMda($mdaCode)
	{
		/** @var RevenueHeadRemittanceRepository $revenueHeadRemittanceRepository */
		$revenueHeadRemittanceRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {

			$revenueHeadRemittance = $revenueHeadRemittanceRepository->findByMdaCode($mdaCode);
			echo $revenueHeadRemittance->toJSON();

		} catch (EntityNotFoundException $e) {

			$this->app->response->setStatus(404);
            $this->app->response->setBody($e->getMessage());
		}
	}

	public function update()
	{
		$request = json_decode($this->app->request->getBody(), true);
        $request['username'] = $this->getCurrentUser();

		/** @var RevenueHeadRemittanceRepository $revenueHeadRemittanceRepository */
		$revenueHeadRemittanceRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {
			$revenueHeadRemittanceRepository->update($request);
			echo 'Revenue head Remittance was successfully updated';
		} catch (EntityNotFoundException $e) {
			$this->createNotFoundException();
		}
	}

	public function delete($revenueHeadId, $mdaCode, $month, $year)
	{
        /** @var RevenueHeadRemittanceRepository $revenueHeadRemittanceRepository */
		$revenueHeadRemittanceRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {
			$revenueHeadRemittanceRepository->delete($revenueHeadId, $mdaCode, $month, $year);
			echo 'Revenue head Remittance was successfully deleted';
		} catch (EntityNotFoundException $e) {
			$this->app->response->setStatus(404);
			$this->createNotFoundException($e->getMessage());
		}
	}

	public function searchRevenueHeadRemittance()
	{
		$criteria = $this->app->request->get();

		/** @var RevenueHeadRemittanceRepository $revenueHeadRemittanceRepository */
		$revenueHeadRemittanceRepository = $this->getRepository(self::REPOSITORY_NAME);
		$revenueHeadRemittance = $revenueHeadRemittanceRepository->filter($criteria);

		echo $revenueHeadRemittance->toJSON();
	}

	public function exportData()
	{
		$request = $this->app->request->get();

		/** @var RevenueHeadRemittanceRepository $revenueHeadRemittanceRepository */
		$revenueHeadRemittanceRepository = $this->getRepository(self::REPOSITORY_NAME);
		$revenueHeadRemittance = $revenueHeadRemittanceRepository->filter($request);

		echo $revenueHeadRemittance->toJSON();
	}
}
