<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 5/28/2015
 * Time: 2:00 PM
 */
//var_dump(dirname(dirname(dirname(dirname(dirname(__FILE__))))));die();

namespace Rafmis\RevenueMonitoringModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\RevenueMonitoringModule\Repository\InhouseRevenueCollectionRepository;

class InhouseRevenueCollectionController extends BaseController {

    const REPOSITORY_NAME = 'inhouse_revenue_collection_repository';

    public function all($page = 1, $count = 10) {
        /** @var InhouseRevenueCollectionRepository $inhouseRevenueCollectionRepository */
        $inhouseRevenueCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);
        $inhouseRevenueCollections = $inhouseRevenueCollectionRepository->findAll();

        if (!$inhouseRevenueCollections->count()) {
            echo 'No inhouse revenue collection has been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
            echo $inhouseRevenueCollections->toJSON();
        }
    }

    public function create() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['date_created'] = date('Y-m-d H:i:s');
        $request['created_by'] = $this->getCurrentUser();

        /** @var InhouseRevenueCollectionRepository $inhouseRevenueCollectionRepository */
        $inhouseRevenueCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);
        $inhouseRevenueCollectionRepository->saveInhouseRevenueCollection($request, 'create');

        echo 'Inhouse revenue collection has successfully been created';
    }

    public function filterCsv() {
        $request = json_decode($this->app->request->getBody(), true);
        $revenueCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);
        $input_array = $revenueCollectionRepository->filterCsv($request);
        $this->create_csv($input_array, 'a.csv', ',');
    }

    function create_csv($input_array, $output_file_name, $delimiter) {
        /** open raw memory as file, no need for temp files, be careful not to run out of memory thought */
        $f = fopen('php://memory', 'w');
        /** loop through array  */
        foreach ($input_array as $line) {
            /** default php csv handler * */
            fputcsv($f, $line, $delimiter);
        }
        /** rewrind the "file" with the csv lines * */
        fseek($f, 0);
        /** modify header to be downloadable csv file * */
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
//        header("Content-Type: $type");
        header("Content-Transfer-Encoding: binary");
        header('Content-Type: application/csv');
        header('Content-Disposition: attachement; filename="' . $output_file_name . '";');
        /** Send file to browser for download */
        fpassthru($f);
    }

    public static function convertExcelToCSV() {
        $files = $_FILES;
        //is this an ajax request or sent via iframe(IE9 and below)?
        $ajax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest';
        $excel_readers = array(
            'Excel5',
            'Excel2003XML',
            'Excel2007'
        );

        require_once (dirname(dirname(dirname(dirname(__FILE__))))) . DIRECTORY_SEPARATOR . 'Common/Utilities/PHPExcel/PHPExcel.php';
//        require_once ('client/assets/plugins/PHPExcel/PHPExcel.php');
        $dir = dirname(str_replace("\t", "/t", $files["webmasterfile"]["tmp_name"]));
        if (preg_match("/.xlsx$/", $files["webmasterfile"]["name"])) {
            $reader = PHPExcel_IOFactory::createReader('Excel2007');
            $path = $dir . "/" . time() . rand() . "document.xslx";
        } else if (preg_match("/.xls$/", $files["webmasterfile"]["name"])) {
            $reader = PHPExcel_IOFactory::createReader('Excel5');
            $path = $dir . "/" . time() . rand() . "document.xsl";
        } else {
            $error = true;
        }


        if ($error) {
            $response = json_encode(array("status" => "0", "data" => "Bad File"));
        } else {
            rename($_FILES["webmasterfile"]["tmp_name"], $path);

            $reader->setReadDataOnly(true);
            $excel = $reader->load($path);

            $writer = PHPExcel_IOFactory::createWriter($excel, 'CSV');
            ob_start();
            $writer->save('php://output');
            $result = ob_get_clean();
            ob_end_clean();
            $response = json_encode(array("status" => "1", "data" => $result));
        }
        if ($ajax) {
            //if request was ajax(modern browser), just echo it back
            echo $response;
        } else {
            //if request was from an older browser not supporting ajax upload
            //then we have used an iframe instead and the response is sent back to the iframe as a script
            //if request was from an older browser not supporting ajax upload
            //then we have used an iframe instead and the response is sent back to the iframe as a script
            echo '<script language="javascript" type="text/javascript">';
            echo 'window.top.window.jQuery("#' . $_POST['temporary-iframe-id'] . '").data("deferrer").resolve(' . $response . ');';
            echo '</script>';
        }
        unlink($path);
    }

    public function importrecords() {
        $request = json_decode($this->app->request->getBody(), true);
        $inhouseRevenueCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);

        //convert csv data into two multidimensionl array
        $lines = explode("\n", urldecode($request['data']));
        $head = str_getcsv(array_shift($lines));

        $array = array();
        foreach ($lines as $line) {
            $array[] = array_combine($head, str_getcsv($line));
        }
        $postValues = $request;
        $inhouseRevenueCollectionRepository->import(
                $array, $postValues['revenue_head_id'], $postValues['mda_code'], $postValues['expected_payment_month'], $postValues['expected_payment_year'], $postValues['amount'], $postValues['state'], $postValues['payer_name'], $postValues['rc_number'], 'CSV', $postValues['tin_number'], $postValues['payment_date'], date("Y-m-d H:i:s"), $this->getCurrentUser());
    }

    public function show($mdaCode) {
        /** @var InhouseRevenueCollectionRepository $inhouseRevenueCollectionRepository */
        $inhouseRevenueCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $inhouseRevenueCollection = $inhouseRevenueCollectionRepository->findInhouseRevenueCollectionByMdaCode
                    ($mdaCode);
            echo $inhouseRevenueCollection->exportTo('JSON');
        } catch (EntityNotFoundException $e) {

            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function update() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['date_modified'] = date('Y-m-d H:i:s');
        $request['modified_by'] = $this->getCurrentUser();

//        var_dump($request);die();
        /** @var InhouseRevenueCollectionRepository $inhouseRevenueCollectionRepository */
        $inhouseRevenueCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $inhouseRevenueCollectionRepository->saveInhouseRevenueCollection($request, 'update');
            echo 'Inhouse revenue collection was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($inhouseRevenueCollectionId) {
        $inhouseRevenueCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $inhouseRevenueCollectionRepository->deleteInhouseRevenueCollection($inhouseRevenueCollectionId);
            echo 'Inhouse revenue collection was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }
      public function renderChart() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $revenueCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            echo json_encode($revenueCollectionRepository->renderChart($request));
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

}
