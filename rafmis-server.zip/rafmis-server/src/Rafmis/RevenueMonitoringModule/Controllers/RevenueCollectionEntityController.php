<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 5/28/2015
 * Time: 2:00 PM
 */

namespace Rafmis\RevenueMonitoringModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\RevenueMonitoringModule\Repository\RevenueCollectionEntityRepository;

class RevenueCollectionEntityController extends BaseController {

	const REPOSITORY_NAME = 'revenue_collection_entity_repository';

	public function all()
	{
		$request = $this->app->request->get();

		if (count($request)) {
			$columns = array(
				'mda_code',
				'description',
			);
			$revenueCollectionEntities = $this->tableData->get('revenue_collection_entity', 'mda_code', $columns);
		} else {
			/** @var RevenueCollectionEntityRepository $revenueCollectionEntityRepository */
			$revenueCollectionEntityRepository = $this->getRepository(self::REPOSITORY_NAME);
			$revenueCollectionEntities = $revenueCollectionEntityRepository->findAll();
		}

		if (!count($revenueCollectionEntities)) {
			echo 'No revenue collection entity has been added';
		} else if(count($request)) {
			echo json_encode($revenueCollectionEntities);
		} else {
			$this->app->response->header('content-type', 'application/json');
			echo $revenueCollectionEntities->toJSON();
		}
	}

    public function allWIthRevenueHead()
    {
        /** @var RevenueCollectionEntityRepository $revenueCollectionEntityRepository */
        $revenueCollectionEntityRepository = $this->getRepository(self::REPOSITORY_NAME);
        $revenueCollectionEntities = $revenueCollectionEntityRepository->findAllWithRevenueHead();

        if (!$revenueCollectionEntities->count()) {
            echo 'No revenue collection entities have been associated with a revenue head.';
        } else {
            $this->app->response->header('content-type', 'application/json');
            echo $revenueCollectionEntities->toJSON();
        }
    }

	public function create()
	{
		$request = json_decode($this->app->request->getBody(), true);
        $request['CreatedBy'] = $this->getCurrentUser();

		/** @var RevenueCollectionEntityRepository $revenueCollectionEntityRepository */
		$revenueCollectionEntityRepository = $this->getRepository(self::REPOSITORY_NAME);
		$revenueCollectionEntityRepository->saveRevenueCollectionEntity($request);

		echo 'Revenue collection entity has successfully been created';
	}

	public function show($mdaCode)
	{
		/** @var RevenueCollectionEntityRepository $revenueCollectionEntityRepository */
		$revenueCollectionEntityRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {

			$revenueCollectionEntity = $revenueCollectionEntityRepository->findRevenueCollectionEntityByMdaCode
			($mdaCode);
			echo $revenueCollectionEntity->exportTo('JSON');

		} catch (EntityNotFoundException $e) {

			$this->app->response->setStatus(404);
			$this->createNotFoundException($e->getMessage());

		}
	}

	public function update()
	{
		$request = json_decode($this->app->request->getBody(), true);
        $request['ModifiedBy'] = $this->getCurrentUser();

		/** @var RevenueCollectionEntityRepository $revenueCollectionEntityRepository */
		$revenueCollectionEntityRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {
			$revenueCollectionEntityRepository->saveRevenueCollectionEntity($request);
			echo 'Revenue collection entity was successfully updated';
		} catch (EntityNotFoundException $e) {
			$this->createNotFoundException();
		}
	}

	public function delete($mdaCode)
	{
		$revenueCollectionEntityRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {
			$revenueCollectionEntityRepository->deleteRevenueCollectionEntity($mdaCode);
			echo 'Revenue collection entity was successfully deleted';
		} catch (EntityNotFoundException $e) {
			$this->app->response->setStatus(404);
			$this->createNotFoundException($e->getMessage());
		}
	}

	public function exportData()
	{
		$request = $this->app->request->get();

		/** @var RevenueCollectionEntityRepository $revenueCollectionEntityRepository */
		$revenueCollectionEntityRepository = $this->getRepository(self::REPOSITORY_NAME);
		$revenueCollectionEntity = $revenueCollectionEntityRepository->filterData($request);

		echo $revenueCollectionEntity->toJSON();
	}
}
