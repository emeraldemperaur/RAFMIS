<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 5/28/2015
 * Time: 10:46 PM
 */

namespace Rafmis\PaymentScheduleManagementModule;

use Common\ServiceProviderInterface;
use Rafmis\PaymentScheduleManagementModule\Repository\BeneficiaryIndexRepository;
use Rafmis\PaymentScheduleManagementModule\Repository\ScheduleRepository;
use Rafmis\PaymentScheduleManagementModule\Repository\ScheduleDisbursementRepository;
use Slim\Slim;

class PaymentScheduleManagementModule {

    public function register($app) {
        //adds BeneficiaryIndexRepository to Slim container
        $app->container->singleton('beneficiary_index_repository', function () use ($app) {
            return new BeneficiaryIndexRepository($app);
        });

        //adds ScheduleRepository to Slim container
        $app->container->singleton('schedule_repository', function () use ($app) {
            return new ScheduleRepository($app);
        });
        
        //adds ScheduleDisbursementRepository to Slim container
        $app->container->singleton('schedule_disbursement_repository', function () use ($app) {
            return new ScheduleDisbursementRepository($app);
        });
    }

}
