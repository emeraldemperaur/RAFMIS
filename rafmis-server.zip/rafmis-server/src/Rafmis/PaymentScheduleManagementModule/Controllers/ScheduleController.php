<?php

/**

 */

namespace Rafmis\PaymentScheduleManagementModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\PaymentScheduleManagementModule\Repository\ScheduleRepository;

class ScheduleController extends BaseController {

    const REPOSITORY_NAME = 'schedule_repository';

    public function all($page = 1, $count = 10) {
        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);
        $schedules = $scheduleRepository->findAll($page, $count);

        if (!$schedules->count()) {
            echo 'No schedule has been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
            echo $schedules->getResults()->toJSON();
        }
    }

    public function create() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['date_created'] = date('Y-m-d H:i:s');
        $request['created_by'] = $this->getCurrentUser();
        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);
        $scheduleRepository->saveSchedule($request, 'create');

        echo 'schedule has successfully been created';
    }

    public function generate() {
        $request = $this->app->request->post();

        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $schedule = $scheduleRepository->generate($request);
            echo $schedule->toJSON();
        } catch (Exception $e) {

            $this->app->response->setStatus(404);
            echo $e->getMessage();
        }
    }

    public function generateIndex() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;

        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $indices = $scheduleRepository->generateIndex($request);
//            var_dump($indices);die();
//            die();
            echo json_encode($indices);
            //’
        } catch (Exception $e) {

            $this->app->response->setStatus(404);
            echo $e->getMessage();
        }
    }

    public function generateIndex2() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;

        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $indices = $scheduleRepository->generateIndex2($request);
//            var_dump($indices);die();
//            die();
            echo json_encode($indices);
            //’
        } catch (Exception $e) {

            $this->app->response->setStatus(404);
            echo $e->getMessage();
        }
    }

    public function generatePayment() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;

        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $paySchedule = $scheduleRepository->generatePayment($request);
//            var_dump($paySchedule);die();
//            die();
            echo json_encode($paySchedule);
        } catch (Exception $e) {

            $this->app->response->setStatus(404);
            echo $e->getMessage();
        }
    }

    public function scheduleexists() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;

        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $count = $scheduleRepository->scheduleexists($request);
//            var_dump($paySchedule);die();
//            die();
            echo ($count);
        } catch (Exception $e) {

            $this->app->response->setStatus(404);
            echo $e->getMessage();
        }
    }

    public function savePayment() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;

        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $paySchedule = $scheduleRepository->savePayment($request, $this->getCurrentUser());
            echo $paySchedule;
        } catch (Exception $e) {

            $this->app->response->setStatus(404);
            echo $e->getMessage();
        }
    }

    public function saveIndices() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;

        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $indices = $scheduleRepository->saveIndices($request);
            echo $indices;
        } catch (Exception $e) {

            $this->app->response->setStatus(404);
            echo $e->getMessage();
        }
    }

    public function disbursed() {
        $request = $this->app->request->post();

        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);
        $scheduleRepository->disbursed($request);

        echo 'schedule disbursment has been successfully updated';
    }

    public function showBeneficiary($id) {
        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $schedule = $scheduleRepository->findByBeneficiary($id);
            echo $schedule->toJSON();
        } catch (EntityNotFoundException $e) {

            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function showPrincipleItem($principle_item_id) {
        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $schedule = $scheduleRepository->findByPrincipleItem($principle_item_id);
            echo $schedule->toJSON();
        } catch (EntityNotFoundException $e) {

            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function showMonth($month) {
        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $schedule = $scheduleRepository->findByMonth($month);
            echo $schedule->toJSON();
        } catch (EntityNotFoundException $e) {

            $this->app->response->setStatus(404);
            $this->app->response->setBody($e->getMessage());
        }
    }

    public function showYear($year) {
        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $schedule = $scheduleRepository->findByYear($year);
            echo $schedule->toJSON();
        } catch (EntityNotFoundException $e) {

            $this->app->response->setStatus(404);
            $this->app->response->setBody($e->getMessage());
        }
    }

    public function update() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['date_modified'] = date('Y-m-d H:i:s');
        $request['modified_by'] = $this->getCurrentUser();


        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $scheduleRepository->saveSchedule($request, 'update');
            echo 'schedule was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function updateMultiple() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['date_modified'] = date('Y-m-d H:i:s');
        $request['modified_by'] = $this->getCurrentUser();


        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $scheduleRepository->updateMultiple($request);
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($id) {
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $scheduleRepository->delete($id);
            echo 'schedule was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function deletePayment($id1, $id2, $id3, $id4) {
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $scheduleRepository->deletePayment($id1, $id2, $id3, $id4);
            echo 'schedule was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function deleteDisbursement($id1, $id2, $id3, $id4, $id5, $id6) {
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $scheduleRepository->deleteDisbursement($id1, $id2, $id3, $id4, $id5, $id6);
            echo 'schedule was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public static function convertExcelToCSV() {
        $files = $_FILES;
        //is this an ajax request or sent via iframe(IE9 and below)?
        $ajax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest';
        $excel_readers = array(
            'Excel5',
            'Excel2003XML',
            'Excel2007'
        );

        require_once (dirname(dirname(dirname(dirname(__FILE__))))) . DIRECTORY_SEPARATOR . 'Common/Utilities/PHPExcel/PHPExcel.php';
//        require_once ('client/assets/plugins/PHPExcel/PHPExcel.php');
        $dir = dirname(str_replace("\t", "/t", $files["webmasterfile"]["tmp_name"]));
        if (preg_match("/.xlsx$/", $files["webmasterfile"]["name"])) {
            $reader = PHPExcel_IOFactory::createReader('Excel2007');
            $path = $dir . "/" . time() . rand() . "document.xslx";
        } else if (preg_match("/.xls$/", $files["webmasterfile"]["name"])) {
            $reader = PHPExcel_IOFactory::createReader('Excel5');
            $path = $dir . "/" . time() . rand() . "document.xsl";
        } else {
            $error = true;
        }


        if ($error) {
            $response = json_encode(array("status" => "0", "data" => "Bad File"));
        } else {
            rename($_FILES["webmasterfile"]["tmp_name"], $path);

            $reader->setReadDataOnly(true);
            $excel = $reader->load($path);

            $writer = PHPExcel_IOFactory::createWriter($excel, 'CSV');
            ob_start();
            $writer->save('php://output');
            $result = ob_get_clean();
            ob_end_clean();
            $response = json_encode(array("status" => "1", "data" => $result));
        }
        if ($ajax) {
            //if request was ajax(modern browser), just echo it back
            echo $response;
        } else {
            //if request was from an older browser not supporting ajax upload
            //then we have used an iframe instead and the response is sent back to the iframe as a script
            //if request was from an older browser not supporting ajax upload
            //then we have used an iframe instead and the response is sent back to the iframe as a script
            echo '<script language="javascript" type="text/javascript">';
            echo 'window.top.window.jQuery("#' . $_POST['temporary-iframe-id'] . '").data("deferrer").resolve(' . $response . ');';
            echo '</script>';
        }
        unlink($path);
    }

    public function importrecords() {
        $request = json_decode($this->app->request->getBody(), true);
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        //convert csv data into two multidimensionl array
        $lines = explode("\n", urldecode($request['data']));
        $head = str_getcsv(array_shift($lines));

        $array = array();
        foreach ($lines as $line) {
            $array[] = array_combine($head, str_getcsv($line));
        }
        $postValues = $request;
        $result = $scheduleRepository->import(
                $array, $postValues['beneficiary_id'],  $postValues['beneficiary_cat_allocation_group_id'], $postValues['revenue_type_category_id'], $postValues['total_allocated_value'], $postValues['total_disbursed_value'], $postValues['month'], $postValues['year'], date("Y-m-d H:i:s"), $this->getCurrentUser());

        echo json_encode($result);
    }

    public function revenueDisbursementGrid() {
//        $request = json_decode($this->app->request->getBody(), true);
//        $request = (array) $request;
//        $request['date_created'] = date('Y-m-d H:i:s');
//        $request['created_by'] = $this->getCurrentUser();
        /** @var scheduleRepository $scheduleRepository */
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);
        echo json_encode($scheduleRepository->revenueDisbursementGrid());

//        echo 'schedule has successfully been created';
    }

}
