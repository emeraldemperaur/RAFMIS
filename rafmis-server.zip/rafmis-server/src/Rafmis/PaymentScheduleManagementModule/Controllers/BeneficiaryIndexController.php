<?php

/**

 */

namespace Rafmis\PaymentScheduleManagementModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\PaymentScheduleManagementModule\Repository\BeneficiaryIndexRepository;

class BeneficiaryIndexController extends BaseController {

    const REPOSITORY_NAME = 'beneficiary_index_repository';

    public function all($page = 1, $count = 10) {
        /** @var beneficiaryIndexRepository $beneficiaryIndexRepository */
        $beneficiaryIndexRepository = $this->getRepository(self::REPOSITORY_NAME);
        $beneficiaryIndices = $beneficiaryIndexRepository->findAll($page, $count);

        if (!$beneficiaryIndices->count()) {
            echo 'No beneficiary index has been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
            echo $beneficiaryIndices->getResults()->toJSON();
        }
    }

    public function create() {
        $request = $this->app->request->post();

        /** @var beneficiaryIndexRepository $beneficiaryIndexRepository */
        $beneficiaryIndexRepository = $this->getRepository(self::REPOSITORY_NAME);
        $beneficiaryIndexRepository->save($request);

        echo 'beneficiary index has successfully been created';
    }

    public function showBeneficiary($id) {
        /** @var beneficiaryIndexRepository $beneficiaryIndexRepository */
        $beneficiaryIndexRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $beneficiaryIndex = $beneficiaryIndexRepository->findByBeneficiary($id);
            echo $beneficiaryIndex->toJSON();
        } catch (EntityNotFoundException $e) {

            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function showPrincipleItem($principle_item_id) {
        /** @var beneficiaryIndexRepository $beneficiaryIndexRepository */
        $beneficiaryIndexRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $beneficiaryIndex = $beneficiaryIndexRepository->findByPrincipleItem($principle_item_id);
            echo $beneficiaryIndex->getResults()->toJSON();
        } catch (EntityNotFoundException $e) {

            $this->app->response->setStatus(404);
            $this->app->response->setBody($e->getMessage());
        }
    }

    public function update() {
        $request = $this->app->request->post();

        /** @var beneficiaryIndexRepository $beneficiaryIndexRepository */
        $beneficiaryIndexRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $beneficiaryIndexRepository->save($request);
            echo 'beneficiary index was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($id) {
        $beneficiaryIndexRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $beneficiaryIndexRepository->delete($id);
            echo 'beneficiary index was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function deleteIndices($id1, $id2) {
        $scheduleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $scheduleRepository->deleteIndices($id1, $id2);
            echo 'schedule was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function indexexists() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;

        /** @var scheduleRepository $scheduleRepository */
        $indexRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {

            $count = $indexRepository->indexexists($request);
//            var_dump($paySchedule);die();
//            die();
            echo ($count);
        } catch (Exception $e) {

            $this->app->response->setStatus(404);
            echo $e->getMessage();
        }
    }

}
