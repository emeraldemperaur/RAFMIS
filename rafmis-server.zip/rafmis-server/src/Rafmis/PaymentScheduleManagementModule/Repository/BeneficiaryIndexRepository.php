<?php

/**

 */

namespace Rafmis\PaymentScheduleManagementModule\Repository;

use Propel\Runtime\Exception\EntityNotFoundException;
use Propel\Runtime\Propel;
use BeneficiaryIndex;
use BeneficiaryIndexQuery;
use PrincipleItemQuery;
use BeneficiaryCategoryAllocationQuery;
use BeneficiaryQuery;
use RawDataQuery;
use Slim\Slim;

class BeneficiaryIndexRepository {

    /**
     * @var Slim
     */
    private $app;

    /**
     * @var beneficiaryIndex
     */
    private $beneficiaryIndex;

    /**
     * * @var Connectiom	 
     */
    private $con;

    /**
     * @param Slim $app
     */
    public function __construct(Slim $app) {
        $this->con = Propel::getConnection();
        $this->app = $app;
        $this->beneficiaryIndex = new BeneficiaryIndex();
        $this->beneficiaryIndexQuery = BeneficiaryIndexQuery::create();

        return $this;
    }

    /**
     * @param array $data
     * @return int The number of affected rows
     */
    public function save(array $data) {
        $beneficiaryIndex = $this->beneficiaryIndex;
        $beneficiaryIndexPercentage = null;

        //verifies if the data passed in is a managed by propel
        if (isset($data['beneficiary_id'])) {

            $beneficiaryIndex = $this->findBy('BeneficiaryId', $data['beneficiary_id']);
            $beneficiaryIndex = $this->findbeneficiaryIndexByBeneficiaryId($data['beneficiary_id']);
        }


        //get principle item record from principle_item_id
        $principleItem = $this->fetchPrincipleItem($data['principle_item_id']);

        //get beneficiary category allocation from beneficiaryCategoryId derived from Principle Item
        $beneficiaryCategoryAllocation = $this->fetchBeneficiaryCategoryAllocation($principleItem->getBeneficiaryCategoryId());

        //calculate principleIndex
        $principleIndex = $principleItem->getPercentageAllocation() * $beneficiaryCategoryAllocation->getPercentageAllocation();

        if ($data['is_equality']) {

            $beneficiaryCount = BeneficiaryQuery::create()->count();
            $beneficiaryIndexPercentage = $principleIndex / $beneficiaryCount;
        } else {

            $rawData = $this->fetchRawData($principleItem->getPrincipleItemId, $data['beneficiary_id']);

            $beneficiaryIndexPercentage = $rawData * $principleIndex;
        }

        $beneficiaryIndex->setBeneficiaryId($data['beneficiary_id']);
        $beneficiaryIndex->setPrincipleItemId($data['principle_item_id']);
        $beneficiaryIndex->setIndex($beneficiaryIndexPercentage);

        return $this->beneficiaryIndex->save();
    }

    /**
     * @param $id
     *
     * @return array|mixed|beneficiaryIndex finds a beneficiary index by beneficiary
     *
     * finds a revenue head by its mda_code
     */
    public function findByBeneficiary($id) {

        $beneficiaryIndex = $this->findBy('BeneficiaryId', $id);

        if (!$beneficiaryIndex) {
            throw new EntityNotFoundException('Entity not found.');
        }

        return $beneficiaryIndex;
    }

    /**
     * @param $principle
     *
     * @return array|mixed|beneficiaryIndex finds a revenue head by its mda_code
     *
     * finds a revenue head by its mda_code
     */
    public function findByPrincipleItem($id) {

        $beneficiaryIndex = beneficiaryIndexQuery::create()->findOneByPrincipleItemId($id);

        if (!$beneficiaryIndex) {
            throw new EntityNotFoundException('Entity not found.');
        }

        $beneficiaryIndexQuery = $this->findBy('PrincipleItemId', $id);
        $beneficiaryIndex = beneficiaryIndexQuery::create()->findOneByPrincipleItemId($id);

        if (!$beneficiaryIndex) {
            throw new EntityNotFoundException('Entity not found.');
        }

        return $beneficiaryIndexQuery;
    }

    /**
     * @param $id
     *
     * @return mixed
     */
    public function delete($beneficiary_id) {
        /** @var beneficiaryIndex $beneficiaryIndex */
        $beneficiaryIndex = $this->findBy('BeneficiaryId', $beneficiary_id);
        $beneficiaryIndex->delete();
    }

    /**
     * @param $id
     *
     * @return mixed
     */
    public function deleteIndices($id1, $id2) {
//        var_dump($id1, $id2);
//        die();
        $sql='DELETE FROM beneficiary_index WHERE beneficiary_id IN (SELECT beneficiary_id FROM beneficiary WHERE beneficiary_category_id = ?) AND beneficiary_cat_allocation_group_id = ?';
        $stmt=$this->con->prepare($sql);
        $stmt->bindValue(1, $id2);
        $stmt->bindValue(2, $id1);
        $result=$stmt->execute();
        return $result;
    }

    private function fetchPrincipleItem($id) {

        $principleItem = PrincipleItemQuery::create()->findPk($id);
        return $principleItem;
    }

    private function fetchBeneficiaryCategoryAllocation($beneficiary_category_id) {
        $beneficiaryCategoryAllocation = BeneficiaryCategoryAllocationQuery::create()
                ->findByBeneficiaryCategoryId($beneficiary_category_id);
        return $beneficiaryCategoryAllocation;
    }

    private function fetchRawData($principle_item_id, $beneficiary_id) {

        $rawData = RawDataQuery::create()
                ->filterByPrincipleItemId($principle_item_id)
                ->filterByBeneficiaryId($beneficiary_id)
                ->findOne();
        return $rawData;
    }

    private function findBy($columnName, $pk) {
        $beneficiaryIndex = BeneficiaryIndexQuery::create()->findBy($columnName, $pk);
        return $beneficiaryIndex;
    }

    public function findAll($page = 1, $count = 10) {
        $beneficiaryIndexs = BeneficiaryIndexQuery::create()->select('*')->paginate($page, $count);
        return $beneficiaryIndexs;
    }

    public function indexexists(array $data) {
        $beneficiaryCategoryAllocationGroupId = $data['beneficiary_cat_allocation_group_id'];
//        $revenue_type_category_id = $data['revenue_type_category_id'];
        $beneficiary_category_id = $data['beneficiary_category_id'];

        $sql = " SELECT
  COUNT(*)
FROM `beneficiary_index`
  JOIN principle_item
    ON principle_item.principle_item_id = `beneficiary_index`.principle_item_id
WHERE principle_item.beneficiary_category_id = ?
    AND `beneficiary_index`.beneficiary_cat_allocation_group_id = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->bindValue(1, $beneficiary_category_id);
        $stmt->bindValue(2, $beneficiaryCategoryAllocationGroupId);
        $stmt->execute();
        $count = $stmt->fetchColumn(0);
        return $count;
    }

}
