<?php

/**

 */

namespace Rafmis\PaymentScheduleManagementModule\Repository;

use Propel\Runtime\Exception\EntityNotFoundException;
use Propel\Runtime\Exception\RuntimeException;
use Propel\Runtime\Propel;
use Common\BaseGrid;
use BeneficiaryIndexQuery;
use RevenueQuery;
use Schedule;
use ScheduleQuery;
use Slim\Slim;

class ScheduleRepository extends BaseGrid {

    /**
     * @var Slim
     */
    private $app;

    /**
     * @var schedule
     */
    private $schedule;
    private $scheduleQuery;

    /**
     * * @var Connectiom	 
     */
    private $con;

    /**
     * @param Slim $app
     */
    public function __construct(Slim $app) {
        $this->con = Propel::getConnection();
        $this->app = $app;
        $this->schedule = new Schedule();
        $this->scheduleQuery = ScheduleQuery::create();

        return $this;
    }

    /**
     * @param array $data
     */

    /**     * @param array $data	 * @return int The number of affected rows	 */
    public function saveSchedule(array $data, $mode) {
//        var_dump($data);die();
        try {
            //Save benficiary index first
            $this->con->beginTransaction();

            $beneficaryId = $data['beneficiary_id'];
            $principleItemId = $data['principle_item_id'];
            $benCatAllocationGroupId = $data['beneficiary_cat_allocation_group_id'];
            $revenueTypeCategoryId = $data['revenue_type_category_id'];
            $index = $data['Index'];
            $month = $data['month'];
            $year = $data['year'];

            if ($mode == 'create') {
                $revenueTypeCategoryId = $data['revenue_type_category_id'];
                $sql = 'INSERT INTO beneficiary_index VALUES(?,?,?,?,?,?,?,?)';

                $stmt = $this->con->prepare($sql);

                $stmt->bindValue(1, $beneficaryId);
                $stmt->bindValue(2, $principleItemId);
                $stmt->bindValue(3, $benCatAllocationGroupId);
                $stmt->bindValue(4, $index);
                $stmt->bindValue(5, $data['date_created']);
                $stmt->bindValue(6, $data['created_by']);
                $stmt->bindValue(7, NULL);
                $stmt->bindValue(8, NULL);

                $stmt->execute();

                $schedule = $this->schedule;
            } else {


                $pks = array(array($beneficaryId, $principleItemId, $benCatAllocationGroupId, $revenueTypeCategoryId, $month, $year));
                $pks2 = array(array($beneficaryId, $principleItemId, $benCatAllocationGroupId));

//                $beneficiaryIndex = BeneficiaryIndexQuery::create()->filterByPrimaryKeys($pks2)->findOne();
                $revenueTypeCategoryId = $data['revenue_type_category_id'];
                $sql = 'UPDATE beneficiary_index SET `Index` = ?, `date_modified` = ?, modified_by = ? WHERE `beneficiary_id` = ? AND `principle_item_id` = ? AND `beneficiary_cat_allocation_group_id` = ?';

                $stmt = $this->con->prepare($sql);

                $stmt->bindValue(1, $index);
                $stmt->bindValue(2, $data['date_modified']);
                $stmt->bindValue(3, $data['modified_by']);
                $stmt->bindValue(4, $beneficaryId);
                $stmt->bindValue(5, $principleItemId);
                $stmt->bindValue(6, $benCatAllocationGroupId);

                $stmt->execute();

                $schedule = ScheduleQuery::create()->filterByPrimaryKeys($pks)->findOne();
            }



            /* sets all required properties of the schedule */
            $schedule->setBeneficiaryId($data['beneficiary_id']);
            $schedule->setPrincipleItemId($data['principle_item_id']);
            $schedule->setBeneficiaryCatAllocationGroupId($data['beneficiary_cat_allocation_group_id']);
            $schedule->setRevenueTypeCategoryId($data['revenue_type_category_id']);
            $schedule->setAllocatedValue($data['allocated_value']);
            $schedule->setDisbursedValue($data['disbursed_value']);
            $schedule->setMonth($data['month']);
            $schedule->setYear($data['year']);
            $schedule->setDateCreated($mode == 'create' ? $data['date_created'] : $schedule->getDateCreated());
            $schedule->setCreatedBy($mode == 'create' ? $data['created_by'] : $schedule->getCreatedBy());
            $schedule->setDateModified($mode == 'update' ? $data['date_modified'] : $schedule->getDateModified());
            $schedule->setModifiedBy($mode == 'update' ? $data['modified_by'] : $schedule->getModifiedBy());

            $result = $schedule->save();
            $this->con->commit();
            return $result;
        } catch (Exception $e) {
            $this->con->rollBack();
            throw $e;
        }
    }

    private function placeholders($text, $count = 0, $separator = ",") {
        $result = array();
        if ($count > 0) {
            for ($x = 0; $x < $count; $x++) {
                $result[] = $text;
            }
        }

        return implode($separator, $result);
    }

    public function import($csvArray, $beneficiary_id, $beneficiary_cat_allocation_group_id, $revenue_type_category_id, $allocated_value, $disbursed_value, $month, $year, $dateCreated, $createdBy) {
        $db = $this->con;
        $count = 0;
        $start = 0;
        $limit = 1000;
        $stop = false;
        //there representation in the csv array
        $columns = array($beneficiary_id, $beneficiary_cat_allocation_group_id, $revenue_type_category_id, $allocated_value, $disbursed_value, $month, $year, "rafmis_column_1_date_created" => $dateCreated, "rafmis_column_1_created_by" => $createdBy, "rafmis_column_1_date_modified" => null, "rafmis_column_1_modified_by" => null);
        do {
            $result = array_splice($csvArray, $start, $limit);
            if (count($result) < $limit) {
                $stop = true;
            }
            if (count($result) == 0) {
                break;
            }
        
            $errorStore = array();
            $sql = implode(';', array_map(function($n)use($dateCreated, $createdBy) {
                        $bid = $n["Beneficiary ID"] == '' ? null : $n["Beneficiary ID"];
                        $bcatid = $n["Beneficiary Category Allocation Group ID"] == '' ? null : $n["Beneficiary Category Allocation Group ID"];
                        $rid = $n["Revnue Type Category ID"] == '' ? null : $n["Revnue Type Category ID"];
                        $av = $n["Allocated Value"] == '' ? 0 : $n["Allocated Value"];
                        $dv = $n["Disbursed Value"] == '' ? 0 : $n["Disbursed Value"];
                        $mth = $n["Month"] == '' ? null : $n["Month"];
                        $yr = $n["Year"] == '' ? null : $n["Year"];

                        return "INSERT INTO schedule_disbursement(`beneficiary_id`,`beneficiary_cat_allocation_group_id`,`revenue_type_category_id`,`total_allocated_value`,`total_disbursed_value`,`month`,`year`,date_created,created_by,date_modified,modified_by) VALUES ('$bid','$bcatid','$rid' ,$av,$dv,$mth,$yr,'$dateCreated', '$createdBy',null,null)";
                    }, $result));
            try {
                $db->beginTransaction();
                $rs = $stmt = $db->exec($sql);
                $db->commit();
                return $rs;
//                $count += intval($stmt->rowCount());
            } catch (PDOException $e) {
                $db->rollback();
//                    throw $e;
//                    $this->app->halt();
                $errorStore[] = $value;
                continue;
            }
        } while (!$stop);
        return array("valid" => $count, "invalid" => $errorStore);
    }

    private function replaceStr($str) {
        return preg_replace("/'+/", "\'", preg_replace('/"+/', '\"', $str));
    }

//    public function save(array $data, $mode) {
//
//        if ($mode == 'create') {
//            $schedule = $this->schedule;
//        } else {
//            $beneficaryId = $data['beneficiary_id'];
//            $principleItemId = $data['principle_item_id'];
//            $month = $data['month'];
//            $year = $data['year'];
//
//            $pks = array(array($beneficaryId, $principleItemId, $month, $year));
//            $schedule = ScheduleQuery::create()->filterByPrimaryKeys($pks)->findOne();
//        }
//
////verifies if the data passed in is a managed by propel
//        if (isset($data['revenue_type_id'])) {
//            $revenue = $this->fetchRevenue($data['revenue_type_id'], $data['month'], $data['year']);
//            $beneficiaryIndices = BeneficiaryIndexQuery::create()->find();
//            foreach ($beneficiaryIndices as $beneficiaryIndex) {
//                $schedule->setBeneficiaryId($beneficiaryIndex->getBeneficiaryId());
//                $schedule->setPrincipleItemId($beneficiaryIndex->getPrincipleItemId());
//                $schedule->setIndex($beneficiaryIndex->getBeneficiaryIndex());
//                $schedule->setAllocatedValue($revenue->getAmount() * $beneficiaryIndex->getBeneficiaryIndex());
//                $schedule->setMonth($data['month']);
//                $schedule->setYear($data['year']);
//            }
//        }
//
//        return $this->schedule->save();
//    }

    /**
     * @param array $data
     */
    public function generate(array $data) {
        $schedule = array();

//verifies if the data passed in is a managed by propel
        if (isset($data['revenue_type_id'])) {
            $revenue = $this->fetchRevenue($data['revenue_type_id'], $data['month'], $data['year']);
            $beneficiaryIndices = BeneficiaryIndexQuery::create()->find();
            foreach ($beneficiaryIndices as $beneficiaryIndex) {
                $row_array['beneficiary_id'] = $beneficiaryIndex->getBeneficiaryId();
                $row_array['principle_item_id'] = $beneficiaryIndex->getPrincipleItemId();
                $row_array['index'] = $beneficiaryIndex->getBeneficiaryIndex();
                $row_array['allocated_value'] = $revenue->getAmount() * $beneficiaryIndex->getBeneficiaryIndex();
                $row_array['month'] = $data['month'];
                $row_array['year'] = $data['year'];
                array_push($schedule, $row_array);
            }
        }

        return $schedule;
    }

    public function generateIndex(array $data) {
        $beneficiaryCategoryId = $data['beneficiary_category_id'];
        $beneficiaryCategoryAllocationGroupId = $data['beneficiary_cat_allocation_group_id'];
//        ===========================================================
        $sqlx = "SELECT percentage_allocation FROM beneficiary_category_allocation WHERE beneficiary_category_id = '$beneficiaryCategoryId' AND beneficiary_cat_allocation_group_id = '$beneficiaryCategoryAllocationGroupId'";
        $rslt = $this->con->query($sqlx);
        $beneficaryCatPercent = ($rslt->fetchColumn());
//===============================================================
        $sqlp = "SELECT principle_id FROM beneficiary_category_allocation WHERE beneficiary_category_id = '$beneficiaryCategoryId' AND beneficiary_cat_allocation_group_id = '$beneficiaryCategoryAllocationGroupId'";
        $rslp = $this->con->query($sqlp);
        $principle = ($rslp->fetchColumn());

        $stmtcl = $this->con->prepare("SELECT * FROM principle_item WHERE beneficiary_category_id = '$beneficiaryCategoryId' AND principle_id = '$principle'");
        $stmtcl->execute();
        $colgroups = $stmtcl->fetchAll(\PDO::FETCH_ASSOC);

        $ks = array_map(function($n) {
            return $n['parent_id'] === null ? '' : $n['parent_id'];
        }, $colgroups);
        $fks = (array_flip(array_filter(array_unique($ks))));
        $groupedColumns = array();
        foreach ($colgroups as $un) {
            if (!array_key_exists($un['principle_item_id'], $fks) && ($un['parent_id'] === NULL || $un['parent_id'] === '')) {
                $groupedColumns[$un['principle_item_id']] = $un['principle_item_name'] . '|' . $un['percentage_allocation'];
            } else if ($un['parent_id'] !== NULL && $un['parent_id'] !== '') {
                $groupedColumns[$un['parent_id']][$un['principle_item_id']] = $un['principle_item_name'] . '|' . $un['percentage_allocation'];
            }
        }

//===============================================================

        $sql = "SELECT
  principle_item.principle_item_id,
  principle_item.principle_item_name,
  principle_item.percentage_allocation                    AS `PI-percent`,
  beneficiary_category_allocation.beneficiary_category_id,
  principle_item.is_equal
FROM beneficiary_category_allocation
  JOIN principle_item
    ON principle_item.principle_id = beneficiary_category_allocation.principle_id
  JOIN principle
    ON principle.principle_id = principle_item.principle_id
WHERE beneficiary_category_allocation.beneficiary_cat_allocation_group_id = ?
    AND principle_item.beneficiary_category_id = ?
    AND beneficiary_category_allocation.beneficiary_category_id = ?";

        $stmt = $this->con->prepare($sql);
        $stmt->bindValue(1, $beneficiaryCategoryAllocationGroupId);
        $stmt->bindValue(2, $beneficiaryCategoryId);
        $stmt->bindValue(3, $beneficiaryCategoryId);
        $stmt->execute();
        $pItems = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $mappedItems = array();
        $mappedItems2 = array();
        foreach ($pItems as $item) {
            if (is_array($item)) {
                $mappedItems[$item['principle_item_id']]['PI-percent'] = floatval($item['PI-percent']);
                $mappedItems[$item['principle_item_id']]['is_equal'] = $item['is_equal'];
                $mappedItems[$item['principle_item_id']]['principle_item_name'] = $item['principle_item_name'];
                $mappedItems2[$item['principle_item_id']] = $item['principle_item_name'] . '|' . $item['PI-percent'];
            }
        }
        $sql3 = "SELECT DISTINCT
  beneficiary.beneficiary_id,
  raw_data.principle_item_id,
  beneficiary.parent_id,
  raw_data.value             AS `Raw Data Value`
FROM beneficiary
  LEFT JOIN raw_data
    ON raw_data.beneficiary_id = beneficiary.beneficiary_id
WHERE beneficiary.beneficiary_category_id = ?
ORDER BY beneficiary.parent_id ASC, beneficiary.beneficiary_id ASC";
        $stmtl = $this->con->prepare($sql3);
        $stmtl->bindValue(1, $beneficiaryCategoryId);
        $stmtl->execute();
        $allBeneficiaries = $stmtl->fetchAll(\PDO::FETCH_ASSOC);

        $sql4 = "SELECT
  raw_data.principle_item_id,
  SUM(raw_data.`value`)      AS total
FROM raw_data
  JOIN principle_item
    ON raw_data.principle_item_id = principle_item.principle_item_id
  JOIN beneficiary_category_allocation
    ON beneficiary_category_allocation.principle_id = principle_item.principle_id
WHERE beneficiary_category_allocation.beneficiary_cat_allocation_group_id = ?
    AND beneficiary_category_allocation.beneficiary_category_id = ?
GROUP BY raw_data.principle_item_id";
        $stmt4 = $this->con->prepare($sql4);
        $stmt4->bindValue(1, $beneficiaryCategoryAllocationGroupId);
        $stmt4->bindValue(2, $beneficiaryCategoryId);
        $stmt4->execute();
        $sums = $stmt4->fetchAll(\PDO::FETCH_ASSOC);

        $sql5 = "SELECT COUNT(*) AS beneficiary_count FROM beneficiary WHERE beneficiary_category_id =?";

        $stmt5 = $this->con->prepare($sql5);
        $stmt5->bindValue(1, $beneficiaryCategoryId);
        $stmt5->execute();
        $beneficiaryCountFake = $stmt5->fetch(\PDO::FETCH_ASSOC)['beneficiary_count'];

        $sqlbc = "SELECT description FROM beneficiary_category WHERE beneficiary_category_id =?";
        $stmtbc = $this->con->prepare($sqlbc);
        $stmtbc->bindValue(1, $beneficiaryCategoryId);
        $stmtbc->execute();
        $beneficiaryCatDescription = $stmtbc->fetch(\PDO::FETCH_ASSOC)['description'];

        $stmtrw = $this->con->prepare("SELECT raw_data.*
FROM raw_data
  JOIN principle_item
    ON principle_item.principle_item_id = raw_data.principle_item_id
  JOIN beneficiary_category_allocation
    ON beneficiary_category_allocation.principle_id = principle_item.principle_id
WHERE beneficiary_category_allocation.beneficiary_cat_allocation_group_id = ?
    AND principle_item.beneficiary_category_id = ?");
        $stmtrw->bindValue(1, $beneficiaryCategoryAllocationGroupId);
        $stmtrw->bindValue(2, $beneficiaryCategoryId);
        $stmtrw->execute();
        $resultrw = $stmtrw->fetchAll(\PDO::FETCH_ASSOC);
        $rawData = array();
        foreach ($resultrw as $each) {
            $rawData[$each['principle_item_id']][$each['beneficiary_id']] = $each['value'];
        }


        $allData = array();
        foreach ($sums as $unit) {
            $allData[$unit['principle_item_id']] = $unit['total'];
        }
//        var_dump($allData);die();
        $preparedFake = array();

        foreach ($allBeneficiaries as $beneficiary) {
            foreach ($mappedItems as $key => $item) {
                $isEqual = $mappedItems[$key]['is_equal'];
                $piPercent = $mappedItems[$key]['PI-percent'];
                $preparedFake[$beneficiary['beneficiary_id']]['parent_id'] = $beneficiary['parent_id'];

                if ($isEqual === "0") {
                    if ($key === $beneficiary['principle_item_id']) {
                        $value = $beneficiary['Raw Data Value'];
                        $preparedFake[$beneficiary['beneficiary_id']][$key] = ( floatval($value) / floatval($allData[$key])) * (floatval($beneficaryCatPercent) / 100) * (floatval($piPercent) / 100);
                    }
                } else {
                    if (!isset($preparedFake[$beneficiary['beneficiary_id']][$key])) {

                        $preparedFake[$beneficiary['beneficiary_id']][$key] = ((floatval($beneficaryCatPercent) / 100) * (floatval($item['PI-percent']) / 100)) / intval($beneficiaryCountFake);
                    }
                }
            }
        }
        $valid = array();
        foreach ($groupedColumns as $n) {
            if (is_string($n)) {
                $valid[] = $n;
            } else if (is_array($n)) {
                foreach ($n as $two) {
                    $valid[] = $two;
                }
            }
        }
        $size_of_columns = sizeof($valid);
        $fltrdFake = array_filter($preparedFake, function($m)use($size_of_columns) {
            return sizeof($m) - 1 == $size_of_columns;
        });
        $beneficiaryCount = sizeof($fltrdFake);


        $prepared = array();
        $columns = array();
        foreach ($allBeneficiaries as $beneficiary) {
            foreach ($mappedItems as $key => $item) {
                $columns[$key] = $item['principle_item_name'];
                $isEqual = $mappedItems[$key]['is_equal'];
                $piPercent = $mappedItems[$key]['PI-percent'];
                $prepared[$beneficiary['beneficiary_id']]['parent_id'] = $beneficiary['parent_id'];

                if ($isEqual === "0") {
                    if ($key === $beneficiary['principle_item_id']) {
                        $value = $beneficiary['Raw Data Value'];
                        $prepared[$beneficiary['beneficiary_id']][$key] = ( floatval($value) / floatval($allData[$key])) * (floatval($beneficaryCatPercent) / 100) * (floatval($piPercent) / 100);
                    }
                } else {
                    if (!isset($prepared[$beneficiary['beneficiary_id']][$key])) {

                        $prepared[$beneficiary['beneficiary_id']][$key] = ((floatval($beneficaryCatPercent) / 100) * (floatval($item['PI-percent']) / 100)) / intval($beneficiaryCount);
                    }
                }
            }
        }
        $fltrd = array_filter($prepared, function($m)use($size_of_columns) {
            return sizeof($m) - 1 == $size_of_columns;
        });
        array_unshift($columns, 'parent_id');
        $groupedColumns = array_merge(array('parent_id' => 'parent_id'), $groupedColumns);

        $columns['parent_id'] = 'parent_id';
        $package = array('data' => $fltrd, 'pi-columns' => $columns, 'grouped-columns' => $groupedColumns, 'column-info' => $mappedItems2, 'beneficaryCatPercent' => $beneficaryCatPercent, 'beneficiaryCategoryId' => $beneficiaryCatDescription, 'beneficiaryCategoryAllocationGroupId' => $beneficiaryCategoryAllocationGroupId, 'raw-data' => $rawData);
        return $package;
    }

    /**
     * @param array $data
     */
    public function generatePayment(array $data) {
        $revenue_type_category_id = $data['revenue_type_category_id'];
        $month = intval($data['month']);
        $year = intval($data['year']);
        $sql = "SELECT SUM(amount) AS allocation FROM revenue WHERE revenue_type_id IN 
(SELECT revenue_type_id FROM revenue_type_category_group WHERE revenue_type_category_id = ?) AND `month` = $month AND `year` = $year";

        $sqlrt = "SELECT description FROM revenue_type_category WHERE revenue_type_category_id =?";
        $stmtrt = $this->con->prepare($sqlrt);
        $stmtrt->bindValue(1, $revenue_type_category_id);
        $stmtrt->execute();
        $rtcdesc = $stmtrt->fetch(\PDO::FETCH_ASSOC)['description'];

        $stmt = $this->con->prepare($sql);

        $stmt->bindValue(1, $revenue_type_category_id);

        $stmt->execute();

        $allocation = $stmt->fetchColumn();

        $allocation == null ? 0 : floatval($allocation);

        $indices = $this->generateIndex($data)['data'];
//        var_dump($indices);
//        die();
        $columns = $this->generateIndex($data)['pi-columns'];
        $groupedColumns = $this->generateIndex($data)['grouped-columns'];
        $columnInfo = $this->generateIndex($data)['column-info'];
        $beneficaryCatPercent = $this->generateIndex($data)['beneficaryCatPercent'];
        $beneficiaryCategoryId = $this->generateIndex($data)['beneficiaryCategoryId'];
        $beneficiaryCategoryAllocationGroupId = $this->generateIndex($data)['beneficiaryCategoryAllocationGroupId'];
        $paymentSchedule = array_map(function($n)use($allocation) {
            return array_map(function($o)use($allocation) {
//                var_dump($o);
                if (is_string($o)) {
                    return $o;
                } else if (is_float($o)) {
                    return $allocation * ($o);
                } else {
                    return null;
                }
            }, $n);
        }, $indices);
        $package = array('data' => $paymentSchedule, 'pi-columns' => $columns, 'grouped-columns' => $groupedColumns, 'column-info' => $columnInfo, 'beneficaryCatPercent' => $beneficaryCatPercent, 'beneficiaryCategoryId' => $beneficiaryCategoryId, 'beneficiaryCategoryAllocationGroupId' => $beneficiaryCategoryAllocationGroupId, 'revenue_type_category_id' => $rtcdesc, 'month' => $month, 'year' => $year);
        return $package;
    }

    public function savePayment(array $data, $user) {
        try {
            $beneficiaryCategoryAllocationGroupId = $data['beneficiary_cat_allocation_group_id'];
            $revenue_type_category_id = $data['revenue_type_category_id'];
            $month = intval($data['month']);
            $year = intval($data['year']);
            $sql = "SELECT SUM(amount) AS allocation FROM revenue WHERE revenue_type_id IN 
(SELECT revenue_type_id FROM revenue_type_category_group WHERE revenue_type_category_id = ?) AND `month` = $month AND `year` = $year";

            $stmt = $this->con->prepare($sql);

            $stmt->bindValue(1, $revenue_type_category_id);

            $stmt->execute();
            $allocation = $stmt->fetchColumn();
            $allocation == null ? 0 : floatval($allocation);
            $indices = $this->generateIndex($data)['data'];
            $columns = $this->generateIndex($data)['pi-columns'];
            $paymentSchedule = array_map(function($n)use($allocation) {
                return array_map(function($o)use($allocation) {
                    if (is_string($o)) {
                        return $o;
                    } else {
                        return $allocation * ($o);
                    }
                }, $n);
            }, $indices);
//            var_dump($paymentSchedule);die();
            $inserts = implode('', array_map(function($value, $benneficiaryId)use($beneficiaryCategoryAllocationGroupId, $revenue_type_category_id, $month, $year, $user) {
                        $dateCreated = date('Y-m-d H:i:s');
                        $benneficiaryId = addslashes($benneficiaryId);
                        $beneficiaryCategoryAllocationGroupId = addslashes($beneficiaryCategoryAllocationGroupId);
                        $total_allocation = array_sum(array_map(function($m, $principle_item_id)use($benneficiaryId, $beneficiaryCategoryAllocationGroupId, $revenue_type_category_id, $month, $year, $user) {

                                    if (is_float($m)) {
                                        return $m;
                                    } else {
                                        return 0;
                                    }
                                }, $value, array_keys($value)));

                        return "INSERT INTO `schedule_disbursement`(`beneficiary_id`,`beneficiary_cat_allocation_group_id`,`revenue_type_category_id`,`total_allocated_value`,`total_disbursed_value`,`month`,`year`,`date_created`,`created_by`,`date_modified`,`modified_by`) VALUES('$benneficiaryId','$beneficiaryCategoryAllocationGroupId','$revenue_type_category_id',$total_allocation,NULL,$month, $year, '$dateCreated','$user',NULL,NULL);";
                    }, $paymentSchedule, array_keys($paymentSchedule)));

            $insertsx = explode(';', $inserts);
            $result = false;
            $this->con->beginTransaction();
            foreach ($insertsx as $unit) {
                if ($unit !== '') {
                    $this->con->query($unit);
                }
            }
            $result = true;
            $this->con->commit();

            return $result;
        } catch (Exception $e) {

            $this->con->rollBack();
            throw $e;
        }
    }

    public function saveIndices(array $data) {
        try {
            $beneficiaryCategoryAllocationGroupId = $data['beneficiary_cat_allocation_group_id'];
            $indices = $this->generateIndex($data)['data'];

            $inserts = implode('', array_map(function($value, $benneficiaryId)use($beneficiaryCategoryAllocationGroupId) {
                        return implode('', array_map(function($m, $principle_item_id)use($benneficiaryId, $beneficiaryCategoryAllocationGroupId) {
//                                    var_dump($m);
                                    $dateCreated = date('Y-m-d H:i:s');
                                    if ($principle_item_id !== 'parent_id') {
                                        $m = addslashes($m);
                                        $benneficiaryId = addslashes($benneficiaryId);
//                                        var_dump($m);
                                        return "INSERT INTO beneficiary_index(`beneficiary_id`,`principle_item_id`,`beneficiary_cat_allocation_group_id`, `Index`,`date_created`,`created_by`,`date_modified`,`modified_by`) VALUES('$benneficiaryId','$principle_item_id','$beneficiaryCategoryAllocationGroupId','$m','$dateCreated','admin',NULL,NULL);";
                                    } else {
                                        return '';
                                    }
                                }, $value, array_keys($value)));
                    }, $indices, array_keys($indices)));

            $insertsx = explode(';', $inserts);

            $result = false;
//            var_dump($insertsx);
//            die();
            $this->con->beginTransaction();
            foreach ($insertsx as $unit) {
                if ($unit !== '') {
                    $this->con->query($unit);
                }
            }
            $result = true;
            $this->con->commit();

            return $result;
        } catch (Exception $e) {

            $this->con->rollBack();
            throw $e;
        }
    }

    public function scheduleexists(array $data) {
        $beneficiaryCategoryAllocationGroupId = $data['beneficiary_cat_allocation_group_id'];
//        $revenue_type_category_id = $data['revenue_type_category_id'];
        $beneficiary_category_id = $data['beneficiary_category_id'];
        $month = intval($data['month']);
        $year = intval($data['year']);

        $sql = "SELECT
  COUNT(*)
FROM `schedule_disbursement`
  JOIN beneficiary
    ON beneficiary.beneficiary_id = `schedule_disbursement`.beneficiary_id
WHERE beneficiary.beneficiary_category_id = ?
    AND `schedule_disbursement`.beneficiary_cat_allocation_group_id = ?
    AND `schedule_disbursement`.`month` = ?
    AND `schedule_disbursement`.`year` = ?";
        $stmt = $this->con->prepare($sql);
        $stmt->bindValue(1, $beneficiary_category_id);
        $stmt->bindValue(2, $beneficiaryCategoryAllocationGroupId);
        $stmt->bindValue(3, $month);
        $stmt->bindValue(4, $year);
        $stmt->execute();
        $count = $stmt->fetchColumn(0);


//        $count = \Base\ScheduleQuery::create()->join('principle_item.PrincipleItemId')->filterByBeneficiaryCatAllocationGroupId($beneficiaryCategoryAllocationGroupId)->filterByMonth($month)->filterByYear($year)->count();
        return $count;
    }

    public function updateMultiple(array $data) {
//        var_dump($data);
        $updatesComp = array_filter($data, function($n) {
            if (is_array($n)) {
                return $n;
            }
        });
        $dateModified = $data['date_modified'];
        $modifiedBy = $data['modified_by'];
        $updates = array_map(function($n)use($dateModified, $modifiedBy) {
            $beneficiary_cat_allocation_group_id = $n['beneficiary_cat_allocation_group_id'];
            $beneficiary_id = $n['beneficiary_id'];
//            $principle_item_id = $n['principle_item_id'];
            $revenue_type_category_id = $n['revenue_type_category_id'];
            $month = $n['month'];
            $year = $n['year'];
            $disbursed_value = trim($n['disbursed_value']) === '' ? null : $n['disbursed_value'];
            return "UPDATE `schedule_disbursement` SET total_disbursed_value = '$disbursed_value', date_modified = '$dateModified', modified_by = '$modifiedBy'
                    WHERE beneficiary_cat_allocation_group_id = '$beneficiary_cat_allocation_group_id' AND beneficiary_id = '$beneficiary_id' AND revenue_type_category_id = '$revenue_type_category_id' AND `month` = $month AND `year` = $year";
        }, $updatesComp);
        try {
            $this->con->beginTransaction();
            foreach ($updates as $statement) {
                $this->con->exec($statement);
            }
            $this->con->commit();
        } catch (RuntimeException $e) {
            $this->con->rollBack();
        }
    }

    /**
     * @param array $data
     */
    public function disbursed(array $data) {
        $scheduleQuery = $this->scheduleQuery
                ->filterByBeneficiaryId($data['beneficiary_id'])
                ->filterByPrincipleItemId($data['principle_item_id'])
                ->filterByMonth($month)
                ->filterByYear($year)
                ->findOne();


        if (!$scheduleQuery) {
            throw new EntityNotFoundException('Entity not found.');
        }

        $schedule->setDisbursedValue($data['disbursed_value']);

        return $this->schedule->save();
    }

    public function generateIndex2(array $data) {
        $beneficiaryCategoryId = $data['beneficiary_category_id'];
        $beneficiaryCategoryAllocationGroupId = $data['beneficiary_cat_allocation_group_id'];
//        ===========================================================
        $sqlx = "SELECT percentage_allocation FROM beneficiary_category_allocation WHERE beneficiary_category_id = '$beneficiaryCategoryId' AND beneficiary_cat_allocation_group_id = '$beneficiaryCategoryAllocationGroupId'";
        $rslt = $this->con->query($sqlx);
        $beneficaryCatPercent = ($rslt->fetchColumn());
//===============================================================
        $sqlp = "SELECT principle_id FROM beneficiary_category_allocation WHERE beneficiary_category_id = '$beneficiaryCategoryId' AND beneficiary_cat_allocation_group_id = '$beneficiaryCategoryAllocationGroupId'";
        $rslp = $this->con->query($sqlp);
        $principle = ($rslp->fetchColumn());

        $stmtcl = $this->con->prepare("SELECT * FROM principle_item WHERE beneficiary_category_id = '$beneficiaryCategoryId' AND principle_id = '$principle'");
        $stmtcl->execute();
        $colgroups = $stmtcl->fetchAll(\PDO::FETCH_ASSOC);

        $ks = array_map(function($n) {
            return $n['parent_id'] === null ? '' : $n['parent_id'];
        }, $colgroups);
        $fks = (array_flip(array_filter(array_unique($ks))));
        $groupedColumns = array();
        foreach ($colgroups as $un) {
            if (!array_key_exists($un['principle_item_id'], $fks) && ($un['parent_id'] === NULL || $un['parent_id'] === '')) {
                $groupedColumns[$un['principle_item_id']] = $un['principle_item_name'] . '|' . $un['percentage_allocation'];
            } else if ($un['parent_id'] !== NULL && $un['parent_id'] !== '') {
                $groupedColumns[$un['parent_id']][$un['principle_item_id']] = $un['principle_item_name'] . '|' . $un['percentage_allocation'];
            }
        }

//===============================================================

        $sql = "SELECT
  principle_item.principle_item_id,
  principle_item.principle_item_name,
  principle_item.percentage_allocation                    AS `PI-percent`,
  beneficiary_category_allocation.beneficiary_category_id,
  principle_item.is_equal
FROM beneficiary_category_allocation
  JOIN principle_item
    ON principle_item.principle_id = beneficiary_category_allocation.principle_id
  JOIN principle
    ON principle.principle_id = principle_item.principle_id
WHERE beneficiary_category_allocation.beneficiary_cat_allocation_group_id = ?
    AND principle_item.beneficiary_category_id = ?
    AND beneficiary_category_allocation.beneficiary_category_id = ?";

        $stmt = $this->con->prepare($sql);
        $stmt->bindValue(1, $beneficiaryCategoryAllocationGroupId);
        $stmt->bindValue(2, $beneficiaryCategoryId);
        $stmt->bindValue(3, $beneficiaryCategoryId);
        $stmt->execute();
        $pItems = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        $mappedItems = array();
        $mappedItems2 = array();
        foreach ($pItems as $item) {
            if (is_array($item)) {
                $mappedItems[$item['principle_item_id']]['PI-percent'] = floatval($item['PI-percent']);
                $mappedItems[$item['principle_item_id']]['is_equal'] = $item['is_equal'];
                $mappedItems[$item['principle_item_id']]['principle_item_name'] = $item['principle_item_name'];
                $mappedItems2[$item['principle_item_id']] = $item['principle_item_name'] . '|' . $item['PI-percent'];
            }
        }
        $sql3 = "SELECT DISTINCT
  beneficiary.beneficiary_id,
  raw_data.principle_item_id,
  beneficiary.parent_id,
  raw_data.value             AS `Raw Data Value`
FROM beneficiary
  LEFT JOIN raw_data
    ON raw_data.beneficiary_id = beneficiary.beneficiary_id
WHERE beneficiary.beneficiary_category_id = ?
ORDER BY beneficiary.parent_id ASC, beneficiary.beneficiary_id ASC";
        $stmtl = $this->con->prepare($sql3);
        $stmtl->bindValue(1, $beneficiaryCategoryId);
        $stmtl->execute();
        $allBeneficiaries = $stmtl->fetchAll(\PDO::FETCH_ASSOC);

        $sql4 = "SELECT
  raw_data.principle_item_id,
  SUM(raw_data.`value`)      AS total
FROM raw_data
  JOIN principle_item
    ON raw_data.principle_item_id = principle_item.principle_item_id
  JOIN beneficiary_category_allocation
    ON beneficiary_category_allocation.principle_id = principle_item.principle_id
WHERE beneficiary_category_allocation.beneficiary_cat_allocation_group_id = ?
    AND beneficiary_category_allocation.beneficiary_category_id = ?
GROUP BY raw_data.principle_item_id";
        $stmt4 = $this->con->prepare($sql4);
        $stmt4->bindValue(1, $beneficiaryCategoryAllocationGroupId);
        $stmt4->bindValue(2, $beneficiaryCategoryId);
        $stmt4->execute();
        $sums = $stmt4->fetchAll(\PDO::FETCH_ASSOC);

        $sql5 = "SELECT COUNT(*) AS beneficiary_count FROM beneficiary WHERE beneficiary_category_id =?";

        $stmt5 = $this->con->prepare($sql5);
        $stmt5->bindValue(1, $beneficiaryCategoryId);
        $stmt5->execute();
        $beneficiaryCountFake = $stmt5->fetch(\PDO::FETCH_ASSOC)['beneficiary_count'];

        $sqlbc = "SELECT description FROM beneficiary_category WHERE beneficiary_category_id =?";
        $stmtbc = $this->con->prepare($sqlbc);
        $stmtbc->bindValue(1, $beneficiaryCategoryId);
        $stmtbc->execute();
        $beneficiaryCatDescription = $stmtbc->fetch(\PDO::FETCH_ASSOC)['description'];

        $stmtrw = $this->con->prepare("SELECT raw_data.principle_item_id
FROM raw_data
  JOIN principle_item
    ON principle_item.principle_item_id = raw_data.principle_item_id
  JOIN beneficiary_category_allocation
    ON beneficiary_category_allocation.principle_id = principle_item.principle_id
WHERE beneficiary_category_allocation.beneficiary_cat_allocation_group_id = ?
    AND principle_item.beneficiary_category_id = ?
    GROUP BY raw_data.principle_item_id");
        $stmtrw->bindValue(1, $beneficiaryCategoryAllocationGroupId);
        $stmtrw->bindValue(2, $beneficiaryCategoryId);
        $stmtrw->execute();
        $resultrw = $stmtrw->fetchAll(\PDO::FETCH_COLUMN);
        $rawData = array_values($resultrw);


        $allData = array();
        foreach ($sums as $unit) {
            $allData[$unit['principle_item_id']] = $unit['total'];
        }
//        var_dump($allData);die();
        $preparedFake = array();

        foreach ($allBeneficiaries as $beneficiary) {
            foreach ($mappedItems as $key => $item) {
                $isEqual = $mappedItems[$key]['is_equal'];
                $piPercent = $mappedItems[$key]['PI-percent'];
                $preparedFake[$beneficiary['beneficiary_id']]['parent_id'] = $beneficiary['parent_id'];

                if ($isEqual === "0") {
                    if ($key === $beneficiary['principle_item_id']) {
                        $value = $beneficiary['Raw Data Value'];
                        $preparedFake[$beneficiary['beneficiary_id']][$key] = ( floatval($value) / floatval($allData[$key])) * (floatval($beneficaryCatPercent) / 100) * (floatval($piPercent) / 100);
                    }
                } else {
                    if (!isset($preparedFake[$beneficiary['beneficiary_id']][$key])) {

                        $preparedFake[$beneficiary['beneficiary_id']][$key] = ((floatval($beneficaryCatPercent) / 100) * (floatval($item['PI-percent']) / 100)) / intval($beneficiaryCountFake);
                    }
                }
            }
        }
        $valid = array();
        foreach ($groupedColumns as $n) {
            if (is_string($n)) {
                $valid[] = $n;
            } else if (is_array($n)) {
                foreach ($n as $two) {
                    $valid[] = $two;
                }
            }
        }
        $size_of_columns = sizeof($valid);
        $fltrdFake = array_filter($preparedFake, function($m)use($size_of_columns) {
            return sizeof($m) - 1 == $size_of_columns;
        });
        $beneficiaryCount = sizeof($fltrdFake);


        $prepared = array();
        $columns = array();
        foreach ($allBeneficiaries as $beneficiary) {
            foreach ($mappedItems as $key => $item) {
                $columns[$key] = $item['principle_item_name'];
                $isEqual = $mappedItems[$key]['is_equal'];
                $piPercent = $mappedItems[$key]['PI-percent'];
                $prepared[$beneficiary['beneficiary_id']]['parent_id'] = $beneficiary['parent_id'];

                if ($isEqual === "0") {
                    if ($key === $beneficiary['principle_item_id']) {
                        $value = $beneficiary['Raw Data Value'];
                        $prepared[$beneficiary['beneficiary_id']][$key]['index'] = ( floatval($value) / floatval($allData[$key])) * (floatval($beneficaryCatPercent) / 100) * (floatval($piPercent) / 100);
                        $prepared[$beneficiary['beneficiary_id']][$key]['value'] = $value;
                    }
                } else {
                    if (!isset($prepared[$beneficiary['beneficiary_id']][$key])) {

                        $prepared[$beneficiary['beneficiary_id']][$key]['index'] = ((floatval($beneficaryCatPercent) / 100) * (floatval($item['PI-percent']) / 100)) / intval($beneficiaryCount);
                    }
                }
            }
        }
        $fltrd = array_filter($prepared, function($m)use($size_of_columns) {
            return sizeof($m) - 1 == $size_of_columns;
        });
        array_unshift($columns, 'parent_id');
        $groupedColumns = array_merge(array('parent_id' => 'parent_id'), $groupedColumns);

        $columns['parent_id'] = 'parent_id';
        $package = array('data' => $fltrd, 'pi-columns' => $columns, 'grouped-columns' => $groupedColumns, 'column-info' => $mappedItems2, 'beneficaryCatPercent' => $beneficaryCatPercent, 'beneficiaryCategoryId' => $beneficiaryCatDescription, 'beneficiaryCategoryAllocationGroupId' => $beneficiaryCategoryAllocationGroupId, 'raw-data' => $rawData);
        return $package;
    }

    /**
     * @param $beneficiary_id
     *
     * @return array|mixed|schedule finds a revenue head by its revenue_head_id
     *
     * finds a revenue head by its mda_code
     */
    public function findByBeneficiary($beneficiary_id) {

        $schedule = $this->findBy('BeneficiaryId', $beneficiary_id);

        if (!$schedule) {
            throw new EntityNotFoundException('Entity not found.');
        }

        return $schedule;
    }

    /**
     * @param $principle_item_id
     *
     * @return array|mixed|schedule finds a revenue head by its mda_code
     *
     * finds a revenue head by its mda_code
     */
    public function findByPrincipleItem($principle_item_id) {

        $schedule = ScheduleQuery::create()->findOneByPrincipleItemId($principle_item_id);

        if (!$schedule) {
            throw new EntityNotFoundException('Entity not found.');
        }

        return $scheduleQuery;
    }

    /**
     * @param $month
     *
     * @return array|mixed|schedule finds a schedule by month
     *
     * finds a revenue head by month
     */
    public function findByMonth($month) {

        $schedule = $this->findBy('Month', $month);

        if (!$schedule) {
            throw new EntityNotFoundException('Entity not found.');
        }

        return $schedule;
    }

    /**
     * @param $year
     *
     * @return array|mixed|schedule finds a schedule by year
     *
     * finds a revenue head by year
     */
    public function findByYear($year) {

        $schedule = $this->findBy('Year', $year);

        if (!$schedule) {
            throw new EntityNotFoundException('Entity not found.');
        }

        return $schedule;
    }

    /**
     * @param $id
     *
     * @return mixed
     */
    public function deletePayment($id1, $id2, $id3, $id4) {
        $today = (strtotime('today'));

        $date_of_record = strtotime(date("Y-m-t", strtotime("$id4-$id3-01")));

        $duration = ($today - $date_of_record) / 86400;

        if ($duration <= MAX_DAYS_FOR_DELETE) {
            $this->con->beginTransaction();
//            $result = ScheduleQuery::create()->filterByBeneficiaryCatAllocationGroupId(urldecode($id1))->filterByRevenueTypeCategoryId(urldecode($id2))->filterByMonth($id3)->filterByYear($id4)->delete();
            $sql = "DELETE FROM `schedule_disbursement` WHERE beneficiary_cat_allocation_group_id = ? AND revenue_type_category_id = ? AND `month`=? AND `year`= ?";

            $stmt = $this->con->prepare($sql);
            $stmt->bindValue(1, $id1);
            $stmt->bindValue(2, $id2);
            $stmt->bindValue(3, $id3);
            $stmt->bindValue(4, $id4);

            $result = $stmt->execute();


//            \Base\BeneficiaryIndexQuery::create()->filterByBeneficiaryCatAllocationGroupId(filterByBeneficiaryCatAllocationGroupId)->delete();
            $this->con->commit();
            return $result;
        } else {
            $this->con->rollBack();
            throw new RuntimeException("Sorry Schedule can no longer be deleted");
        }
    }

    public function deleteDisbursement($id1, $id2, $id3, $id4, $id5, $id6) {
        $today = (strtotime('today'));
        $date_of_record = (strtotime("$id4-$id3-01"));

        $duration = ($today - $date_of_record) / 86400;

        if ($duration <= MAX_DAYS_FOR_DELETE) {
            $this->con->beginTransaction();
            $result = ScheduleQuery::create()->filterByBeneficiaryCatAllocationGroupId(urldecode($id1))->filterByRevenueTypeCategoryId(urldecode($id2))->filterByMonth($id3)->filterByYear($id4)->filterByPrincipleItemId($id5)->filterByBeneficiaryId(urldecode($id6))->delete();
//            \Base\BeneficiaryIndexQuery::create()->filterByBeneficiaryCatAllocationGroupId(filterByBeneficiaryCatAllocationGroupId)->delete();
            $this->con->commit();
            return $result;
        } else {
            $this->con->rollBack();
            throw new RuntimeException("Sorry disbursement can no longer be deleted");
        }
    }

    public function delete($id) {
        /** @var schedule $schedule */
        $schedule = $this->findBy('BeneficiaryId', $id);
        $schedule->delete();
    }

    private function fetchRevenue($revenue_type_id, $month, $year) {
        $revenue = RevenueQuery::create()
                ->filterByRevenueTypeId($revenue_type_id)
                ->filterByMonth($month)
                ->filterByYear($year)
                ->findOne();
        return $revenue;
    }

    private function findBy($columnName, $pk) {
        $schedule = ScheduleQuery::create()->findBy($columnName, $pk);
        return $schedule;
    }

    public function findAll($page = 1, $count = 10) {
        $schedules = ScheduleQuery::create()->select('*  ')->paginate($page, $count);
        return $schedules;
    }

    public function revenueDisbursementGrid() {

        /*
         * DataTables example server-side processing script.
         *
         * Please note that this script is intentionally extremely simply to show how
         * server-side processing can be implemented, and probably shouldn't be used as
         * the basis for a large complex system. It is suitable for simple use cases as
         * for learning.
         *
         * See http://datatables.net/usage/server-side for full details on the server-
         * side processing requirements of DataTables.
         *
         * @license MIT - http://datatables.net/license_mit
         */

        /*         * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
         * Easy set variables
         */
        require_once (dirname(dirname(dirname(dirname(dirname(__FILE__))))) . DIRECTORY_SEPARATOR . "generated-conf/db.properties.php");


        error_reporting(E_ERROR);
// DB table to use
        $table = 'schedule';

// Table's primary key
        $primaryKey = 'beneficiary_id';

// Array of database columns which should be read and sent back to DataTables.
// The `db` parameter represents the column name in the database, while the `dt`
// parameter represents the DataTables column identifier. In this case simple
// indexes

        $columns = array(
//    array('db' => 'revenue_type_category_id', 'dt' => 'revenue_type_category_id'),
            array('db' => 'beneficiary_id', 'dt' => 'beneficiary_id')
            , array('db' => 'beneficiary_category_id', 'dt' => 'beneficiary_category_id')
            , array('db' => 'principle_item_id', 'dt' => 'principle_item_id')
            , array('db' => 'principle_item_name', 'dt' => 'principle_item_name')
            , array('db' => 'beneficiary_cat_allocation_group_id', 'dt' => 'beneficiary_cat_allocation_group_id')
            , array('db' => 'revenue_type_category_id', 'dt' => 'revenue_type_category_id')
            , array('db' => 'Index', 'dt' => 'Index')
            , array('db' => 'allocated_value', 'dt' => 'allocated_value')
            , array('db' => 'disbursed_value', 'dt' => 'disbursed_value')
            , array('db' => 'month', 'dt' => 'month')
            , array('db' => 'year', 'dt' => 'year')
            , array('db' => 'date_created', 'dt' => 'date_created')
            , array('db' => 'created_by', 'dt' => 'created_by')
            , array('db' => 'date_modified', 'dt' => 'date_modified')
            , array('db' => 'modified_by', 'dt' => 'modified_by')
        );

// SQL server connection information
        $sql_details = array(
            'user' => DB_USERNAME,
            'pass' => DB_PASSWORD,
            'db' => DATABASE_NAME,
            'host' => DATABASE_HOST
        );
//        var_dump($sql_details);

        /*         * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
         * If you just want to use the basic configuration for DataTables with PHP
         * server-side, there is no need to edit below this line.
         */
//$query = 'SELECT SQL_CACHE SQL_CALC_FOUND_ROWS
// *
//FROM schedule ';

        $beneficiary_cat_allocation_group_id = isset($_REQUEST['beneficiary_cat_allocation_group_id']) ? $_REQUEST['beneficiary_cat_allocation_group_id'] : '';
        $beneficiary_category_id = isset($_REQUEST['beneficiary_category_id']) ? $_REQUEST['beneficiary_category_id'] : '';
        $revenue_type_category_id = isset($_REQUEST['revenue_type_category_id']) ? $_REQUEST['revenue_type_category_id'] : '';
        $month = isset($_REQUEST['month']) ? $_REQUEST['month'] : '';
        $year = isset($_REQUEST['year']) ? $_REQUEST['year'] : '';

        $query = "SELECT SQL_CACHE SQL_CALC_FOUND_ROWS
  schedule.beneficiary_id,
  beneficiary.beneficiary_category_id,
  principle_item.principle_item_id,
  principle_item.principle_item_name,
  schedule.beneficiary_cat_allocation_group_id,
  schedule.revenue_type_category_id,
  beneficiary_index.Index,
  schedule.allocated_value,
  schedule.disbursed_value,
  schedule.month,
  schedule.year,
  schedule.date_created,
  schedule.created_by,
  schedule.date_modified,
  schedule.modified_by
FROM SCHEDULE
  JOIN beneficiary_index
    ON schedule.beneficiary_cat_allocation_group_id = beneficiary_index.beneficiary_cat_allocation_group_id
  JOIN beneficiary
    ON beneficiary.beneficiary_id = beneficiary_index.beneficiary_id
  join principle_item
    on principle_item.principle_item_id = beneficiary_index.principle_item_id
      AND schedule.beneficiary_id = beneficiary_index.beneficiary_id
      AND schedule.principle_item_id = beneficiary_index.principle_item_id
WHERE beneficiary_index.beneficiary_cat_allocation_group_id = '$beneficiary_cat_allocation_group_id'
    AND principle_item.beneficiary_category_id = '$beneficiary_category_id'
    AND `schedule`.revenue_type_category_id = '$revenue_type_category_id'
    AND `schedule`.`month` = '$month'
    AND `schedule`.`year` = '$year'";

//        require_once (dirname(dirname(dirname(dirname(__FILE__)))) . DIRECTORY_SEPARATOR . 'Common/Utilities/ssp.class.php' );
        echo "kop";
//        var_dump(dirname(dirname(dirname(dirname(__FILE__)))) . DIRECTORY_SEPARATOR . 'Common/Utilities/ssp.class.php' );
        return
                ScheduleRepository::complex2($_POST, $sql_details, $table, $primaryKey, $columns, $query)
        ;
    }

}
