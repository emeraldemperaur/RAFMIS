<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/8/2015
 * Time: 12:12 AM
 */

namespace Rafmis\RevenueConfigurationModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\RevenueConfigurationModule\Repository\RevenueAllocationRepository;

class RevenueAllocationController extends BaseController {

    const REPOSITORY_NAME = 'revenue_allocation_repository';

    public function all($page = 1, $count = 10) {
        /** @var RevenueAllocationRepository $revenueAllocationRepository */
        $revenueAllocationRepository = $this->getRepository(self::REVENUE_ALLOCATION_REPOSITORY);
        $revenueAllocationRepository->findAll($page, $count);
    }

    public function create() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['date_created'] = date('Y-m-d H:i:s');
        $request['created_by'] = $this->getCurrentUser();

        /** @var RevenueAllocationRepository $revenueAllocationRepository */
        $revenueAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);

        if ($revenueAllocationRepository->save($request)) {
            echo 'A new revenue type has been added to the system';
        } else {
            echo 'Something went wrong!';
        }
    }

    public function show($revenueTypeCategoryId, $beneficiaryCatAllocationGroupId) {
        /** @var RevenueAllocationRepository $revenueAllocationRepository */
        $revenueAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueType = $revenueAllocationRepository->findOne($revenueTypeCategoryId, $beneficiaryCatAllocationGroupId);

            echo $revenueType->exportTo('JSON');
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function update() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['date_modified'] = date('Y-m-d H:i:s');
        $request['modified_by'] = $this->getCurrentUser();
        /** @var RevenueAllocationRepository $revenueAllocationRepository */
        $revenueAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueAllocationRepository->save($request);
            echo 'The selected revenue type was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($revenueTypeCategoryId, $beneficiaryCatAllocationGroupId) {
        /** @var RevenueAllocationRepository $revenueAllocationRepository */
        $revenueAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueAllocationRepository->deleteRevenueAllocation($revenueTypeCategoryId, $beneficiaryCatAllocationGroupId);
            echo 'The selected Revenue was successfully deleted';
        } catch (EntityNotFoundException $e) {
//			$this->app->response->setStatus(404);
//			$this->createNotFoundException($e->getMessage());
        }
    }
    
//    public function deleteTwo() {
//        $request = json_decode($this->app->request->getBody(), true);
//        var_dump($request);
//        /** @var RevenueAllocationRepository $revenueAllocationRepository */
////        $revenueAllocationRepository = $this->getRepository(self::REPOSITORY_NAME);
////
//        try {
////            $revenueAllocationRepository->deleteRevenueAllocation($revenueTypeCategoryId, $beneficiaryCatAllocationGroupId);
////            echo 'The selected Revenue was successfully deleted';
//        } catch (EntityNotFoundException $e) {
////			$this->app->response->setStatus(404);
////			$this->createNotFoundException($e->getMessage());
//        }
//    }

}
