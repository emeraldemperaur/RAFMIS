<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/2/2015
 * Time: 12:41 AM
 */

namespace Rafmis\RevenueConfigurationModule\Controllers;

use Common\BaseController;
use Common\Exception\HttpNotFoundException;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\RevenueConfigurationModule\Repository\RevenueTypeCategoryRepository;

class RevenueTypeCategoryController extends BaseController {

    const REPOSITORY_NAME = 'revenue_type_category_repository';

    public function all($page = 1, $count = 10) {
        /** @var RevenueTypeCategoryRepository $revenueTypeCategoryRepository */
        $revenueTypeCategoryRepository = $this->getRepository(self::REPOSITORY_NAME);
        $revenueTypeCategories = $revenueTypeCategoryRepository->findAll($page, $count);

        if (!count($revenueTypeCategories)) {
            echo 'No revenue types have been added.';
        } else {
            $this->app->response->header('content-type', 'application/json');
            echo $revenueTypeCategories->getResults()->toJSON(false);
        }
    }

    public function create() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['date_created'] = date('Y-m-d H:i:s');
        $request['created_by'] = $this->getCurrentUser();

        /** @var RevenueTypeCategoryRepository $revenueTypeCategoryRepository */
        $revenueTypeCategoryRepository = $this->getRepository(self::REPOSITORY_NAME);
        if ($revenueTypeCategoryRepository->save($request)) {
            echo 'A new revenue type category has been added to the system.';
        } else {
            echo 'Something went wrong!';
        }
    }

    public function assignToSuperGroup($supergroupid) {
        try {
            $request = json_decode($this->app->request->getBody(), true);
            $request = (array) $request;
            $request['date_created'] = date('Y-m-d H:i:s');
            $request['created_by'] = $this->getCurrentUser();

            /** @var RevenueTypeCategoryRepository $revenueTypeCategoryRepository */
            $revenueTypeCategoryRepository = $this->getRepository(self::REPOSITORY_NAME);
            $revenueTypeCategoryRepository->save($request);

            $superGroupRevenueTypeCategory = new \SupergroupRevenueTypeCategory();
            $superGroupRevenueTypeCategory->setRevenueTypeCategoryId($request['revenue_type_category_id']);
            $superGroupRevenueTypeCategory->setSupergroupId($supergroupid);
            $superGroupRevenueTypeCategory->setDateCreated(date('Y-m-d H:i:s'));
            $superGroupRevenueTypeCategory->setCreatedBy('');

            $superGroupRevenueTypeCategory->save();
        } catch (Exception $e) {
            throw $e;
        }
    }

    public function show($revenueTypeCategoryId) {
        /** @var RevenueTypeCategoryRepository $revenueTypeCategoryRepository */
        $revenueTypeCategoryRepository = $this->getRepository(self::REPOSITORY_NAME);
        $revenueTypeCategory = $revenueTypeCategoryRepository->findOneByRevenueTypeCategoryId($revenueTypeCategoryId);
        echo $revenueTypeCategory->exportTo('JSON');
    }

    public function update() {
        $request = json_decode($this->app->request->getBody());
        $request = (array) $request;
        $request['date_modified'] = date('Y-m-d H:i:s');
        $request['modified_by'] = $this->getCurrentUser();
        /** @var RevenueTypeCategoryRepository $revenueTypeCategoryRepository */
        $revenueTypeCategoryRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueTypeCategoryRepository->save($request);
            echo 'The selected revenue type category was successfully updated.';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function delete($revenueTypeCategoryId) {
        /** @var RevenueTypeCategoryRepository $revenueTypeCategoryRepository */
        $revenueTypeCategoryRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueTypeCategoryRepository->deleteRevenueTypeCategory($revenueTypeCategoryId);
            echo 'The selected revenue type category was successfully deleted.';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function getAssociatedRevenueType($revenueTypeCategoryId) {
        /** @var RevenueTypeCategoryRepository $revenueTypeCategoryRepository */
        $revenueTypeCategoryRepository = $this->getRepository(self::REPOSITORY_NAME);

        echo $revenueTypeCategoryRepository->getAssociatedRevenueType($revenueTypeCategoryId)->toJSON();
    }

    public function filterCsv() {
        $request = json_decode($this->app->request->getBody(), true);
        $revenueCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);
        $input_array = $revenueCollectionRepository->filterCsv($request);
        $this->create_csv($input_array, 'a.csv', ',');
    }

    function create_csv($input_array, $output_file_name, $delimiter) {
        /** open raw memory as file, no need for temp files, be careful not to run out of memory thought */
        $f = fopen('php://memory', 'w');
        /** loop through array  */
        foreach ($input_array as $line) {
            /** default php csv handler * */
            fputcsv($f, $line, $delimiter);
        }
        /** rewrind the "file" with the csv lines * */
        fseek($f, 0);
        /** modify header to be downloadable csv file * */
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
//        header("Content-Type: $type");
        header("Content-Transfer-Encoding: binary");
        header('Content-Type: application/csv');
        header('Content-Disposition: attachement; filename="' . $output_file_name . '";');
        /** Send file to browser for download */
        fpassthru($f);
    }

}
