<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/1/2015
 * Time: 4:31 PM
 */

namespace Rafmis\RevenueConfigurationModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\RevenueConfigurationModule\Repository\RevenueTypeRepository;

class RevenueTypeController extends BaseController {

    const REPOSITORY_NAME = 'revenue_type_repository';

    public function all($page = 1, $count = 10) {
        /** @var RevenueTypeRepository $revenueTypeRepository */
        $revenueTypeRepository = $this->getRepository(self::REPOSITORY_NAME);
        $revenueTypes = $revenueTypeRepository->findAll($page, $count);

        if (!count($revenueTypes)) {
            echo 'No revenue types have been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
            echo $revenueTypes->getResults()->toJSON(false);
        }
    }

    public function create() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['date_created'] = date('Y-m-d H:i:s');
        $request['created_by'] = $this->getCurrentUser();

        /** @var RevenueTypeRepository $revenueTypeRepository */
        $revenueTypeRepository = $this->getRepository(self::REPOSITORY_NAME);

        if ($revenueTypeRepository->save($request)) {
            echo 'A new revenue type has been added to the system';
        } else {
            echo 'Something went wrong!';
        }
    }

    public function assignToRevenueTypeCategory($revenueTypeCategoryId) {
        try {
            $request = json_decode($this->app->request->getBody(), true);
            $request = (array) $request;
            $request['date_created'] = date('Y-m-d H:i:s');
            $request['created_by'] = $this->getCurrentUser();

            /** @var RevenueTypeCategoryRepository $revenueTypeCategoryRepository */
            $revenueTypeCategoryRepository = $this->getRepository(self::REPOSITORY_NAME);
            $revenueTypeCategoryRepository->save($request);

            $revenueTypeCategoryGroup = new \RevenueTypeCategoryGroup();
            $revenueTypeCategoryGroup->setRevenueTypeId($request['revenue_type_id']);
            $revenueTypeCategoryGroup->setRevenueTypeCategoryId($revenueTypeCategoryId);
            $revenueTypeCategoryGroup->setDateCreated(date('Y-m-d H:i:s'));
            $revenueTypeCategoryGroup->setCreatedBy($this->getCurrentUser());

            $revenueTypeCategoryGroup->save();
        } catch (Exception $e) {
            throw $e;
        }
    }

    public function show($revenueTypeId) {
        /** @var RevenueTypeRepository $revenueTypeRepository */
        $revenueTypeRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueType = $revenueTypeRepository->findOneByRevenueTypeId($revenueTypeId);

            echo $revenueType->exportTo('JSON');
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function update() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['date_modified'] = date('Y-m-d H:i:s');
        $request['modified_by'] = $this->getCurrentUser();

        /** @var RevenueTypeRepository $revenueTypeRepository */
        $revenueTypeRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueTypeRepository->save($request);
            echo 'The selected revenue type was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($revenueTypeId) {
        /** @var RevenueTypeRepository $revenueTypeRepository */
        $revenueTypeRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueTypeRepository->deleteRevenueType($revenueTypeId);
            echo 'The selected Revenue was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function filterCsv() {
        $request = json_decode($this->app->request->getBody(), true);
        $revenueCollectionRepository = $this->getRepository(self::REPOSITORY_NAME);
        $input_array = $revenueCollectionRepository->filterCsv($request);
        $this->create_csv($input_array, 'a.csv', ',');
    }

    function create_csv($input_array, $output_file_name, $delimiter) {
        /** open raw memory as file, no need for temp files, be careful not to run out of memory thought */
        $f = fopen('php://memory', 'w');
        /** loop through array  */
        foreach ($input_array as $line) {
            /** default php csv handler * */
            fputcsv($f, $line, $delimiter);
        }
        /** rewrind the "file" with the csv lines * */
        fseek($f, 0);
        /** modify header to be downloadable csv file * */
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
//        header("Content-Type: $type");
        header("Content-Transfer-Encoding: binary");
        header('Content-Type: application/csv');
        header('Content-Disposition: attachement; filename="' . $output_file_name . '";');
        /** Send file to browser for download */
        fpassthru($f);
    }

}
