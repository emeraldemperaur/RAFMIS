<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/1/2015
 * Time: 4:31 PM
 */

namespace Rafmis\RevenueConfigurationModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\RevenueConfigurationModule\Repository\RevenueRepository;

class RevenueController extends BaseController {

    const REPOSITORY_NAME = 'revenue_repository';

    public function all() {
        $request = $this->app->request->get();

        if (count($request)) {
            $columns = array(
                'revenue_type_id',
                'month',
                'year',
                'amount'
            );
            $revenues = $this->tableData->get('revenue', 'revenue_type_id', $columns);
        } else {
            /** @var RevenueRepository $revenueRepository */
            $revenueRepository = $this->getRepository(self::REPOSITORY_NAME);
            $revenues = $revenueRepository->findAll();
        }

        if (!count($revenues)) {
            echo 'No revenue types have been added';
        } else if (count($request)) {
            echo json_encode($revenues);
        } else {
            $this->app->response->header('content-type', 'application/json');
            echo $revenues->toJSON(false);
        }
    }

    public function create() {
        $request = json_decode($this->app->request->getBody(), true);
        $request = (array) $request;
        $request['username'] = $this->getCurrentUser();
        /** @var RevenueRepository $revenueRepository */
        $revenueRepository = $this->getRepository(self::REPOSITORY_NAME);

        if ($revenueRepository->save($request)) {
            echo 'A new revenue type has been added to the system';
        } else {
            echo 'Something went wrong!';
        }
    }

    public function show($revenueTypeId, $year, $month) {
        /** @var RevenueRepository $revenueRepository */
        $revenueRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueType = $revenueRepository->findOne($revenueTypeId, $year, $month);

            echo $revenueType->exportTo('JSON');
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function update() {
        $request = json_decode($this->app->request->getBody(), true);

        /** @var RevenueRepository $revenueRepository */
        $revenueRepository = $this->getRepository(self::REPOSITORY_NAME);
        $request['username'] = $this->getCurrentUser();

        try {
            $revenueRepository->save($request);
            echo 'The selected revenue type was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($revenueTypeId, $year, $month) {
        /** @var RevenueRepository $revenueRepository */
        $revenueRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $revenueRepository->deleteRevenue($revenueTypeId, $year, $month);
            echo 'The selected Revenue was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function monthlyRevenue()
    {
        $year = $this->app->request->get('year');

        /** @var RevenueRepository $revenueRepository */
        $revenueRepository = $this->getRepository(self::REPOSITORY_NAME);

        $revenues = $revenueRepository->monthlyRevenue($year);

        echo $revenues->toJSON();
    }
}
