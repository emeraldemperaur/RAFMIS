<?php
/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/1/2015
 * Time: 4:57 PM
 */

namespace Rafmis\RevenueConfigurationModule;


use Rafmis\RevenueConfigurationModule\Repository\RevenueTypeCategoryRepository;
use Rafmis\RevenueConfigurationModule\Repository\RevenueTypeRepository;
use Rafmis\RevenueConfigurationModule\Repository\SuperGroupRepository;
use Rafmis\RevenueConfigurationModule\Repository\RevenueRepository;
use Slim\Slim;

class RevenueConfigurationModule {

	public function register(Slim $app)
	{
		$app->container->singleton('revenue_type_repository', function () use ($app) {
			return new RevenueTypeRepository($app);
		});

		$app->container->singleton('revenue_type_category_repository', function () use ($app) {
			return new RevenueTypeCategoryRepository();
		});

		$app->container->singleton('super_group_repository', function () use ($app) {
		  	return new SuperGroupRepository($app);
		});

		$app->container->singleton('revenue_repository', function () use ($app) {
		  	return new RevenueRepository($app);
		});

		$app->container->singleton('revenue_allocation_repository', function () use ($app) {
			return new RevenueAllocationRepository($app);
		});
	}
}