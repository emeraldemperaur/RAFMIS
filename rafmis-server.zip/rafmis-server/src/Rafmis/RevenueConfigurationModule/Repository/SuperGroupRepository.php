<?php

namespace Rafmis\RevenueConfigurationModule\Repository;

use Propel\Runtime\Propel;
use Propel\Runtime\Exception\EntityNotFoundException;
use Supergroup;
use SupergroupQuery;
use Slim\Slim;

class SupergroupRepository { /** * @var Slim	 */

    private $app;/**     * @var Supergroup	 */
    private $supergroup;/**     * @param Slim $app	 */

    /**
     * * @var Connectiom	 
     */
    private $con;

    public function __construct(Slim $app) {
        $this->con = Propel::getConnection();
        $this->app = $app;
        $this->supergroup = new Supergroup();
        return $this;
    }

    /**
     * * @param array $data	
     *  * @return int The number of affected rows	 
     */
    public function saveSupergroup(array $data, $mode) {
        $data['is_active'] = isset($data['is_active']) ? 1 : 0;
        $data['is_default'] = isset($data['is_default']) ? 1 : 0;

        try {
            $this->con->beginTransaction();
            if (isset($data['super_group_id']) && $mode == 'update') {
                $supergroup = $this->findSupergroupBySupergroupId($data['super_group_id']);

                $sql1 = 'UPDATE supergroup SET is_default = ?';
                $stmt1 = $this->con->prepare($sql1);
                $stmt1->bindValue(1, 0);
                $stmt1->execute();
            } else {
                $supergroup = $this->supergroup;
            }
            /* sets all required properties of the supergroup */
            $supergroup->setSupergroupId($data['super_group_id']);
            $supergroup->setDescription($data['description']);
            $supergroup->setIsActive($data['is_active']);
            $supergroup->setIsDefault($data['is_default']);

            $supergroup->setDateCreated($mode === 'create' ? date('Y-m-d H:i:s') : $supergroup->getDateCreated());
            $supergroup->setCreatedBy($mode === 'create' ? $data['created_by'] : $supergroup->getCreatedBy());
            $supergroup->setDateModified($mode === 'update' ? date('Y-m-d H:i:s') : $supergroup->getDateModified());
            $supergroup->setModifiedBy($mode === 'update' ? $data['modified_by'] : $supergroup->getModifiedBy());
            $result = $supergroup->save();
            $this->con->commit();
            return $result;
        } catch (Exception $e) {
            $this->con->rollBack();
        }
    }

    /**     * @param(s) $supergroupId	 *	 * @return array|mixed|Supergroup finds a Supergroup by its id(s)	 *	 * finds a Supergroup by its id(s)	 */
    public function findSupergroupBySupergroupId($supergroupId) {
        $supergroup = SupergroupQuery::create()->findOneBySupergroupId($supergroupId);
//        if (!$supergroup) {
//            throw new EntityNotFoundException('Entity not found.');
//        } 
        return $supergroup;
    }

    /**     * @param(s) $supergroupId	 *	 * @return mixed	 */
    public function deleteSupergroup($supergroupId) { /** @var Supergroup $supergroup */
        $supergroup = $this->findSupergroupBySupergroupId($supergroupId);
        $supergroup->delete();
    }

    public function findAll($page = 1, $count = 10) {
        $supergroups = SupergroupQuery::create()->paginate($page, $count);
        return $supergroups;
    }

    public function filterCsv($request) {
        $query = 'SELECT SQL_CACHE * FROM supergroup';

        $q = $this->con->prepare("DESCRIBE supergroup");
        $q->execute();
        $table_fields = $q->fetchAll(\PDO::FETCH_COLUMN);

        $columRefined = array_map(function($e) {
            return implode(' ', array_map(function($n) {
                        return ucwords($n);
                    }, explode('_', $e)));
        }, $table_fields);

        $stmt = $this->con->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        array_unshift($result, $columRefined);
        return $result;
    }

}
