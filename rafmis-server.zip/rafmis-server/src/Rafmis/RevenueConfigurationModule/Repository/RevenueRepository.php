<?php
/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/1/2015
 * Time: 4:16 PM
 */

namespace Rafmis\RevenueConfigurationModule\Repository;


use Map\RevenueTableMap;
use Propel\Runtime\Exception\EntityNotFoundException;
use Propel\Runtime\Propel;
use Slim\Slim;

/**
 * Class RevenueTypeRepository
 * @package Rafmis\RevenueConfigurationModule\Repository
 */
class RevenueRepository {

	/**
	 * @var Slim
	 */
	private $app;

	/**
	 * @var \Revenue
	 */
	private $revenue;

	/**
	 * @var \RevenueQuery
	 */
	private $revenueQuery;

	/**
	 * @param Slim $app
	 */
	public function __construct(Slim $app)
	{
		$this->app = $app;
		$this->revenue = new \Revenue();
		$this->revenueQuery = \RevenueQuery::create();
	}

	/**
	 * @param array $data
	 *
	 * @return int
	 * @throws \Propel\Runtime\Exception\PropelException
	 */
	public function save(array $data)
	{
		$revenue = $this->revenueQuery
			->filterByRevenueTypeId($data['RevenueTypeId'])
			->filterByMonth($data['Month'])
			->filterByYear($data['Year'])
			->findOne();

		if (!$revenue) {
			$revenue = $this->revenue;
			$revenue->setCreatedBy($data['username']);
			$revenue->setDateCreated(new \DateTime());
		} else {
			$revenue->setDateModified(new \DateTime());
			$revenue->setModifiedBy($data['username']);
		}

		$revenue->setRevenueTypeId($data['RevenueTypeId']);
		$revenue->setMonth($data['Month']);
		$revenue->setYear($data['Year']);
        $revenue->setAmount($data['Amount']);

		return $revenue->save();
	}

	/**
	 * @param $revenueTypeId
	 * @param $year
	 * @param $month
	 *
	 * @throws \Propel\Runtime\Exception\PropelException
	 */
	public function deleteRevenue($revenueTypeId, $year, $month)
	{
		/** @var \Revenue $revenue */
		$revenue = $this->revenueQuery->filterByPks($revenueTypeId, $year, $month)->findOne();
		$revenue->delete();
	}

	/**
	 * @param $revenueTypeId
	 * @param $year
	 * @param $month
	 *
	 * @return \RevenueType
	 */
	public function findOne($revenueTypeId, $year, $month)
	{
		$revenue = $this->revenueQuery->filterByPks($revenueTypeId, $month, $year)->findOne();

		if (!$revenue) {
			throw new EntityNotFoundException('Record Not Found.');
		}

		return $revenue;
	}

    /**
     * @param $page
     * @param $count
     * @return \Propel\Runtime\Util\PropelModelPager|\Revenue[]
     */
    public function findAll()
    {
        return \RevenueQuery::create('Revenue')
            ->setFormatter('\Propel\Runtime\Formatter\ArrayFormatter')
            ->find();
    }

    public function monthlyRevenue($year)
    {
        return $this->revenueQuery->withColumn('sum(amount)', 'monthlyAmount')
            ->select(array('month'))
            ->filterByYear($year)
            ->groupByMonth()
            ->find();
    }
}