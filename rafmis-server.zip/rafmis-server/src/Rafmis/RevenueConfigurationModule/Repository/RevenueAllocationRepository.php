<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/1/2015
 * Time: 4:16 PM
 */

namespace Rafmis\RevenueConfigurationModule\Repository;

use Base\RevenueType;
use Propel\Runtime\Exception\EntityNotFoundException;
use Slim\Slim;

/**
 * Class RevenueTypeRepository
 * @package Rafmis\RevenueConfigurationModule\Repository
 */
class RevenueAllocationRepository {

    /**
     * @var Slim
     */
    private $app;

    /**
     * @var \RevenueAllocation
     */
    private $revenueAllocation;

    /**
     * @var \RevenueAllocationQuery
     */
    private $revenueAllocationQuery;

    /**
     * @param Slim $app
     */
    public function __construct(Slim $app) {
        $this->app = $app;
        $this->revenueAllocation = new \RevenueAllocation();
        $this->revenueAllocationQuery = \RevenueAllocationQuery::create();
    }

    /**
     * @param array $data
     *
     * @return int
     * @throws \Propel\Runtime\Exception\PropelException
     */
    public function save(array $data) {
        $revenueAllocation = $this->revenueAllocationQuery
                ->filterByRevenueTypeCategoryId($data['revenue_type_category_id'])
                ->filterByBeneficiaryCatAllocationGroupId($data['beneficiary_cat_allocation_group_id'])
                ->findOne();

        if (!$revenueAllocation) {
            $revenueAllocation = $this->revenueAllocation;
            $revenueAllocation->setCreatedBy($data['created_by']);
            $revenueAllocation->setDateCreated(new \DateTime());
        } else {
            $revenueAllocation->setDateModified(new \DateTime());
            $revenueAllocation->setModifiedBy($data['modified_by']);
        }

        $revenueAllocation->setRevenueTypeCategoryId($data['revenue_type_category_id']);
        $revenueAllocation->setBeneficiaryCatAllocationGroupId($data['beneficiary_cat_allocation_group_id']);

        return $revenueAllocation->save();
    }

    /**
     * @param $revenueTypeCategoryId
     *
     * @param $beneficiaryCatAllocationGroupId
     *
     * @throws \Propel\Runtime\Exception\PropelException
     */
    public function deleteRevenueAllocation($revenueTypeCategoryId, $beneficiaryCatAllocationGroupId) {
        /** @var RevenueType $revenueType */
        $revenueType = $this->findOne($revenueTypeCategoryId, $beneficiaryCatAllocationGroupId);
        $revenueType->delete();
    }

    /**
     * @param $revenueTypeCategoryId
     * @param $beneficiaryCatAllocationGroupId
     *
     * @return \RevenueAllocation
     */
    public function findOne($revenueTypeCategoryId, $beneficiaryCatAllocationGroupId) {
        $RevenueAllocation = $this->revenueAllocationQuery->filterByRevenueTypeCategoryId($revenueTypeCategoryId)
                ->filterByBeneficiaryCatAllocationGroupId($beneficiaryCatAllocationGroupId);

        if (!$RevenueAllocation) {
            throw new EntityNotFoundException('Record Not Found.');
        }

        return $RevenueAllocation;
    }

    /**
     * @param int $page
     * @param int $count
     *
     * @return \Propel\Runtime\Util\PropelModelPager|\RevenueAllocation[]
     */
    public function findAll($page = 1, $count = 10) {
        $revenueAllocation = $this->revenueAllocationQuery->paginate($page, $count);

        return $revenueAllocation;
    }

}
