<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/1/2015
 * Time: 4:16 PM
 */

namespace Rafmis\RevenueConfigurationModule\Repository;

use Propel\Runtime\Propel;
use Base\RevenueType;
use Propel\Runtime\Exception\EntityNotFoundException;
use Slim\Slim;

/**
 * Class RevenueTypeRepository
 * @package Rafmis\RevenueConfigurationModule\Repository
 */
class RevenueTypeRepository {

    /**
     * @var Slim
     */
    private $app;

    /**
     * @var \RevenueType
     */
    private $revenueType;

    /**
     * @var \RevenueTypeQuery
     */
    private $revenueTypeQuery;

    /**
     * * @var Connectiom	 
     */
    private $con;

    /**
     * @param Slim $app
     */
    public function __construct(Slim $app) {
        $this->con = Propel::getConnection();
        $this->app = $app;
        $this->revenueType = new \RevenueType();
        $this->revenueTypeQuery = \RevenueTypeQuery::create();
    }

    /**
     * @param array $data
     *
     * @return int
     * @throws \Propel\Runtime\Exception\PropelException
     */
    public function save(array $data) {
        $revenueType = $this->revenueTypeQuery->findOneByRevenueTypeId($data['revenue_type_id']);

        if (!$revenueType) {
            $revenueType = $this->revenueType;
            $revenueType->setDateCreated(new \DateTime());
            $revenueType->setCreatedBy($data['created_by']);
        } else {
            $revenueType->setDateModified(new \DateTime());
            $revenueType->setModifiedBy($data['modified_by']);
        }

        $revenueType->setRevenueTypeId($data['revenue_type_id']);
        $revenueType->setDescription($data['description']);

        return $revenueType->save();
    }

    /**
     * @param $revenueTypeId
     *
     * @throws \Propel\Runtime\Exception\PropelException
     */
    public function deleteRevenueType($revenueTypeId) {
        /** @var RevenueType $revenueType */
        $revenueType = $this->findOneByRevenueTypeId($revenueTypeId);
        $revenueType->delete();
    }

    /**
     * @param $revenue_type_id
     *
     * @return \RevenueType
     */
    public function findOneByRevenueTypeId($revenue_type_id) {
        $revenueType = $this->revenueTypeQuery->findOneByRevenueTypeId($revenue_type_id);

        if (!$revenueType) {
            throw new EntityNotFoundException('Record Not Found.');
        }

        return $revenueType;
    }

    /**
     * @param int $page
     * @param int $count
     *
     * @return \Propel\Runtime\Util\PropelModelPager|\RevenueType[]
     */
    public function findAll($page = 1, $count = 10) {
        $revenueTypes = $this->revenueTypeQuery->paginate($page, $count);

        return $revenueTypes;
    }

    public function filterCsv($request) {
        $revenueTypeCategotyId = $request['revenue_type_category_id'];
        $query = "SELECT SQL_CACHE SQL_CALC_FOUND_ROWS
  revenue_type.*
FROM revenue_type
  JOIN revenue_type_category_group
    ON revenue_type_category_group.revenue_type_id= revenue_type.revenue_type_id
WHERE revenue_type_category_group.revenue_type_category_id = '$revenueTypeCategotyId'";

        $q = $this->con->prepare("DESCRIBE revenue_type");
        $q->execute();
        $table_fields = $q->fetchAll(\PDO::FETCH_COLUMN);

        $columRefined = array_map(function($e) {
            return implode(' ', array_map(function($n) {
                        return ucwords($n);
                    }, explode('_', $e)));
        }, $table_fields);

        $stmt = $this->con->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        array_unshift($result, $columRefined);
        return $result;
    }

}
