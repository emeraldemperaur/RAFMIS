<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/1/2015
 * Time: 9:00 PM
 */

namespace Rafmis\RevenueConfigurationModule\Repository;

use Propel\Runtime\Propel;
use Propel\Runtime\Exception\EntityNotFoundException;
use Slim\Slim;

class RevenueTypeCategoryRepository {

    private $app;
    private $revenueTypeCategory;
    private $revenueTypeCategoryQuery;

    /**
     * * @var Connectiom	 
     */
    private $con;

    public function __construct() {
        $this->con = Propel::getConnection();
        $this->app = Slim::getInstance();
        $this->revenueTypeCategory = new \RevenueTypeCategory();
        $this->revenueTypeCategoryQuery = \RevenueTypeCategoryQuery::create();
    }

    public function save($data) {
        $data = (array) $data;
        $revenueTypeCategory = $this->revenueTypeCategoryQuery->findOneByRevenueTypeCategoryId
                ($data['revenue_type_category_id']);

        if (!$revenueTypeCategory) {
            $revenueTypeCategory = $this->revenueTypeCategory;
            $revenueTypeCategory->setDateCreated(new \DateTime());
            $revenueTypeCategory->setCreatedBy($data['created_by']);
        } else {
            $revenueTypeCategory->setDateModified(new \DateTime());
            $revenueTypeCategory->setModifiedBy($data['modified_by']);
        }

        $revenueTypeCategory->setRevenueTypeCategoryId($data['revenue_type_category_id']);
        $revenueTypeCategory->setDescription($data['description']);

        if (array_key_exists('revenue_types', $data)) {
            array_map(function ($revenueType) use ($revenueTypeCategory) {
                $revenueTypeCategoryGroup = new \RevenueTypeCategoryGroup();
                $revenueTypeCategoryGroup->setRevenueTypeId($revenueType['revenue_type_id']);
                $revenueTypeCategoryGroup->setDateCreated(new \DateTime());
                $revenueTypeCategoryGroup->setCreatedBy(1);

                $revenueTypeCategory->addRevenueTypeCategoryGroup($revenueTypeCategoryGroup);
            }, $data['revenue_types']);
        }

        return $revenueTypeCategory->save();
    }

    public function findAll($page, $count) {
        $revenueTypeCategories = $this->revenueTypeCategoryQuery->paginate($page, $count);
        return $revenueTypeCategories;
    }

    public function findOneByRevenueTypeCategoryId($revenueTypeCategoryId) {
        $revenueTypeCategory = $this->revenueTypeCategoryQuery->filterByRevenueTypeCategoryId($revenueTypeCategoryId)
                ->find();

        if (!$revenueTypeCategory) {
            throw new EntityNotFoundException('Revenue type category not found');
        }

        return $revenueTypeCategory;
    }

    public function deleteRevenueTypeCategory($revenueTypeCategoryId) {
        $revenueTypeCategory = $this->revenueTypeCategoryQuery->findOneByRevenueTypeCategoryId($revenueTypeCategoryId);
        $revenueTypeCategory->delete();
    }

    public function getAssociatedRevenueType($revenueTypeCategoryId) {
        $revenueTypeCategoryGroup = $this->revenueTypeCategoryQuery->useRevenueTypeCategoryGroupQuery();

        return $revenueTypeCategoryGroup->filterByRevenueTypeCategoryId($revenueTypeCategoryId)->useRevenueTypeQuery()
                        ->find();
    }

    public function filterCsv($request) {
//        var_dump($request);
//        die();
        $superGroupId = $request['supergroup_id'];
        $query = "SELECT SQL_CACHE SQL_CALC_FOUND_ROWS
  revenue_type_category.*
FROM revenue_type_category
  JOIN supergroup_revenue_type_category
    ON supergroup_revenue_type_category.revenue_type_category_id = revenue_type_category.revenue_type_category_id
WHERE supergroup_revenue_type_category.supergroup_id = '$superGroupId'";


        $q = $this->con->prepare("DESCRIBE revenue_type_category");
        $q->execute();
        $table_fields = $q->fetchAll(\PDO::FETCH_COLUMN);

        $columRefined = array_map(function($e) {
            return implode(' ', array_map(function($n) {
                        return ucwords($n);
                    }, explode('_', $e)));
        }, $table_fields);

        $stmt = $this->con->prepare($query);
        $stmt->execute();
        $result = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        array_unshift($result, $columRefined);
        return $result;
    }

}
