<?php
/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/9/2015
 * Time: 5:36 PM
 */

namespace Rafmis\UserManagementModule\Middleware;


use Common\Exception\BadCredentials;
use Common\Exception\SessionTimeoutException;
use Rafmis\UserManagementModule\Repository\SessionTokenRepository;
use Rafmis\UserManagementModule\Services\SessionManager;
use Slim\Middleware;

/**
 * Class AuthenticationMiddleware
 * @package Rafmis\UserManagementModule\Middleware
 */
class TokenAuthenticatorMiddleware extends Middleware{

	/**
	 * @var
	 */
	private $sessionManager;

	/**
	 * @param SessionManager $sessionManager
	 */
	public function __construct(SessionManager $sessionManager)
	{
		$this->sessionManager = $sessionManager;
	}

	/**
	 * Call
	 *
	 * Perform actions specific to this middleware and optionally
	 * call the next downstream middleware.
	 */
	public function call()
	{
		// instance of slim
		$app = $this->app;

		$token = $app->request->headers->get('Authorization');

		if ($app->request->getResourceUri() === '/auth/login' && strlen($app->response->getBody()) === 0) {
			$this->next->call();

			return;
		}

		if (preg_match('/send-password/', $this->app->request->getResourceUri())) {
			$this->next->call();

			return;
		}

		if (preg_match('/activitylog/', $this->app->request->getResourceUri())) {
			$this->next->call();

			return;
		}

		try {
			$this->sessionManager->verifySessionToken($token);
		} catch (SessionTimeoutException $e) {
			$app->response->setStatus(401);
			$app->response->setBody('Session Timeout');

			return;
		} catch (BadCredentials $e) {
			$app->response->setStatus(401);
			$app->response->setBody('Invalid Authentication Credentials.');

			return;
		}

		$this->next->call();
	}
}
