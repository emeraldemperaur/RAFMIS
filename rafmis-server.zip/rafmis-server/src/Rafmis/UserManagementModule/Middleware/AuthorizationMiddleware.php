<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/10/2015
 * Time: 4:02 PM
 */

namespace Rafmis\UserManagementModule\Middleware;

use Common\Exception\AccessDeniedException;
use Common\Exception\HttpNotFoundException;
use Rafmis\UserManagementModule\Services\SessionManager;
use ActivityLog;
use Slim\Middleware;
use Slim\Slim;

class AuthorizationMiddleware extends Middleware {

    private $sessionManager;

    public function __construct(SessionManager $sessionManager) {
        $this->sessionManager = $sessionManager;
    }

    private function onRouteMatch() {
        $matchedRoutes = $this->app->router->getMatchedRoutes(
                $this->app->request->getMethod(), $this->app->request->getResourceUri()
        );

        $token = $token = $this->app->request->headers->get('Authorization');

        if (count($matchedRoutes)) {
            $controllerObject = $matchedRoutes[0]->getCallable()[0];
            $namespace = get_class($controllerObject);
            $namespaceComponent = explode('\\', $namespace);
            $class = end($namespaceComponent);
            $allowedPrivilege = strtoupper('pri_' . str_ireplace('controller', '', $class) . '_'
                    . $matchedRoutes[0]->getCallable()[1]);

            $userPrivileges = $this->sessionManager->getCurrentUserPrivileges($token)->toArray();

            $isGranted = false;
            $privilegesDescription = array_map(function($userPrivilege) {
                return trim($userPrivilege['Priviledge']['PrivilegeName']);
            }, $userPrivileges);
            $privileges = array_map(function($userPrivilege) {
                return trim($userPrivilege['PrivilegeId']);
            }, $userPrivileges);
            $combined=  array_combine($privileges, $privilegesDescription);
            $username=$this->app->container->get('security_manager')->getCurrentUsername();
            
            if (in_array($allowedPrivilege, $privileges)) {
                $desription=$combined[$allowedPrivilege];
                
                $activityLog=new ActivityLog();
                $activityLog->setActivityType($allowedPrivilege);
                $activityLog->setDetails($desription);
                $activityLog->setUsername($username);
                $activityLog->setDateOfActivity(date('Y-m-d H:i:s'));
                $activityLog->setDateCreated(date('Y-m-d H:i:s'));
                $activityLog->setCreatedBy($username);
                $activityLog->save();
                $isGranted = true;
            }
            return $isGranted;
        }

        $this->next->call();
    }

    /**
     * Call
     *
     * Perform actions specific to this middleware and optionally
     * call the next downstream middleware.
     */
    public function call() {
        if ($this->app->request->getResourceUri() === '/auth/login' && strlen($this->app->response->getBody()) === 0) {
            $this->next->call();

            return;
        }

        if ($this->app->request->getResourceUri() === '/auth/logout') {
            $this->next->call();

            return;
        }

        if (preg_match('/send-password/', $this->app->request->getResourceUri())) {
            $this->next->call();

            return;
        }

        if (preg_match('/activitylog/', $this->app->request->getResourceUri())) {
            $this->next->call();

            return;
        }

        if ($this->app->request->getMethod() === 'GET') {
            $this->next->call();

            return;
        }

        if (!$this->onRouteMatch() && is_bool($this->onRouteMatch())) {
            $this->app->response->setStatus(403);
            $this->app->response->setBody('Access Denied');
            return;
        }

        $this->next->call();
    }

}
