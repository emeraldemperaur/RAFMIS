<?php

namespace Rafmis\UserManagementModule\Repository;

use Propel\Runtime\Exception\EntityNotFoundException;
use ActivityLog;
use ActivityLogQuery;
use Slim\Slim;

class ActivityLogRepository { /** * @var Slim	 */

    private $app;/**     * @var ActivityLog	 */
    private $activityLog;/**     * @param Slim $app	 */

    public function __construct(Slim $app) {
        $this->app = $app;
        $this->activityLog = new ActivityLog();
        return $this;
    }

    /**     * @param array $data	 * @return int The number of affected rows	 */
    public function saveActivityLog(array $data) {
        $timeStamp = date('Y-m-d H:i:s');
        $activityLog = $this->activityLog;
        /* sets all required properties of the activity_log */
        $activityLog->setActivityId(NULL);
        $activityLog->setActivityType($data['activity_type']);
        $activityLog->setDetails($data['details']);
        $activityLog->setUsername($data['username']);
        $activityLog->setDateOfActivity($timeStamp);
        $activityLog->setDateCreated($timeStamp);
        $activityLog->setCreatedBy($data['created_by']);
        $activityLog->setDateModified($data['date_modified']);
        $activityLog->setModifiedBy($data['modified_by']);
        return $this->activityLog->save();
    }

    /**     * @param(s) $activityId	 *	 * @return array|mixed|ActivityLog finds a ActivityLog by its id(s)	 *	 * finds a ActivityLog by its id(s)	 */
    public function findActivityLogByActivityId($activityId) {
        $activityLog = ActivityLogQuery::create()->findOneByActivityId($activityId);
        if (!$activityLog) {
            throw new EntityNotFoundException('Entity not found.');
        } return $activityLog;
    }

    /**     * @param(s) $activityId	 *	 * @return mixed	 */
    public function deleteActivityLog($activityId) { /** @var ActivityLog $activityLog */
        $activityLog = $this->findActivityLogByActivityId($activityId);
        $activityLog->delete();
    }

    public function findAll($page = 1, $count = 10) {
        $activityLogs = ActivityLogQuery::create()->paginate($page, $count);
        return $activityLogs;
    }

    public function findBy($criteria)
    {
        $statement = ActivityLogQuery::create();

        if (isset($criteria['ActivityType']) && $criteria['ActivityType'] !== 'undefined') {
            $statement->filterByActivityType($criteria['ActivityType']);
        }

        if (isset($criteria['Username']) && $criteria['Username'] !== 'undefined') {
            $statement->filterByUsername($criteria['Username']);
        }

        return $statement->find();
    }

}
