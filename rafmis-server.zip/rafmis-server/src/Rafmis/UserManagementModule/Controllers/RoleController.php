<?php

namespace Rafmis\UserManagementModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\UserManagementModule\Repository\PriviledgeRepository;
use Rafmis\UserManagementModule\Repository\RolePriviledgeRepository;
use Rafmis\UserManagementModule\Repository\RoleRepository;

class RoleController extends BaseController {

    const REPOSITORY_NAME = 'role_repository';

    public function all($page = 1, $count = 10) {/** @var RoleRepository $roleRepository */
        $roleRepository = $this->getRepository(self::REPOSITORY_NAME);
        $roles = $roleRepository->findAll($page, $count);
        if (!$roles->count()) {
            echo 'No role has been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
//            echo json_encode($roles);
            echo $roles->getResults()->toJSON();
        }
    }

    public function create() {
        $request = json_decode(($this->app->request->getBody()), true);
        $request['username'] = $this->getCurrentUser();
        /** @var RoleRepository $roleRepository */
        $roleRepository = $this->getRepository(self::REPOSITORY_NAME);
        $roleRepository->saveRole($request);
        echo 'Role has successfully been created';
    }

    public function show($roleId) {/** @var RoleRepository $roleRepository */
        $roleRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $role = $roleRepository->findRoleByRoleId($roleId);

            if ($role !== null && is_object($role)) {
                echo $role->exportTo('JSON');
            } else {
                throw new EntityNotFoundException('Entity not Found', 404);
            }
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function update() {
        $request = json_decode(($this->app->request->getBody()), true);
        $request['username'] = $this->getCurrentUser();
        /** @var RoleRepository $roleRepository */
        $roleRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $roleRepository->saveRole($request, 'update');
            echo 'Role was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($roleId) {
        $roleRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $roleRepository->deleteRole($roleId);
            echo 'Role was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

	public function assignPrivileges() {
		$request = json_decode($this->app->request->getBody(), true);
        $request['CreatedBy'] = $this->getCurrentUser();

		/** @var RoleRepository $roleRepository */
		$roleRepository = $this->getRepository(self::REPOSITORY_NAME);
		$role = $roleRepository->findRoleByRoleId($request['RoleId']);

		if (!$role) {
			$this->createNotFoundException('Role Not Found');
		}

		if ($roleRepository->addPrivilege($role, $request)) {
			echo 'Privileges were successfully assigned to the specified role.';
		} else {
			echo 'Something went wrong.';
		}
	}

    public function removePrivileges($roleId, $privilegeId)
    {
        /** @var RoleRepository $roleRepository */
        $roleRepository = $this->getRepository(self::REPOSITORY_NAME);
        $role = $roleRepository->findRoleByRoleId($roleId);

        /** @var RolePriviledgeRepository $privilegeRepository */
        $privilegeRepository = $this->getRepository('role_priviledge_repository');
        $rolePrivilege = $privilegeRepository->findRolePriviledgeByRoleIdPrivilegeId($roleId, $privilegeId);

        $role->removeRolePriviledge($rolePrivilege);
        $role->save();

        echo 'Privilege has been removed from role';
    }

	public function getRolePrivileges($roleId)
	{
		/** @var RoleRepository $roleRepository */
		$roleRepository = $this->getRepository(self::REPOSITORY_NAME);
		echo $roleRepository->getPrivileges($roleId)->toJSON();
	}
}
