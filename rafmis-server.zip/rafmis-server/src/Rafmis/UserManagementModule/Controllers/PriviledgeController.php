<?php

namespace Rafmis\UserManagementModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\UserManagementModule\Repository\PriviledgeRepository;

class PriviledgeController extends BaseController {

    const REPOSITORY_NAME = 'priviledge_repository';

    public function all($page = 1, $count = 10) {
		/** @var PriviledgeRepository $priviledgeRepository */
        $priviledgeRepository = $this->getRepository(self::REPOSITORY_NAME);
        $priviledges = $priviledgeRepository->findAll($page, $count);
        if (!$priviledges->count()) {
            echo 'No priviledge has been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
//            echo json_encode($priviledges);
            echo $priviledges->toJSON();
        }
    }

    public function create() {
        $request = $this->app->request->post();
        /** @var PriviledgeRepository $priviledgeRepository */
        $priviledgeRepository = $this->getRepository(self::REPOSITORY_NAME);
        $priviledgeRepository->savePriviledge($request, 'create');
        echo 'Priviledge has successfully been created';
    }

    public function show($privilegeId) {/** @var PriviledgeRepository $priviledgeRepository */
        $priviledgeRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $priviledge = $priviledgeRepository->findPriviledgeByPrivilegeId($privilegeId);

            if ($priviledge !== null && is_object($priviledge)) {
                echo $priviledge->exportTo('JSON');
            } else {
                throw new EntityNotFoundException('Entity not Found', 404);
            }
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function update() {
        $request = $this->app->request->post();
        /** @var PriviledgeRepository $priviledgeRepository */
        $priviledgeRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $priviledgeRepository->savePriviledge($request, 'update');
            echo 'Priviledge was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($privilegeId) {
        $priviledgeRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $priviledgeRepository->deletePriviledge($privilegeId);
            echo 'Priviledge was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

}
