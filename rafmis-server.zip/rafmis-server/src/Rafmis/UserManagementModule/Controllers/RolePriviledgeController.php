<?php

namespace Rafmis\UserManagementModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\PrincipleManagementModule\Repository\RolePriviledgeRepository;

class RolePriviledgeController extends BaseController {

    const REPOSITORY_NAME = 'role_priviledge_repository';

    public function all($page = 1, $count = 10) {
        /** @var RolePriviledgeRepository $rolePriviledgeRepository */
        $rolePriviledgeRepository = $this->getRepository(self::REPOSITORY_NAME);
        $rolePriviledges = $rolePriviledgeRepository->findAll($page, $count);
        if (!$rolePriviledges->count()) {
            echo 'No rolePriviledge has been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
//            echo json_encode($rolePriviledges);
            echo $rolePriviledges->getResults()->toJSON();
        }
    }

    public function create() {
        $request = $this->app->request->post();
        /** @var RolePriviledgeRepository $rolePriviledgeRepository */
        $rolePriviledgeRepository = $this->getRepository(self::REPOSITORY_NAME);
        $rolePriviledgeRepository->saveRolePriviledge($request,'create');
        echo 'RolePriviledge has successfully been created';
    }

    public function show($roleId, $privilegeId) {
        /** @var RolePriviledgeRepository $rolePriviledgeRepository */
        $rolePriviledgeRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $rolePriviledge = $rolePriviledgeRepository->findRolePriviledgeByRoleIdPrivilegeId($roleId, $privilegeId);
            
            if ($rolePriviledge !== null && is_object($rolePriviledge)) {
                echo $rolePriviledge->exportTo('JSON');
            } else {
                throw new EntityNotFoundException('Entity not Found', 404);
            }
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

//    public function update() {
//        $request = $this->app->request->post();
//        /** @var RolePriviledgeRepository $rolePriviledgeRepository */
//        $rolePriviledgeRepository = $this->getRepository(self::REPOSITORY_NAME);
//        try {
//            $rolePriviledgeRepository->saveRolePriviledge($request,'update');
//            echo 'RolePriviledge was successfully updated';
//        } catch (EntityNotFoundException $e) {
//            $this->createNotFoundException();
//        }
//    }

    public function delete($roleId, $privilegeId) {
        $rolePriviledgeRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $rolePriviledgeRepository->deleteRolePriviledge($roleId, $privilegeId);
            echo 'RolePriviledge was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

}
