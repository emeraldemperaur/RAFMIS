<?php

namespace Rafmis\UserManagementModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\PrincipleManagementModule\Repository\SessionTokenRepository;

class SessionTokenController extends BaseController {

    const REPOSITORY_NAME = 'session_token_repository';

    public function all($page = 1, $count = 10) {/** @var SessionTokenRepository $sessionTokenRepository */
        $sessionTokenRepository = $this->getRepository(self::REPOSITORY_NAME);
        $sessionTokens = $sessionTokenRepository->findAll($page, $count);
        if (!$sessionTokens->count()) {
            echo 'No sessionToken has been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
//            echo json_encode($sessionTokens);
            echo $sessionTokens->getResults()->toJSON();
        }
    }

    public function create() {
        $request = $this->app->request->post();
        /** @var SessionTokenRepository $sessionTokenRepository */
        $sessionTokenRepository = $this->getRepository(self::REPOSITORY_NAME);
        $sessionTokenRepository->saveSessionToken($request, 'create');
        echo 'SessionToken has successfully been created';
    }

    public function show($username) {
        /** @var SessionTokenRepository $sessionTokenRepository */
        $sessionTokenRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $sessionToken = $sessionTokenRepository->findSessionTokenByUsername($username);
            if ($sessionToken !== null && is_object($sessionToken)) {
                echo $sessionToken->exportTo('JSON');
            } else {
                throw new EntityNotFoundException('Entity not Found', 404);
            }
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function update() {
        $request = $this->app->request->post();
        /** @var SessionTokenRepository $sessionTokenRepository */
        $sessionTokenRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $sessionTokenRepository->saveSessionToken($request, 'update');
            echo 'SessionToken was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($username) {
        $sessionTokenRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $sessionTokenRepository->deleteSessionToken($username);
            echo 'SessionToken was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

}
