<?php

/**
 * Created by PhpStorm.
 * User: SQuaye
 * Date: 6/9/2015
 * Time: 1:20 PM
 */

namespace Rafmis\UserManagementModule\Controllers;

use Common\BaseController;
use Common\Exception\BadCredentials;
use Rafmis\UserManagementModule\Repository\AppUserRepository;
use Rafmis\UserManagementModule\Services\SecurityManager;

class SecurityController extends BaseController {

    public function login() {
        $request = json_decode($this->app->request->getBody(), true);

        /** @var SecurityManager $securityManager */
        $securityManager = $this->app->container->get('security_manager');

        try {
            $user = $securityManager->authenticate($request);

            /** @var AppUserRepository $userRepository */
            $userRepository = $this->app->container->get('app_user_repository');
            $privileges = $userRepository->getUserPrivileges($request['username'])->toArray();
            $privilegesArray = array();

            for ($i = 0; $i < count($privileges); $i++) {
                array_push($privilegesArray, $privileges[$i]['PrivilegeId']);
            }

            $user['privileges'] = $privilegesArray;
            echo json_encode($user);
        } catch (BadCredentials $e) {
            $this->createAccessDeniedException('Invalid Authentication Credentials.');
        }
    }

    public function logout() {
        $token = $this->app->request->headers->get('Authorization');

        /** @var SecurityManager $securityManager */
        $securityManager = $this->app->container->get('security_manager');

        try {
            $securityManager->logout($token);
            echo 'Account logout successfully';
        } catch (BadCredentials $e) {
			$this->createAccessDeniedException('Invalid Authentication Credentials');
        }
    }
}
