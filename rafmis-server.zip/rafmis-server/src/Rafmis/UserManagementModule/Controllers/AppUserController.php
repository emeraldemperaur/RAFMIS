<?php

namespace Rafmis\UserManagementModule\Controllers;

use Common\BaseController;
use Common\Utilities\Mailer;
use Common\Utilities\PasswordGenerator;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\UserManagementModule\Repository\AppUserRepository;
use Rafmis\UserManagementModule\Services\PasswordEncoder;

class AppUserController extends BaseController {

    const REPOSITORY_NAME = 'app_user_repository';

    public function all($page = 1, $count = 10) {/** @var AppUserRepository $appUserRepository */
        $appUserRepository = $this->getRepository(self::REPOSITORY_NAME);
        $appUsers = $appUserRepository->findAll($page, $count);
        if (!$appUsers->count()) {
            echo 'No user has been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
//            echo json_encode($appUsers);
            echo $appUsers->toJSON();
        }
    }

    public function create() {
        $request = json_decode($this->app->request->getBody(), true);

        /** @var AppUserRepository $appUserRepository */
        $appUserRepository = $this->getRepository(self::REPOSITORY_NAME);

        $request['username'] = $this->getCurrentUser();

		/** @var PasswordEncoder $encoder */
		$encoder = $this->app->container->get('encoder');
        $request['Password'] = $encoder->encodePassword($request['Password']);

        $appUserRepository->saveAppUser($request, 'create');
        echo 'User has successfully been created';
    }

    public function show($username) {
		/** @var AppUserRepository $appUserRepository */
        $appUserRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $appUser = $appUserRepository->findAppUserByUsername($username);

            if ($appUser !== null && is_object($appUser)) {
                echo $appUser->exportTo('JSON');
            } else {
                throw new EntityNotFoundException('Entity not Found', 500);
            }
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException('User Not Found');
        }
    }

	public function update() {
		$request = json_decode($this->app->request->getBody(), true);

		/** @var AppUserRepository $appUserRepository */
		$appUserRepository = $this->getRepository(self::REPOSITORY_NAME);

        $request['username'] = $this->getCurrentUser();

		try {
			$appUserRepository->saveAppUser($request, 'update');
			echo 'User was successfully updated';
		} catch (EntityNotFoundException $e) {
			$this->createNotFoundException();
		}
	}

	public function delete($username) {
		$appUserRepository = $this->getRepository(self::REPOSITORY_NAME);

		try {
			$appUserRepository->deleteAppUser($username);
			echo 'User was successfully deleted';
		} catch (EntityNotFoundException $e) {
			$this->app->response->setStatus(404);
			$this->createNotFoundException($e->getMessage());
		}
	}

    public function changePassword() {
        $request = json_decode($this->app->request->getBody(), true);

        /** @var AppUserRepository $userRepository */
        $userRepository = $this->app->container->get('app_user_repository');
        $encodedPassword = $userRepository->findAppUserByUsername($request['username'])->getPassword();

        /** @var PasswordEncoder $passwordEncoder */
        $passwordEncoder = $this->app->container->get('encoder');
        
        if ($passwordEncoder->verifyPassword($request['oldPassword'], $encodedPassword)) {
            try {
                $request['password'] = $passwordEncoder->encodePassword($request['newPassword']);
                $userRepository->updatePassword($request);
                echo 'Password changed successfully';
            } catch (EntityNotFoundException $e) {
                $this->createNotFoundException($e->getMessage());
            };
        } else {
            $this->createUnauthorisedException();
        }
    }

    public function sendPassword()
    {
        $request = json_decode($this->app->request->getBody(), true);

        /** @var AppUserRepository $userRepository */
        $userRepository = $this->getRepository('app_user_repository');

        try {
            $user = $userRepository->getUserByEmail($request['email']);

            $password = PasswordGenerator::generateStrongPassword();

            $passwordEncoder = $this->app->container->get('encoder');
            $user->setPassword($passwordEncoder->encodePassword($password));
            $user->save();

            $message = '<p>Hello '.$user->getFirstName().' '.$user->getLastName().'.</p>
            <p>Your new temporary password is '.$password.'.</p>
            <p>You can change it on your next successful login.</p><p>System Administrator</p>';

            Mailer::sendEmail('Password Recovery', 'noreply@rafmis.sys', $user->getEmail(), $message);
            echo 'Success';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException($e->getMessage());
        }
    }
}
