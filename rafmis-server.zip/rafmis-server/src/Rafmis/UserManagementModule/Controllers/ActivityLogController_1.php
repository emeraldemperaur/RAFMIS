<?php

namespace Rafmis\UserManagementModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\UserManagementModule\Repository\ActivityLogRepository;

class ActivityLogController extends BaseController {

    const REPOSITORY_NAME = 'activity_log_repository';

    public function all($page = 1, $count = 10) {/** @var ActivityLogRepository $activityLogRepository */
        $activityLogRepository = $this->getRepository(self::REPOSITORY_NAME);
        $activityLogs = $activityLogRepository->findAll($page, $count);
        if (!$activityLogs->count()) {
            echo 'No activityLog has been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
//            echo json_encode($activityLogs);
            echo $activityLogs->getResults()->toJSON();
        }
    }

    public function create() {
        $request = $this->app->request->post();/** @var ActivityLogRepository $activityLogRepository */$activityLogRepository = $this->getRepository(self::REPOSITORY_NAME);
        $activityLogRepository->saveActivityLog($request);
        echo 'ActivityLog has successfully been created';
    }

    public function show($activityId) {/** @var ActivityLogRepository $activityLogRepository */
        $activityLogRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $activityLog = $activityLogRepository->findActivityLogByActivityId($activityId);
            if ($activityLog !== null && is_object($activityLog)) {
                echo $activityLog->exportTo('JSON');
            } else {
                throw new EntityNotFoundException('Entity not Found', 404);
            }
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

//    public function update() {
//        $request = $this->app->request->post();/** @var ActivityLogRepository $activityLogRepository */$activityLogRepository = $this->getRepository(self::REPOSITORY_NAME);
//        try {
//            $activityLogRepository->saveActivityLog($request);
//            echo 'ActivityLog was successfully updated';
//        } catch (EntityNotFoundException $e) {
//            $this->createNotFoundException();
//        }
//    }

    public function delete($activityId) {
        $activityLogRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $activityLogRepository->deleteActivityLog($activityId);
            echo 'ActivityLog was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

}
