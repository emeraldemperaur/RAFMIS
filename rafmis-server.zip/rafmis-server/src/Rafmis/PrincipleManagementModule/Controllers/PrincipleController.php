<?php

namespace Rafmis\PrincipleManagementModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\PrincipleManagementModule\Repository\PrincipleRepository;

class PrincipleController extends BaseController {

    const REPOSITORY_NAME = 'principle_repository';

    public function all() {
        $request = $this->app->request->get();

        if (count($request)) {
            $columns = array(
                'principle_id',
                'description',
                'is_active',
                'is_default',
            );

            $principles = $this->tableData->get('principle', 'principle_id', $columns);
        } else {
            /** @var PrincipleRepository $principleRepository */
            $principleRepository = $this->getRepository(self::REPOSITORY_NAME);
            $principles = $principleRepository->findAll();
        }

        if (!count($principles)) {
            echo 'No principle has been added';
        } else if (count($request)) {
            echo json_encode($principles);
        } else{
            $this->app->response->header('content-type', 'application/json');
            echo $principles->toJSON();
        }
    }

    public function create() {
        $request = json_decode($this->app->request->getBody(), true);
        $request['CreatedBy'] = $this->getCurrentUser();

        /** @var PrincipleRepository $principleRepository */
        $principleRepository = $this->getRepository(self::REPOSITORY_NAME);
        $principleRepository->savePrinciple($request, 'create');

        echo 'Principle has successfully been created';
    }

    public function show($principleId) {
        /** @var PrincipleRepository $principleRepository */
        $principleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $principle = $principleRepository->findPrincipleByPrincipleId($principleId);
//            var_dump($principle);
            if ($principle !== null && is_object($principle)) {
                echo $principle->exportTo('json');
            } else {
                throw new EntityNotFoundException('Entity not Found', 404);
            }
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function update() {
        $request = json_decode($this->app->request->getBody(), true);
        $request['CreatedBy'] = $this->getCurrentUser();

        /** @var PrincipleRepository $principleRepository */
        $principleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $principleRepository->savePrinciple($request, 'update');
            echo 'Principle was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($principleId) {
        $principleRepository = $this->getRepository(self::REPOSITORY_NAME);

        try {
            $principleRepository->deletePrinciple($principleId);
            echo 'Principle was successfully deleted';
        } catch (EntityNotFoundException $e) {
//            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

}
