<?php

namespace Rafmis\PrincipleManagementModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\PrincipleManagementModule\Repository\RawDataRepository;

class RawDataController extends BaseController {

    const REPOSITORY_NAME = 'raw_data_repository';

    public function all($page = 1, $count = 10) {
        /** @var RawDataRepository $rawDataRepository */
        $rawDataRepository = $this->getRepository(self::REPOSITORY_NAME);
        $rawDatas = $rawDataRepository->findAll($page, $count);
        if (!$rawDatas->count()) {
            echo 'No rawData has been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
//            echo json_encode($rawDatas);
            echo $rawDatas->getResults()->toJSON();
        }
    }

    public function create() {
        $request = $this->app->request->post();
        /** @var RawDataRepository $rawDataRepository */
        $rawDataRepository = $this->getRepository(self::REPOSITORY_NAME);
        $rawDataRepository->saveRawData($request, 'create');
        echo 'RawData has successfully been created';
    }

    public function createMultiple() {
        $request = json_decode($this->app->request->getBody(), true);
        $user = $this->getCurrentUser();

        $request = array_map(function($item) use ($user) {
            $item['CreatedBy'] = $user;
            $item['DateCreated'] = new \DateTime();

            return $item;
        }, $request);

        /** @var RawDataRepository $rawDataRepository */
        $rawDataRepository = $this->getRepository(self::REPOSITORY_NAME);
        $rawDataRepository->saveMultipleRawData($request, 'create');
        echo 'Multiple RawData items have successfully been created';
    }

    public function show($principleItemId, $beneficiaryId) {
        /** @var RawDataRepository $rawDataRepository */
        $rawDataRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $rawData = $rawDataRepository->findRawDataByCompositeIds($principleItemId, $beneficiaryId);

            if ($rawData !== null && is_object($rawData)) {
                echo $rawData->exportTo('JSON');
            } else {
                throw new EntityNotFoundException('Entity not Found', 404);
            }
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function showByPrincipleItem($principleItemId) {
        /** @var RawDataRepository $rawDataRepository */
        $rawDataRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $rawData = $rawDataRepository->findRawDataByPrincipleItem($principleItemId);

            echo json_encode($rawData);
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function showByBeneficiaryCategory($principleItemId, $beneficiaryCategoryId) {
        /** @var RawDataRepository $rawDataRepository */
        $rawDataRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $rawData = $rawDataRepository->findRawDataByBeneficiaryCategory($principleItemId, $beneficiaryCategoryId);

            if ($rawData !== null) {
                echo $rawData->toJSON();
            } else {
                throw new EntityNotFoundException('Entity not Found', 404);
            }
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function showByBeneficiaryParent($principleItemId, $beneficiaryId) {
        /** @var RawDataRepository $rawDataRepository */
        $rawDataRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $rawData = $rawDataRepository->findRawDataByBeneficiaryParent($principleItemId, $beneficiaryId);

            if ($rawData !== null) {
                echo $rawData->toJSON();
            } else {
                throw new EntityNotFoundException('Entity not Found', 404);
            }
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function findRawDataBySpecifics() {
        /** @var RawDataRepository $rawDataRepository */
        $request = (array) json_decode($this->app->request->getBody(), true);
        /** @var RawDataRepository $rawDataRepository */
        $rawDataRepository = $this->getRepository(self::REPOSITORY_NAME);
        $result = $rawDataRepository->findRawDataBySpecifics($request);
//        var_dump($result);
        $arr = array();
        foreach ($result as $each) {
            $arr[$each['principle_item_id']][$each['beneficiary_id']] = $each['value'];
        }
        echo json_encode($arr);
    }

    public function update() {
        $request = $this->app->request->post();
        /** @var RawDataRepository $rawDataRepository */
        $rawDataRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $rawDataRepository->saveRawData($request, 'update');
            echo 'RawData was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($principleItemId) {
        $rawDataRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $rawDataRepository->deleteRawData($principleItemId);
            echo 'RawData was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

}
