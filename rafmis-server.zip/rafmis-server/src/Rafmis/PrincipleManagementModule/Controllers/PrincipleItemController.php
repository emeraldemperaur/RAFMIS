<?php

namespace Rafmis\PrincipleManagementModule\Controllers;

use Common\BaseController;
use Propel\Runtime\Exception\EntityNotFoundException;
use Rafmis\PrincipleManagementModule\Repository\PrincipleItemRepository;
use Rafmis\PrincipleManagementModule\Repository\RawDataRepository;

class PrincipleItemController extends BaseController {

    const REPOSITORY_NAME = 'principle_item_repository';

    public function all($page = 1, $count = 10) {/** @var PrincipleItemRepository $principleItemRepository */
        $principleItemRepository = $this->getRepository(self::REPOSITORY_NAME);
        $principleItems = $principleItemRepository->findAll($page, $count);
        if (!$principleItems->count()) {
            echo 'No principleItem has been added';
        } else {
            $this->app->response->header('content-type', 'application/json');
//            echo json_encode($principleItems);
            echo $principleItems->toJSON();
        }
    }

    public function create() {
        $request = $this->app->request->post();
        /** @var PrincipleItemRepository $principleItemRepository */
        $principleItemRepository = $this->getRepository(self::REPOSITORY_NAME);
        $principleItemRepository->savePrincipleItem($request, 'create');
        echo 'PrincipleItem has successfully been created';
    }

    public function createMultiple() {
        $request = json_decode($this->app->request->getBody(), true);

        /** @var PrincipleItemRepository $principleItemRepository */
        $principleItemRepository = $this->getRepository(self::REPOSITORY_NAME);
        $principleItemRepository->saveMultiplePrincipleItems($request, 'create', $this->getCurrentUser());
        echo 'Principle Items created';
    }

    public function show($principleItemId) {/** @var PrincipleItemRepository $principleItemRepository */
        $principleItemRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $principleItem = $principleItemRepository->findPrincipleItemByPrincipleItemId($principleItemId);
            if ($principleItem !== null && is_object($principleItem)) {
                echo $principleItem->toJSON();
            } else {
                throw new EntityNotFoundException('Entity not Found', 404);
            }
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function showPrinciple($principleId) {
        /** @var PrincipleItemRepository $principleItemRepository */
        $principleItemRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $principleItems = $principleItemRepository->findPrincipleItemByPrincipleId($principleId);

            if ($principleItems !== null && is_object($principleItems)) {
                foreach ($principleItems as $principleItem) {
                    $principleItemId = $principleItem->getPrincipleItemId();

                    /** @var RawDataRepository $rawDataRepo */
                    $rawDataRepo = $this->getRepository('raw_data_repository');

                    $rawData = $rawDataRepo->findMaximumDateRawDataByPrincipleItem($principleItemId);

                    $principleItem->setDateModified($rawData);
                }
            }

            if ($principleItems !== null && is_object($principleItems)) {
                echo $principleItems->toJSON();
            } else {
                throw new EntityNotFoundException('Entity not Found', 404);
            }
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

    public function update() {
        $request = json_decode($this->app->request->getBody(), true);
		$request['ModifiedBy'] = $this->getCurrentUser();

        /** @var PrincipleItemRepository $principleItemRepository */
        $principleItemRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $principleItemRepository->savePrincipleItem($request, 'update');
            echo 'PrincipleItem was successfully updated';
        } catch (EntityNotFoundException $e) {
            $this->createNotFoundException();
        }
    }

    public function delete($principleId) {
        /** @var PrincipleItemRepository $principleItemRepository */
        $principleItemRepository = $this->getRepository(self::REPOSITORY_NAME);
        try {
            $principleItemRepository->deletePrincipleItems($principleId);
            echo 'PrincipleItem was successfully deleted';
        } catch (EntityNotFoundException $e) {
            $this->app->response->setStatus(404);
            $this->createNotFoundException($e->getMessage());
        }
    }

}
