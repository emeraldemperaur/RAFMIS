<?php

namespace Rafmis\PrincipleManagementModule;

use Common\ServiceProviderInterface;
use Rafmis\PrincipleManagementModule\Repository\PrincipleRepository;
use Rafmis\PrincipleManagementModule\Repository\PrincipleItemRepository;
use Rafmis\PrincipleManagementModule\Repository\RawDataRepository;
use Slim\Slim;

class PrincipleManagementModule {

    public function register($app) {
        //adds PrincipleRepository to Slim container
        $app->container->singleton('principle_repository', function () use ($app) {
            return new PrincipleRepository($app);
        });
        //adds PrincipleItemRepository to Slim container
        $app->container->singleton('principle_item_repository', function () use ($app) {
            return new PrincipleItemRepository($app);
        });
        //adds RawDataRepository to Slim container
        $app->container->singleton('raw_data_repository', function () use ($app) {
            return new RawDataRepository($app);
        });
    }

}
