<?php

namespace Rafmis\PrincipleManagementModule\Repository;

use Map\PrincipleItemTableMap;
use Propel\Runtime\Exception\EntityNotFoundException;
use PrincipleItem;
use PrincipleItemQuery;
use Propel\Runtime\Propel;
use Slim\Slim;

class PrincipleItemRepository {

    /**
     * * @var Slim	 
     */
    private $app;

    /**
     * * @var PrincipleItem	 
     */
    private $principleItem;

    /**
     * * @param Slim $app	 
     */
    public function __construct(Slim $app) {
        $this->app = $app;
        $this->principleItem = new PrincipleItem();
        return $this;
    }

    /**
     * * @param array $data	 
     * * @return int The number of affected rows	 
     */
    public function savePrincipleItem($data, $mode) {
        $principleItem = null;
        $data = json_decode($data);
        if (isset($data->PrincipleItemId) && $mode == 'update') {
            $principleItem = $this->findPrincipleItemByPrincipleItemId($data->PrincipleItemId);
        } else {
            $principleItem = $this->principleItem;
        }
        $principleItemId = $mode === 'update' ? $data->PrincipleItemId : NULL;
        /* sets all required properties of the principle_item */
        $principleItem->setPrincipleItemId($principleItemId);
        $principleItem->setPrincipleItemName($data->PrincipleItemName);
        $principleItem->setPrincipleId($data->PrincipleId);
        $principleItem->setBeneficiaryCategoryId($data->BeneficiaryCategoryId);
        $principleItem->setIsEqual($data->IsEqual);
        $principleItem->setPercentageAllocation($data->PercentageAllocation);
        $principleItem->setParentId($data->ParentId);
        $principleItem->setDateCreated($mode === 'create' ? date('Y-m-d H:i:s') : $principleItem->getDateCreated());
        $principleItem->setCreatedBy($mode === 'create' ? $data->CreatedBy : $principleItem->getCreatedBy());
        $principleItem->setDateModified($mode === 'update' ? date('Y-m-d H:i:s') : $principleItem->getDateModified());
        $principleItem->setModifiedBy($mode === 'update' ? $data->ModifiedBy : null);

        return $principleItem->save();
    }


    /**
     * * @param array $data
     * * @return int The number of affected rows
     */
    public function saveMultiplePrincipleItems($dataList, $mode, $createdBy) {

        $conn = Propel::getWriteConnection(PrincipleItemTableMap::DATABASE_NAME);

		$conn->beginTransaction();

		try {
			foreach($dataList as $data){
				$principleItem = null;

				$principleItem = new PrincipleItem();

				/* sets all required properties of the principle_item */
				$principleItem->setPrincipleItemId($data['PrincipleItemId']);
				$principleItem->setPrincipleItemName($data['PrincipleItemName']);
				$principleItem->setPrincipleId($data['PrincipleId']);
				$principleItem->setBeneficiaryCategoryId($data['BeneficiaryCategoryId']);
				$principleItem->setIsEqual($data['IsEqual']);
				$principleItem->setPercentageAllocation($data['PercentageAllocation']);
				$principleItem->setParentId($data['ParentId']);
				$principleItem->setDateCreated(new \DateTime());
				$principleItem->setCreatedBy($createdBy);
				$principleItem->setDateModified(new \DateTime());
				$principleItem->setModifiedBy($createdBy);//var_dump($principleItem->getIsEqual());exit;
				$principleItem->save();
			}

			$conn->commit();
		} catch (\Exception $e) {
			$conn->rollBack();
			throw $e;
		}

        return $dataList;
    }

    /**
     * * @param(s) $principleItemId	 *	 
     * * @return array|mixed|PrincipleItem finds a PrincipleItem by its id(s)	 *	 
     * * finds a PrincipleItem by its id(s)	 
     */
    public function findPrincipleItemByPrincipleItemId($principleItemId) {
        $principleItem = PrincipleItemQuery::create()->findOneByPrincipleItemId($principleItemId);
//        if (!$principleItem) {
//            throw new EntityNotFoundException('Entity not found.');
//        } 
        return $principleItem;
    }

    public function findPrincipleItemByPrincipleId($principleId) {
        $principleItems = PrincipleItemQuery::create()
            ->findByPrincipleId($principleId);

        return $principleItems;
    }

    /**
     * * @param(s) $principleItemId	 *	 
     * * @return mixed	 
     */
    public function deletePrincipleItems($principleId) { /** @var PrincipleItem $principleItem */
        $principleItems = PrincipleItemQuery::create()->findByPrincipleId($principleId);

        if (!count($principleItems)) {
            throw new EntityNotFoundException('No principle items where found for the given principle id');
        }

        $principleItems->delete();
    }

    public function findAll($page = 1, $count = 10) {
        $principleItems = PrincipleItemQuery::create()->find();
        return $principleItems;
    }

}
