<?php

namespace Rafmis\PrincipleManagementModule\Repository;

use Map\RawDataTableMap;
use Propel\Runtime\Collection\ObjectCollection;
use Propel\Runtime\Exception\EntityNotFoundException;
use Propel\Runtime\Propel;
use Propel\Runtime\Formatter\ObjectFormatter;
use RawData;
use RawDataQuery;
use BeneficiaryQuery;
use Rafmis\BeneficiaryManagementModule\Repository\BeneficiaryRepository;
use Slim\Slim;
use Symfony\Component\Config\Definition\Exception\Exception;

class RawDataRepository {

    /**
     * * @var Slim	 
     */
    private $app;

    /**
     * * @var RawData	 
     */
    private $rawData;

    /**
     * * @var Connectiom	 
     */
    private $con;

    /**
     * * @param Slim $app	
     */
    public function __construct(Slim $app) {
        $this->con = Propel::getConnection();
        $this->app = $app;
        $this->rawData = new RawData();
        return $this;
    }

    /**
     * * @param array $data	 
     * * @return int The number of affected rows	 
     */
    public function saveRawData(array $data, $mode) {

        $rawData = null;
        if (isset($data['principle_item_id']) && isset($data['beneficiary_id']) && $mode == 'update') {
            $rawData = $this->findRawDataByCompositeIds($data['principle_item_id'], $data['beneficiary_id']);
        } else {
            $rawData = new RawData();
        }


        /* sets all required properties of the raw_data */
        $rawData->setPrincipleItemId($data['principle_item_id']);
        $rawData->setBeneficiaryId($data['beneficiary_id']);
        $rawData->setValue($data['value']);
        $rawData->setDateCreated($mode === 'create' ? date('Y-m-d H:i:s') : $rawData->getDateCreated());
        $rawData->setCreatedBy($data['created_by']);
        $rawData->setDateModified($mode === 'update' ? date('Y-m-d H:i:s') : $rawData->getDateModified());
        $rawData->setModifiedBy($data['modified_by']);
        return $rawData->save($this->con);
    }

    /**
     * * @param array $data
     * * @return int The number of affected rows
     */
    public function saveMultipleRawData($dataList, $mode) {
        $collection = new ObjectCollection();
        $collection->setModel('RawData');
        $collection->fromArray($dataList);
        $collection->save();
    }

    /**
     * * @param(s) 	 *	 
     * * @return array|mixed|RawData finds a RawData by its id(s)	 *	 
     * * finds a RawData by its id(s)	 
     */
    public function findRawDataByCompositeIds($principleItemId, $beneficiaryId) {

//        var_dump($con);
        $rawData = RawDataQuery::create()->where('RawData.PrincipleItemId = ?', $principleItemId)->where('RawData.BeneficiaryId = ?', $beneficiaryId)->find();
//        $rawData = RawDataQuery::create()->findByCompositeIds($principleItemId, $beneficiaryId);
        //  $rawData = RawDataQuery::create()->findOneByArray(array('PrincipleItemId' => $principleItemId, 'BeneficiaryId' => $beneficiaryId), $this->con);
//        if (!$rawData) {
//            throw new EntityNotFoundException('Entity not found.');
//        } 
        return $rawData;
    }

    /**
     * * @param(s) 	 *
     * * @return array|mixed|RawData finds a RawData by its id(s)	 *
     * * finds a RawData by its id(s)
     */
    public function findRawDataByPrincipleItem($principleItemId) {
        $sql = 'SELECT * FROM raw_data LEFT JOIN beneficiary ON raw_data.beneficiary_id = beneficiary.beneficiary_id where raw_data.principle_item_id=:principleItemId';
        $stmt = $this->con->prepare($sql);
        $stmt->bindParam('principleItemId', $principleItemId);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * * @param(s) 	 *
     * * @return string finds a RawData by its id(s)	 *
     * * finds a RawData by its id(s)
     */
    public function findMaximumDateRawDataByPrincipleItem($principleItemId) {
        $sql = 'SELECT MAX(date_created) as MaxDateCreated FROM raw_data WHERE principle_item_id = :principleItemId';
        $stmt = $this->con->prepare($sql);
        $stmt->bindParam('principleItemId', $principleItemId);
        $stmt->execute();
        return $stmt->fetchColumn();
    }

    /**
     * * @param(s) 	 *
     * * @return array|mixed|RawData finds a RawData by its id(s)	 *
     * * finds a RawData by its id(s)
     */
    public function findRawDataByBeneficiaryCategory($principleItemId, $beneficiaryCategoryId) {


        $rawData = RawDataQuery::create()
                ->joinWith('Beneficiary')
                ->useBeneficiaryQuery()
                ->filterByBeneficiaryCategoryId($beneficiaryCategoryId)
                ->endUse()
                ->filterByPrincipleItemId($principleItemId)
                ->find();

        return $rawData;
    }

    /**
     * * @param(s) 	 *
     * * @return array|mixed|RawData finds a RawData by its id(s)	 *
     * * finds a RawData by its id(s)
     */
    public function findRawDataByBeneficiaryParent($principleItemId, $beneficiaryId) {


        $rawData = RawDataQuery::create()
                ->joinWith('Beneficiary')
                ->useBeneficiaryQuery()
                ->filterByParentId($beneficiaryId)
                ->endUse()
                ->filterByPrincipleItemId($principleItemId)
                ->find();

        return $rawData;
    }

    /**
     * * @param(s) 	 *
     * * @return array|mixed|RawData finds a RawData by its id(s)	 *
     * * finds a RawData by its id(s)
     */
    public function findRawDataBySpecifics(array $request) {
        $beneficiaryCatAllocationGroupId = $request['beneficiary_cat_allocation_group_id'];
        $beneficiaryCatId = $request['beneficiary_category_id'];
        $stmtrw = $this->con->prepare("SELECT raw_data.*
FROM raw_data
  JOIN principle_item
    ON principle_item.principle_item_id = raw_data.principle_item_id
  JOIN beneficiary_category_allocation
    ON beneficiary_category_allocation.principle_id = principle_item.principle_id
WHERE beneficiary_category_allocation.beneficiary_cat_allocation_group_id = ?
    AND principle_item.beneficiary_category_id = ?");
        $stmtrw->bindValue(1, $beneficiaryCatAllocationGroupId);
        $stmtrw->bindValue(2, $beneficiaryCatId);
        $stmtrw->execute();
        $result = $stmtrw->fetchAll(\PDO::FETCH_ASSOC);
        return $result;
    }

    /**
     * * @param(s) 	 *	 
     * * @return mixed	 
     */
    public function deleteRawData($principleItemId) {
        /** @var RawData $rawData */
//        $rawData = $this->findRawDataByCompositeIds($principleItemId, $beneficiaryId);
//        $rawData->delete($this->con);

        $sql = "DELETE FROM raw_data WHERE principle_item_id = ?";

        $stmt = $this->con->prepare($sql);
        $stmt->bindValue(1, $principleItemId);

        $rs = $stmt->execute();
    }

    public function findAll($page = 1, $count = 10) {
        $rawDatas = RawDataQuery::create()->find();
        return $rawDatas;
    }

}
