<?php

namespace Rafmis\PrincipleManagementModule\Repository;

use Propel\Runtime\Exception\EntityNotFoundException;
use Principle;
use PrincipleQuery;
use Slim\Slim;

class PrincipleRepository {

    /**
     * @var Slim
     */
    private $app;

    /**
     * @var Principle
     */
    private $principle;

    /**
     * @param Slim $app
     */
    public function __construct(Slim $app) {
        $this->app = $app;
        $this->principle = new Principle();

        return $this;
    }

    /**
     * @param array $data
     * @return int The number of affected rows
     */
    public function savePrinciple($data, $mode) {
//        $principle = $this->principle;
//verifies if the data passed in is a managed by propel
        if (isset($data['PrincipleId']) && $mode == 'update') {
            $principle = $this->findPrincipleByPrincipleId($data['PrincipleId']);
        } else {
            $principle = $this->principle;
        }

//sets all required properties of the principle
        $principle->setPrincipleId($data['PrincipleId']);
        $principle->setDescription($data['Description']);
        $principle->setIsActive($data['IsActive']);
        $principle->setIsDefault($data['IsDefault']);
        $principle->setDateCreated($mode === 'create' ? new \DateTime() : $principle->getDateCreated());
        $principle->setCreatedBy($mode === 'create' ? $data['CreatedBy'] : $principle->getCreatedBy());
        $principle->setDateModified($mode === 'update' ? new \DateTime() : $principle->getDateModified());
        $principle->setModifiedBy($mode === 'update' ? $data['CreatedBy'] : null);

        return $principle->save();
    }

    /**
     * @param $principleId
     *
     * @return array|mixed|Principle finds a principle by its PrincipleId
     *
     * finds a principle by its PrincipleId
     */
    public function findPrincipleByPrincipleId($principleId) {
        $principle = PrincipleQuery::create()->findOneByPrincipleId($principleId);

        return $principle;
    }

    /**
     * @param $principleId
     *
     * @return mixed
     */
    public function deletePrinciple($principleId) {
        /** @var Principle $principle */
        $principle = $this->findPrincipleByPrincipleId(urldecode($principleId));

        if ($principle !== null && is_object($principle)) {
            $principle->delete();
        } else {
            throw new EntityNotFoundException('Entity not Found', 404);
        }
    }

    public function findAll($page = 1, $count = 10) {
        $principles = PrincipleQuery::create()->find();

        return $principles;
    }

}
