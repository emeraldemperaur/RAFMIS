<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Africa/Lagos');
// setup the autoloading
require_once 'vendor/autoload.php';

// session time out for users
        const SESSION_TIMEOUT = 30;

// setup Propel
use Propel\Runtime\Propel;
use Rafmis\UserManagementModule\Middleware\AuthorizationMiddleware;
use Rafmis\UserManagementModule\Middleware\TokenAuthenticatorMiddleware;

Propel::init("generated-conf/config.php");
set_include_path("models" . PATH_SEPARATOR . get_include_path());

$app = new \Slim\Slim();

//enable CORS on the server
$corsOptions = array(
    "origin" => "*",
    "exposeHeaders" => array("X-My-Custom-Header", "X-Another-Custom-Header"),
    "maxAge" => 1728000,
    "allowCredentials" => True,
    "allowMethods" => array("POST, GET"),
    "allowHeaders" => array("X-PINGOTHER")
);
        const MAX_DAYS_FOR_DELETE = 5;
//routes inclusion list
//require 'routes/revenue_collection_entity.php';
//routes autoload list
require 'config/routes.autoload.php';

//services configuration inclusion
require 'config/services.php';

$app->add(new AuthorizationMiddleware($app->container->get('session_manager')));
$app->add(new TokenAuthenticatorMiddleware($app->container->get('session_manager')));
$app->add(new \CorsSlim\CorsSlim());
$app->config('debug', true);
$app->error(function ( Exception $e ) use ($app) {
    $exceptionPackage = array('code' => $e->getCode(), 'message' => $e->getMessage(), 'file' => $e->getFile(), 'line' => $e->getLine());
    echo json_encode($exceptionPackage);
});


$app->run();
